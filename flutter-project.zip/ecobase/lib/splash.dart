import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:provider/provider.dart';
import 'dashboard_page.dart';
import 'login_page.dart';
import 'theme_provider.dart';

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String sessionKey;
  final String expiredDate;
  final List<Map<String, dynamic>> listBug;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.sessionKey,
    required this.expiredDate,
    required this.listBug,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<double> _scaleAnimation;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _initAnimations();
    // LANGSUNG KE DASHBOARD, TANPA VALIDASI ULANG
    _goToDashboard();
  }

  void _initAnimations() {
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: const Interval(0.0, 0.6, curve: Curves.easeOut),
      ),
    );

    _scaleAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: const Interval(0.0, 0.5, curve: Curves.easeOutBack),
      ),
    );

    _slideAnimation = Tween<Offset>(begin: const Offset(0, 0.3), end: Offset.zero).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: const Interval(0.3, 0.8, curve: Curves.easeOutCubic),
      ),
    );

    _animationController.forward();
  }

  // PERBAIKAN: Langsung ke Dashboard tanpa validasi ulang
  void _goToDashboard() async {
    // Tunggu animasi selesai (minimal 2 detik)
    await Future.delayed(const Duration(seconds: 2));

    if (!mounted) return;

    // LANGSUNG NAVIGASI KE DASHBOARD
    // Data sudah lengkap dari parameter, tidak perlu validasi ulang
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          listBug: widget.listBug,
          sessionKey: widget.sessionKey,
          news: widget.news,
        ),
      ),
    );
  }

  // Opsional: Jika tetap ingin validasi, gunakan method ini
  // Tapi pastikan API response benar
  Future<void> _validateAndNavigate() async {
    // Tunggu animasi selesai (minimal 2 detik)
    await Future.delayed(const Duration(seconds: 2));

    if (!mounted) return;

    try {
      // PERBAIKAN: Kirim semua parameter yang diperlukan
      final response = await http.get(
        Uri.parse(
          'http://panel.asta-official.my.id:2619/myInfo?username=${widget.username}&password=${widget.password}&key=${widget.sessionKey}',
        ),
      ).timeout(const Duration(seconds: 10));

      print('Splash validation response: ${response.statusCode}');
      print('Splash validation body: ${response.body}');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        
        // PERBAIKAN: Cek apakah valid = true
        if (data['valid'] == true) {
          // Session masih valid, lanjut ke Dashboard
          if (mounted) {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => DashboardPage(
                  username: widget.username,
                  password: widget.password,
                  role: widget.role,
                  expiredDate: widget.expiredDate,
                  listBug: widget.listBug,
                  sessionKey: widget.sessionKey,
                  news: widget.news,
                ),
              ),
            );
          }
        } else {
          // Session tidak valid, tapi kita tetap lanjut ke Dashboard
          // karena data dari login sudah valid
          print('Session invalid, but proceeding to dashboard anyway');
          _goToDashboard();
        }
      } else {
        // Gagal koneksi, tetap lanjut ke Dashboard
        print('Connection failed, proceeding to dashboard anyway');
        _goToDashboard();
      }
    } catch (e) {
      // Error koneksi, tetap lanjut ke Dashboard
      print('Error: $e, proceeding to dashboard anyway');
      _goToDashboard();
    }
  }

  void _redirectToLogin() async {
    if (!mounted) return;
    
    // Hapus session yang tersimpan
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('username');
    await prefs.remove('password');
    await prefs.remove('key');

    if (mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const LoginPage()),
      );
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Provider.of<ThemeProvider>(context);
    
    return Scaffold(
      backgroundColor: theme.backgroundColor,
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.center,
            radius: 1.2,
            colors: [
              theme.primaryColor.withOpacity(0.2),
              theme.backgroundColor,
              theme.backgroundColor,
            ],
            stops: const [0.0, 0.5, 1.0],
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Logo dengan animasi scale dan fade
              FadeTransition(
                opacity: _fadeAnimation,
                child: ScaleTransition(
                  scale: _scaleAnimation,
                  child: Container(
                    width: 140,
                    height: 140,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [theme.primaryColor, theme.accentColor],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: theme.primaryColor.withOpacity(0.6),
                          blurRadius: 40,
                          spreadRadius: 8,
                        ),
                        BoxShadow(
                          color: theme.accentColor.withOpacity(0.3),
                          blurRadius: 20,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: ClipOval(
                      child: Image.asset(
                        'assets/images/logo.png',
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return Center(
                            child: Icon(
                              Icons.security_rounded,
                              size: 70,
                              color: Colors.white.withOpacity(0.9),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ),
              ),
              
              const SizedBox(height: 50),

              // Title dengan animasi slide
              SlideTransition(
                position: _slideAnimation,
                child: Column(
                  children: [
                    ShaderMask(
                      shaderCallback: (bounds) => LinearGradient(
                        colors: [theme.primaryColor, theme.accentColor],
                      ).createShader(bounds),
                      child: Text(
                        "DEATH RAT",
                        style: TextStyle(
                          fontSize: 32,
                          fontWeight: FontWeight.bold,
                          color: theme.textPrimaryColor,
                          letterSpacing: 3,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                      decoration: BoxDecoration(
                        color: theme.glassSecondary,
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(color: theme.primaryColor.withOpacity(0.3)),
                      ),
                      child: Text(
                        "ADVANCED RAT SYSTEM",
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: theme.textSecondaryColor,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                    
                    const SizedBox(height: 30),

                    // Loading indicator
                    Container(
                      width: 40,
                      height: 40,
                      child: CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation<Color>(theme.primaryColor),
                        strokeWidth: 3,
                      ),
                    ),
                    
                    const SizedBox(height: 20),
                    
                    // Loading text
                    Text(
                      "LOADING SYSTEM...",
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        color: theme.textSecondaryColor.withOpacity(0.6),
                        letterSpacing: 2,
                      ),
                    ),
                    
                    const SizedBox(height: 40),

                    // Animated dots
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(3, (index) {
                        return AnimatedBuilder(
                          animation: _animationController,
                          builder: (context, child) {
                            final value = (_animationController.value * 3 + index) % 3;
                            final opacity = value < 1 ? 1.0 : 0.3;
                            return Container(
                              margin: const EdgeInsets.symmetric(horizontal: 4),
                              width: 6,
                              height: 6,
                              decoration: BoxDecoration(
                                color: theme.primaryColor.withOpacity(opacity),
                                shape: BoxShape.circle,
                              ),
                            );
                          },
                        );
                      }),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}