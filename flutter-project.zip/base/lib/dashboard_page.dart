import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';

// Page Imports
import '.dart';
import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart'; 
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'partner_page.dart';
import 'moderator_page.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late AnimationController _pulseController;
  late WebSocketChannel channel;

  // --- State Variabel ---
  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;

  String androidId = "unknown";
  File? _profileImage; 
  VideoPlayerController? _menuVideoController; 

  int _bottomNavIndex = 0;
  Widget _selectedPage = const Placeholder();

  int onlineUsers = 0;
  int activeConnections = 0;

  // --- TEMA AGRESIF: BLACK & NEON BLUE WITH RED ACCENT ---
  final Color bgDark = const Color(0xFF05070B);       
  final Color cardDark = const Color(0xFF0F121D);     
  final Color neonCyan = const Color(0xFF00E5FF);     
  final Color neonRed = const Color(0xFFFF1744);      
  final Color textMuted = const Color(0xFF4E5B73);    

  @override
  void initState() {
    super.initState();
    _systemUIConfig();
    
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _controller = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOutCubic);

    // Inisialisasi pulse controller lebih dulu sebelum memanggil page builder
    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    )..repeat(reverse: true);

    _controller.forward();
    _selectedPage = _buildNewsPage();

    _initAndroidIdAndConnect();
    _loadProfileImage(); 
    _initMenuVideo(); 
  }

  void _systemUIConfig() {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
    ));
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  void _initMenuVideo() {
    _menuVideoController =
        VideoPlayerController.asset('assets/videos/banner.mp4')
          ..initialize().then((_) {
            setState(() {});
            _menuVideoController?.setLooping(true);
            _menuVideoController?.play();
          });
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(
      Uri.parse('wss://ws-dark.Tr4sFlox.my.id'),
    );
    channel.sink.add(
      jsonEncode({
        "type": "validate",
        "key": sessionKey,
        "androidId": androidId,
      }),
    );
    channel.sink.add(jsonEncode({"type": "stats"}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo' && data['valid'] == false) {
        if (data['reason'] == 'androidIdMismatch') {
          _handleInvalidSession("Your account has logged on another device.");
        } else if (data['reason'] == 'keyInvalid') {
          _handleInvalidSession("Key is not valid. Please login again.");
        }
      }
      if (data['type'] == 'stats') {
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 0;
          activeConnections = data['activeConnections'] ?? 0;
        });
      }
    });
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: cardDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: neonRed.withOpacity(0.5)),
        ),
        title: Row(
          children: [
            Icon(Icons.gpp_bad_rounded, color: neonRed),
            const SizedBox(width: 10),
            const Text(
              "Session Expired",
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontFamily: 'Orbitron'),
            ),
          ],
        ),
        content: Text(message, style: TextStyle(color: textMuted)),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
            child: Text(
              "RE-LOGIN",
              style: TextStyle(color: neonCyan, fontWeight: FontWeight.bold, fontFamily: 'Orbitron'),
            ),
          ),
        ],
      ),
    );
  }

  void _onBottomNavTapped(int index) {
    setState(() {
      _bottomNavIndex = index;
      if (index == 0) {
        _selectedPage = _buildNewsPage();
      } else if (index == 1) {
        _selectedPage = HomePage(
          username: username,
          password: password,
          listBug: listBug,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
        );
      } else if (index == 2) {
        _selectedPage = InfoPage(sessionKey: sessionKey);
      } else if (index == 3) {
        _selectedPage = ToolsPage(
          sessionKey: sessionKey,
          userRole: role,
          listDoos: listDoos,
        );
      }
    });
  }

  void _onSidebarTabSelected(int index) {
    setState(() {
      if (index == 1) _selectedPage = SellerPage(keyToken: sessionKey);
      if (index == 2) _selectedPage = AdminPage(sessionKey: sessionKey);
      if (index == 3) _selectedPage = OwnerPage(sessionKey: sessionKey, username: username);
      if (index == 4) _selectedPage = PartnerPage(sessionKey: sessionKey, username: username);
      if (index == 5) _selectedPage = ModeratorPage(sessionKey: sessionKey, username: username);
    });
    Navigator.pop(context);
  }

  Widget _buildNewsPage() {
    return Stack(
      children: [
        Positioned.fill(
          child: CustomPaint(
            painter: GridPainter(color: neonCyan.withOpacity(0.015)),
          ),
        ),
        SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            children: [
              const SizedBox(height: 20),
              
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    _buildHUDCard("ONLINE SYSTEM", onlineUsers.toString(), neonCyan, hasPulse: true),
                    const SizedBox(width: 12),
                    _buildHUDCard("ACTIVE BRIDGES", activeConnections.toString(), neonCyan),
                  ],
                ),
              ),

              Container(
                height: 220,
                margin: const EdgeInsets.only(top: 25, bottom: 25),
                child: PageView.builder(
                  physics: const BouncingScrollPhysics(),
                  controller: PageController(viewportFraction: 0.90),
                  itemCount: newsList.length,
                  itemBuilder: (context, index) {
                    final item = newsList[index];
                    return Container(
                      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        color: cardDark,
                        border: Border.all(color: neonCyan.withOpacity(0.15), width: 1.5),
                        boxShadow: [
                          BoxShadow(
                            color: neonCyan.withOpacity(0.05),
                            blurRadius: 15,
                            offset: const Offset(0, 5),
                          ),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(14),
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            if (item['image'] != null && item['image'].toString().isNotEmpty)
                              NewsMedia(url: item['image']),
                            Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [bgDark.withOpacity(0.95), bgDark.withOpacity(0.4), Colors.transparent],
                                  begin: Alignment.bottomCenter,
                                  end: Alignment.topCenter,
                                ),
                              ),
                            ),
                            Positioned(
                              top: 12, right: 12,
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(color: neonCyan.withOpacity(0.1), borderRadius: BorderRadius.circular(4)),
                                child: Text("FEED NODE // 0${index + 1}", style: TextStyle(color: neonCyan, fontSize: 8, fontFamily: "Orbitron", fontWeight: FontWeight.bold)),
                              ),
                            ),
                            Positioned(
                              bottom: 16,
                              left: 16,
                              right: 16,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    item['title'] ?? 'SYSTEM LOG',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 15,
                                      fontFamily: "Orbitron",
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 0.5,
                                      shadows: [Shadow(color: neonCyan.withOpacity(0.5), blurRadius: 4)]
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    item['desc'] ?? '',
                                    style: const TextStyle(
                                      color: Colors.white70,
                                      fontSize: 12,
                                      height: 1.3,
                                    ),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: _buildModernBugSenderButton(
                  label: "INITIALIZE BUG SENDER",
                  subLabel: "SECURE MALIGNANT TERMINAL GATEWAY",
                  icon: Icons.biotech_rounded, 
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => BugSenderPage(
                          sessionKey: sessionKey,
                          username: username,
                          role: role,
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 25),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildHUDCard(String title, String value, Color accent, {bool hasPulse = false}) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: cardDark,
          borderRadius: BorderRadius.circular(16),
          gradient: LinearGradient(
            colors: [cardDark, cardDark.withOpacity(0.7)],
            begin: Alignment.topLeft, end: Alignment.bottomRight,
          ),
          border: Border.all(color: accent.withOpacity(0.15), width: 1.2),
          boxShadow: [
            BoxShadow(color: accent.withOpacity(0.02), blurRadius: 10, spreadRadius: 1)
          ]
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  title, 
                  style: TextStyle(color: textMuted, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1.5),
                ),
                if (hasPulse)
                  FadeTransition(
                    opacity: _pulseController,
                    child: Container(
                      width: 6, height: 6,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: neonCyan, boxShadow: [BoxShadow(color: neonCyan, blurRadius: 6, spreadRadius: 1)]),
                    ),
                  )
              ],
            ),
            const SizedBox(height: 8),
            Text(
              value, 
              style: TextStyle(
                color: Colors.white, 
                fontSize: 26, 
                fontFamily: 'Orbitron', 
                fontWeight: FontWeight.w900,  // ✅ SUDAH DIPERBAIKI
                shadows: [
                  Shadow(color: accent.withOpacity(0.4), blurRadius: 10),
                ]
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildModernBugSenderButton({
    required String label,
    required String subLabel,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [neonRed.withOpacity(0.2), cardDark, neonRed.withOpacity(0.03)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: neonRed.withOpacity(0.5), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: neonRed.withOpacity(0.15),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          splashColor: neonRed.withOpacity(0.25),
          highlightColor: Colors.transparent,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: neonRed.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: neonRed.withOpacity(0.3))
                  ),
                  child: Icon(icon, color: neonRed, size: 24),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        label,
                        style: TextStyle(
                          color: Colors.white, 
                          fontSize: 13, 
                          fontWeight: FontWeight.w900,  // ✅ SUDAH DIPERBAIKI
                          fontFamily: 'Orbitron',
                          letterSpacing: 1.5,
                          shadows: [
                            Shadow(color: neonRed.withOpacity(0.7), blurRadius: 8),
                          ]
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        subLabel,
                        style: TextStyle(color: textMuted, fontSize: 9, fontWeight: FontWeight.w600, letterSpacing: 0.5),
                      )
                    ],
                  ),
                ),
                Icon(Icons.chevron_right_rounded, color: neonRed.withOpacity(0.7))
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCustomDrawer() {
    return Drawer(
      backgroundColor: bgDark,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SizedBox(
            height: 220,
            child: Stack(
              children: [
                if (_menuVideoController != null && _menuVideoController!.value.isInitialized)
                  SizedBox.expand(
                    child: FittedBox(
                      fit: BoxFit.cover,
                      child: SizedBox(
                        width: _menuVideoController!.value.size.width,
                        height: _menuVideoController!.value.size.height,
                        child: VideoPlayer(_menuVideoController!),
                      ),
                    ),
                  ),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Colors.transparent, bgDark],
                    ),
                  ),
                ),
                Positioned(
                  bottom: 16,
                  left: 20,
                  child: Row(
                    children: [
                      Container(
                        width: 56,
                        height: 56,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: neonCyan, width: 2),
                        ),
                        child: ClipOval(
                          child: _profileImage != null
                              ? Image.file(_profileImage!, fit: BoxFit.cover)
                              : Icon(FontAwesomeIcons.userAstronaut, size: 22, color: neonCyan),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            username, 
                            style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron'),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            role.toUpperCase(), 
                            style: TextStyle(color: neonCyan, fontSize: 10, letterSpacing: 1.5, fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              children: [
                if (role == "reseller") _buildDrawerMenuItem(Icons.storefront, "Seller Page", () => _onSidebarTabSelected(1)),
                if (role == "admin") _buildDrawerMenuItem(Icons.admin_panel_settings_rounded, "Admin Page", () => _onSidebarTabSelected(2)),
                if (role == "partner") _buildDrawerMenuItem(FontAwesomeIcons.handshake, "Partner Page", () => _onSidebarTabSelected(4)),
                if (role == "moderator") _buildDrawerMenuItem(FontAwesomeIcons.userShield, "Moderator Page", () => _onSidebarTabSelected(5)),
                if (role == "owner") _buildDrawerMenuItem(Icons.workspace_premium_rounded, "Owner Page", () => _onSidebarTabSelected(3)),
                
                _buildDrawerMenuItem(Icons.history_rounded, "Riwayat Aktivitas", () {
                  Navigator.pop(context);
                  Navigator.push(context, MaterialPageRoute(builder: (_) => RiwayatPage(sessionKey: sessionKey, role: role)));
                }),
                
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 8),
                  child: Divider(color: Colors.white10, thickness: 0.5),
                ),
                
                _buildDrawerMenuItem(Icons.logout_rounded, "Log Out", () async {
                  Navigator.pop(context);
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.clear();
                  if (!mounted) return;
                  Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginPage()), (route) => false);
                }, isLogout: true),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerMenuItem(IconData icon, String label, VoidCallback onTap, {bool isLogout = false}) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 2),
      decoration: BoxDecoration(
        color: isLogout ? neonRed.withOpacity(0.05) : Colors.transparent,
        borderRadius: BorderRadius.circular(10),
      ),
      child: ListTile(
        horizontalTitleGap: 8,
        leading: Icon(icon, color: isLogout ? neonRed : Colors.white70, size: 20),
        title: Text(
          label,
          style: TextStyle(
            color: isLogout ? neonRed : Colors.white, 
            fontWeight: FontWeight.w500, 
            fontSize: 14,
            fontFamily: isLogout ? 'Orbitron' : null
          ),
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        onTap: onTap,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        title: Text(
          "𝐎𝐗𝐅𝐎𝐑𝐃 𝐄𝐍𝐆𝐈𝐍𝐄", 
          style: TextStyle(
            color: Colors.white, 
            fontWeight: FontWeight.w900, 
            fontSize: 16, 
            fontFamily: 'Orbitron', 
            letterSpacing: 2.5,
            shadows: [
              Shadow(color: neonCyan.withOpacity(0.6), blurRadius: 12),
              Shadow(color: neonCyan.withOpacity(0.3), blurRadius: 4),
            ]
          ),
        ),
        centerTitle: true,
        backgroundColor: bgDark,
        elevation: 0,
        iconTheme: IconThemeData(color: neonCyan),
        actions: [
          IconButton(
            icon: const Icon(Icons.headset_mic_rounded, size: 20),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ContactPage())),
          ),
          IconButton(
            icon: const Icon(Icons.account_circle_rounded, size: 20),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(
              username: username, password: password, role: role, expiredDate: expiredDate, sessionKey: sessionKey,
            ))),
          ),
          const SizedBox(width: 6),
        ],
      ),
      drawer: _buildCustomDrawer(),
      body: SafeArea(
        child: FadeTransition(opacity: _animation, child: _selectedPage),
      ),
      
      bottomNavigationBar: SafeArea(
        bottom: true,
        child: Container(
          margin: const EdgeInsets.only(bottom: 20, left: 20, right: 20), 
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
          decoration: BoxDecoration(
            color: cardDark.withOpacity(0.85),
            borderRadius: BorderRadius.circular(24), 
            border: Border.all(color: neonCyan.withOpacity(0.25), width: 1.5),
            boxShadow: [
              BoxShadow(
                color: neonCyan.withOpacity(0.06),
                blurRadius: 16,
                offset: const Offset(0, -2),
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildCustomNavItem(0, Icons.grid_view_rounded, "Dashboard"),
              _buildCustomNavItem(1, FontAwesomeIcons.whatsapp, "Bug"),
              _buildCustomNavItem(2, Icons.notifications_none_rounded, "Info"),
              _buildCustomNavItem(3, Icons.data_saver_off_rounded, "Tools"),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCustomNavItem(int index, IconData icon, String label) {
    final bool isSelected = _bottomNavIndex == index;
    return InkWell(
      onTap: () => _onBottomNavTapped(index),
      splashColor: Colors.transparent,
      highlightColor: Colors.transparent,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: isSelected ? neonCyan.withOpacity(0.12) : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? neonCyan.withOpacity(0.3) : Colors.transparent,
            width: 1
          )
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon, 
              color: isSelected ? Colors.white : textMuted, 
              size: 18,
              shadows: isSelected ? [Shadow(color: neonCyan, blurRadius: 8)] : null,
            ),
            if (isSelected) ...[
              const SizedBox(width: 8),
              Text(
                label,
                style: const TextStyle(
                  color: Colors.white, 
                  fontSize: 11, 
                  fontWeight: FontWeight.w900,  // ✅ SUDAH DIPERBAIKI
                  fontFamily: 'Orbitron',
                  letterSpacing: 0.5
                ),
              ),
            ]
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    channel.sink.close(status.goingAway);
    _controller.dispose();
    _pulseController.dispose();
    _menuVideoController?.dispose();
    super.dispose();
  }
}

class GridPainter extends CustomPainter {
  final Color color;
  GridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1.0;

    const double gridSpacing = 30.0;

    for (double i = 0; i < size.width; i += gridSpacing) {
      canvas.drawLine(Offset(i, 0), Offset(i, size.height), paint);
    }
    for (double i = 0; i < size.height; i += gridSpacing) {
      canvas.drawLine(Offset(0, i), Offset(size.width, i), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(0.0);
          _controller?.play();
        });
    }
  }

  bool _isVideo(String url) {
    return url.endsWith(".mp4") ||
        url.endsWith(".webm") ||
        url.endsWith(".mov") ||
        url.endsWith(".mkv");
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return AspectRatio(
          aspectRatio: _controller!.value.aspectRatio,
          child: VideoPlayer(_controller!),
        );
      } else {
        return const Center(
          child: CircularProgressIndicator(color: Color(0xFF00E5FF), strokeWidth: 2),
        );
      }
    } else {
      return Image.network(
        widget.url,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(
          color: const Color(0xFF10121A),
          child: const Icon(Icons.broken_image_rounded, color: Colors.white24),
        ),
      );
    }
  }
}