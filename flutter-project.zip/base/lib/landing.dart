import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  // --- IDENTITY COLOR: BLACK & CYBER NEON ---
  final Color bgDark = const Color(0xFF07080B);       // Hitam Pekat Cyber
  final Color cardDark = const Color(0xFF10121A);     // Matte Black untuk Card/Tombol
  final Color neonCyan = const Color(0xFF00E5FF);     // Biru Muda Neon
  final Color neonRed = const Color(0xFFFF1744);      // Merah Neon (Aksen)
  final Color textMuted = const Color(0xFF6C7A9C);    // Teks redup modern

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
    );

    _slideAnimation = Tween<Offset>(begin: const Offset(0, 0.1), end: const Offset(0, 0)).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOutCubic),
    );

    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: SlideTransition(
            position: _slideAnimation,
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 28),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(height: 30),

                  // --- BRANDING HERO (Lebih Bersih & Rapi) ---
                  Container(
                    height: 320,
                    width: double.infinity,
                    child: Image.asset(
                      "assets/images/reze.png",
                      fit: BoxFit.contain,
                      errorBuilder: (context, error, stackTrace) {
                        return Center(
                          child: Icon(Icons.blur_on_rounded, size: 80, color: neonCyan.withOpacity(0.2)),
                        );
                      },
                    ),
                  ),

                  const SizedBox(height: 10),

                  // --- DESKRIPSI TEKS ---
                  const Text(
                    "𝐎𝐗𝐅𝐎𝐑𝐃 𝐄𝐍𝐆𝐈𝐍𝐄",
                    style: TextStyle(
                      fontFamily: 'Orbitron',
                      fontSize: 28,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      letterSpacing: 2.0,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "𝐆𝐀𝐂𝐎𝐑 • 𝐓𝐄𝐑𝐔𝐏𝐃𝐀𝐓𝐄 • 𝐄𝐋𝐄𝐆𝐀𝐍",
                    style: TextStyle(
                      color: textMuted,
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                    ),
                    textAlign: TextAlign.center,
                  ),

                  const SizedBox(height: 40),

                  // --- TOMBOL SIGN IN (Neon Border Style) ---
                  Container(
                    width: double.infinity,
                    height: 54,
                    decoration: BoxDecoration(
                      color: cardDark,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: neonCyan, width: 1.5),
                      boxShadow: [
                        BoxShadow(
                          color: neonCyan.withOpacity(0.15),
                          blurRadius: 12,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        shadowColor: Colors.transparent,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      onPressed: () => Navigator.pushNamed(context, "/login"),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.login_rounded, color: neonCyan, size: 18),
                          const SizedBox(width: 10),
                          const Text(
                            "SIGN IN",
                            style: TextStyle(
                              fontFamily: 'Orbitron',
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                              letterSpacing: 1.0,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),

                  // --- TOMBOL BUY ACCESS (Aksen Merah Neon Tipis) ---
                  Container(
                    width: double.infinity,
                    height: 54,
                    decoration: BoxDecoration(
                      color: cardDark,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: neonRed.withOpacity(0.4), width: 1),
                    ),
                    child: OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        side: BorderSide.none,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      onPressed: () => _openUrl("https://t.me/Oxfordcomunity"),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.telegram, color: neonRed, size: 18),
                          const SizedBox(width: 10),
                          const Text(
                            "JOIN COMMUNITY",
                            style: TextStyle(
                              fontFamily: 'Orbitron',
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                              letterSpacing: 1.0,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 24),

                  // --- TOMBOL CONTACT (Minimalis Sekali) ---
                  Row(
                    children: [
                      Expanded(
                        child: _buildContactButton(
                          icon: FontAwesomeIcons.telegram,
                          label: "Telegram",
                          url: "https://t.me/oxfordengine",
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: _buildContactButton(
                          icon: FontAwesomeIcons.whatsapp,
                          label: "WhatsApp",
                          url: "https://whatsapp.com/channel/0029VbCKqeO0bIdmyfS0Ds32",
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 40),

                  // --- FOOTER ---
                  Text(
                    "© 2026 𝐎𝐗𝐅𝐎𝐑𝐃 𝐄𝐍𝐆𝐈𝐍𝐄 • 𝐒𝐘𝐒𝐓𝐄𝐌 𝐒𝐄𝐂𝐔𝐑𝐈𝐓𝐘",
                    style: TextStyle(
                      color: textMuted.withOpacity(0.5), 
                      fontSize: 11, 
                      fontFamily: 'Orbitron',
                      letterSpacing: 0.5
                    ),
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildContactButton({required IconData icon, required String label, required String url}) {
    return InkWell(
      onTap: () => _openUrl(url),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        height: 48,
        decoration: BoxDecoration(
          color: cardDark,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white.withOpacity(0.05)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FaIcon(icon, color: Colors.white70, size: 16),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                color: textMuted,
                fontWeight: FontWeight.w600,
                fontSize: 13,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
