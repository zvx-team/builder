# Flutter Music App

Port ke Flutter dari project Next.js `WEB-MUSIC-NEW-UPDATE_IMPORT_PLAYLIST` (web music player berbasis YouTube Music).

## Fitur yang sudah ada
- Search lagu (via endpoint internal YouTube Music, seperti yang dipakai `ytmusic-api` di versi web)
- Pemutaran audio lewat **embedded YouTube iframe player resmi** (`youtube_player_iframe`) — bukan download/rip file
- Mini player + full player screen
- Queue, shuffle, repeat (off/all/one)
- Riwayat & play count, disimpan lokal (SharedPreferences)
- Lirik (plain & synced) dari [lrclib.net](https://lrclib.net) — database lirik komunitas gratis

## Struktur folder
```
lib/
  models/track.dart          # model data lagu/artis/thumbnail
  services/ytmusic_service.dart  # search ke YouTube Music
  services/lyrics_service.dart   # ambil lirik dari lrclib
  state/player_state.dart    # state global (queue, shuffle, repeat, history)
  screens/home_screen.dart   # search + hasil
  screens/player_screen.dart # now playing + lirik
  widgets/mini_player.dart
  widgets/track_tile.dart
```

## Kalau kena error "deleted Android v1 embedding" / build gagal
Zip ini sekarang **sudah termasuk folder `android/`** dengan v2 embedding (modern, `FlutterActivity`).
Kalau tetap error di build service (misal bot Telegram), penyebab paling umum:
- Build service pakai Flutter SDK versi lama/beda dari yang di-assume di `android/build.gradle` (AGP 8.3.0, Kotlin 1.9.22, Gradle 8.6, compileSdk 34). Kalau service-nya pakai Flutter versi lawas, minta versi Flutter stabil terbaru, atau kabarin gue versinya biar disesuaikan.
- `local.properties` (path SDK Android & Flutter) biasanya di-generate otomatis oleh tool build-nya — kalau bot-nya perlu file itu manual, kasih tau formatnya.

## Cara build APK — GitHub Actions (gratis, gak perlu install Flutter)
Zip ini udah dilengkapi `.github/workflows/build.yml` yang otomatis build APK di cloud GitHub.

1. Buat akun & repo baru di github.com (boleh Private)
2. Upload semua isi zip ini ke repo:
   ```bash
   cd flutter_music_app
   git init
   git add .
   git commit -m "init"
   git branch -M main
   git remote add origin https://github.com/USERNAME/NAMA-REPO.git
   git push -u origin main
   ```
   (Kalau gak familiar `git`, bisa drag-and-drop file lewat tombol "Add file > Upload files" di web GitHub)
3. Buka tab **Actions** di repo — workflow "Build APK" otomatis jalan (~beberapa menit)
4. Setelah selesai (centang hijau), klik run-nya > scroll ke **Artifacts** > download `flutter-music-app-release` → extract, itu APK-nya

Tiap push baru ke `main` = APK baru otomatis. Mau trigger manual: tab Actions > "Build APK" > "Run workflow".

## Cara jalanin (kalau punya Flutter SDK sendiri)
```bash
flutter pub get
flutter run
```

Build APK:
```bash
flutter build apk --release
```

## Catatan penting
- **Belum ada API resmi dari YouTube Music.** `ytmusic_service.dart` manggil endpoint internal yang sama dipakai open-source project `ytmusicapi`/`ytmusic-api` — bisa berubah/rusak sewaktu-waktu kalau Google ubah format response-nya. Cocok buat belajar/pakai pribadi; kalau mau rilis publik & rame, pertimbangkan risiko ToS.
- Pemutaran tetap lewat player YouTube resmi (embed), jadi monetisasi/iklan mereka tetap jalan — bukan mekanisme bypass/download.
- Import playlist (dari Spotify/YouTube Music playlist link) di versi web belum di-port di scaffold ini — struktur `PlayerState` & `Track` sudah siap dipakai kalau mau nambahin fitur itu, tinggal bikin parser link + service baru.
- Fitur admin/genai (`@google/genai` di package.json versi web) juga belum di-port — kasih tau kalau itu tetap mau dimasukin, biar gue tambahin.

## Next steps yang bisa ditambahin
- Import playlist dari link Spotify/YouTube
- Playlist buatan sendiri (simpan ke local storage / cloud)
- Background audio (pakai `just_audio` + `audio_service` kalau mau audio-only tanpa video surface, plus notification media controls)
