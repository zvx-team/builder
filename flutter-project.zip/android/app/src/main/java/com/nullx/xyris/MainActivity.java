package com.nullx.xyris;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
