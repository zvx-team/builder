package com.nullx.hoxtenv5;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
