import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';

class WorldCupStreamPage extends StatefulWidget {
  const WorldCupStreamPage({super.key});

  @override
  State<WorldCupStreamPage> createState() => _WorldCupStreamPageState();
}

class _WorldCupStreamPageState extends State<WorldCupStreamPage> {
  // ✅ WARNA SESUAI TEMA KAMU
  final Color bgDark       = const Color(0xFF000000);
  final Color cardDark      = const Color(0xFF0F0204);
  final Color redMain       = const Color(0xFFFF2244);
  final Color redBright     = const Color(0xFFFF1744);
  final Color textWhite     = const Color(0xFFFFFFFF);
  final Color textMuted     = const Color(0xFF70444E);

  ChewieController? _chewieController;
  VideoPlayerController? _videoController;
  int _selectedMatchIndex = -1;
  bool _isLoading = false;

  // ⚽ DAFTAR PERTANDINGAN & TAUTAN SIARAN
  // GANTI 'LINK_SIARAN_RESIMI' DENGAN TAUTAN YANG BERIZIN & SAH
  final List<Map<String, String>> _matchList = [
    {
      "teamHome": "Brasil",
      "teamAway": "Prancis",
      "time": "20:00 WIB",
      "stage": "Penyisihan Grup",
      "streamUrl": "LINK_SIARAN_RESIMI/brasillawanprancis.m3u8"
    },
    {
      "teamHome": "Argentina",
      "teamAway": "Jerman",
      "time": "23:00 WIB",
      "stage": "Perempat Final",
      "streamUrl": "LINK_SIARAN_RESIMI/argentinallawanjerman.m3u8"
    },
    {
      "teamHome": "Indonesia",
      "teamAway": "Spanyol",
      "time": "02:00 WIB",
      "stage": "Babak Penyisihan",
      "streamUrl": "LINK_SIARAN_RESIMI/indonesialawanspanyol.m3u8"
    }
  ];

  Future<void> _initVideoPlayer(String url) async {
    setState(() {
      _isLoading = true;
    });
    // Hentikan pemutar sebelumnya jika ada
    await _videoController?.dispose();
    _chewieController?.dispose();

    _videoController = VideoPlayerController.networkUrl(Uri.parse(url));
    await _videoController!.initialize();

    _chewieController = ChewieController(
      videoPlayerController: _videoController!,
      autoPlay: true,
      looping: false,
      allowFullScreen: true,
      allowPlaybackSpeedChanging: true,
      materialProgressColors: ChewieProgressColors(
        playedColor: redBright,
        handleColor: redMain,
        backgroundColor: cardDark,
        bufferedColor: textMuted,
      ),
    );
    setState(() {
      _isLoading = false;
    });
  }

  @override
  void dispose() {
    _videoController?.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        title: const Text(
          "⚽ PIALA DUNIA 2026",
          style: TextStyle(
            color: textWhite,
            fontWeight: FontWeight.bold,
            fontFamily: 'Orbitron',
            letterSpacing: 1.2,
          ),
        ),
        centerTitle: true,
        backgroundColor: cardDark,
        elevation: 0,
        iconTheme: const IconThemeData(color: redBright),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // 🎦 AREA PEMUTAR VIDEO
            if (_selectedMatchIndex != -1) ...[
              Container(
                decoration: BoxDecoration(
                  color: cardDark,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: redBright.withOpacity(0.6), width: 1.5),
                  boxShadow: [
                    BoxShadow(
                      color: redBright.withOpacity(0.2),
                      blurRadius: 12,
                      spreadRadius: 1,
                    )
                  ],
                ),
                padding: const EdgeInsets.all(8),
                child: _isLoading
                    ? const SizedBox(
                        height: 220,
                        child: Center(
                          child: CircularProgressIndicator(color: redBright, strokeWidth: 2.5),
                        ),
                      )
                    : _chewieController != null
                        ? AspectRatio(
                            aspectRatio: 16 / 9,
                            child: Chewie(controller: _chewieController!),
                          )
                        : const SizedBox.shrink(),
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: cardDark,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: redMain.withOpacity(0.3)),
                ),
                child: Text(
                  "📺 Sedang menonton: ${_matchList[_selectedMatchIndex]['teamHome']} vs ${_matchList[_selectedMatchIndex]['teamAway']}",
                  style: const TextStyle(color: textWhite, fontSize: 13),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 24),
            ],

            // 📋 DAFTAR PERTANDINGAN
            const Text(
              "PILIH PERTANDINGAN",
              style: TextStyle(
                color: textWhite,
                fontWeight: FontWeight.w700,
                fontSize: 14,
                letterSpacing: 1.1,
              ),
            ),
            const SizedBox(height: 14),
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _matchList.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, index) {
                final match = _matchList[index];
                final isSelected = _selectedMatchIndex == index;
                return GestureDetector(
                  onTap: () {
                    setState(() => _selectedMatchIndex = index);
                    _initVideoPlayer(match['streamUrl']!);
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 220),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: isSelected ? redMain.withOpacity(0.12) : cardDark,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: isSelected ? redBright : redMain.withOpacity(0.25),
                        width: 1.3,
                      ),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.sports_soccer, color: redBright, size: 26),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "${match['teamHome']}  ⚔️  ${match['teamAway']}",
                                style: const TextStyle(
                                  color: textWhite,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 15,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                "${match['stage']} • ${match['time']}",
                                style: TextStyle(color: textMuted, fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.play_circle_fill, color: redBright, size: 32),
                      ],
                    ),
                  ),
                );
              },
            ),

            const SizedBox(height: 30),
            // ⚠️ PERINGATAN HUKUM
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: redMain.withOpacity(0.08),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: redMain.withOpacity(0.3)),
              ),
              child: const Text(
                "⚠️ Catatan: Gunakan hanya sumber siaran resmi dan berizin hak cipta. Penggunaan tautan tidak sah melanggar peraturan berlaku.",
                style: TextStyle(color: textMuted, fontSize: 11, height: 1.4),
                textAlign: TextAlign.center,
              ),
            )
          ],
        ),
      ),
    );
  }
}