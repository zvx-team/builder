import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with SingleTickerProviderStateMixin {
  final targetController = TextEditingController();
  late AnimationController _pulseController;
  String selectedBugId = "";

  // --- State Target ---
  String _selectedBugMode = "number"; // 'number' atau 'group'

  // --- State Sender ---
  String _senderMode = "private"; // 'private' atau 'global'
  int _privateSenderCount = 0;
  int _globalSenderCount = 0;
  bool _isSending = false;
  String? _responseMessage;

  // --- WARNA SUDAH SESUAI PERMINTAAN ---
  final Color bgDark = const Color(0xFF000000);       // Hitam pekat murni
  final Color cardDark = const Color(0xFF0F0204);     // Latar kartu hitam bernuansa merah gelap
  final Color neonCyan = const Color(0xFFFF2244);     // Semua biru diganti merah menyala
  final Color neonRed = const Color(0xFFFF1744);      // Merah utama tetap
  final Color textMuted = const Color(0xFF70444E);    // Teks redup bernuansa merah

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    // Filter bug default
    if (widget.listBug.isNotEmpty) {
      final initialBugs = _getFilteredBugs();
      if (initialBugs.isNotEmpty) {
        selectedBugId = initialBugs[0]['bug_id'];
      }
    }
    _fetchSenderStats(); 
  }

  // --- FUNGSI: Filter Bug ---
  List<Map<String, dynamic>> _getFilteredBugs() {
    if (_selectedBugMode == "group") {
      return widget.listBug.where((b) => b['bug_id'].contains('_group')).toList();
    } else {
      return widget.listBug.where((b) => !b['bug_id'].contains('_group')).toList();
    }
  }

  // --- FUNGSI: Ambil Statistik Sender ---
  Future<void> _fetchSenderStats() async {
    try {
      final res = await http.get(Uri.parse("$apiBaseUrl/getSenderStats?key=${widget.sessionKey}"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() {
            _privateSenderCount = data['private'] ?? 0;
            _globalSenderCount = data['global'] ?? 0;
          });
        }
      }
    } catch (e) {
      debugPrint("Error fetching sender stats: $e");
    }
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (cleaned.length < 8) return null;
    return cleaned;
  }

  bool isValidGroupLink(String input) {
    return input.contains('chat.whatsapp.com') && input.contains('https://');
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    if (_selectedBugMode == "number") {
      final target = formatPhoneNumber(rawInput);
      if (target == null || key.isEmpty) {
        _showAlert("❌ Invalid Number", "Gunakan nomor internasional (misal: +62, 1), bukan 08xxx.");
        return;
      }
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showAlert("❌ Invalid Link", "Masukkan link group WA yang valid (https://chat.whatsapp.com/...).");
        return;
      }
    }

    final currentBugs = _getFilteredBugs();
    if (!currentBugs.any((b) => b['bug_id'] == selectedBugId)) {
      if (currentBugs.isNotEmpty) {
        setState(() {
          selectedBugId = currentBugs[0]['bug_id'];
        });
      } else {
        _showAlert("⚠️ Error", "Tidak ada bug tersedia untuk mode ini.");
        return;
      }
    }

    setState(() {
      _isSending = true;
      _responseMessage = null;
    });

    try {
      final res = await http.get(Uri.parse("$apiBaseUrl/sendBug?key=$key&target=$rawInput&bug=$selectedBugId&senderMode=$_senderMode"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        setState(() => _responseMessage = "⏳ Cooldown: Tunggu beberapa saat.");
      } else if (data["valid"] == false) {
        setState(() => _responseMessage = "❌ Key Invalid: Silakan login ulang.");
      } else if (data["sended"] == false) {
        setState(() => _responseMessage = "⚠️ Gagal: Server sedang maintenance.");
      } else {
        setState(() => _responseMessage = "✅ Berhasil mengirim bug!");
        targetController.clear();
        _fetchSenderStats(); 
      }
    } catch (_) {
      setState(() => _responseMessage = "❌ Error: Terjadi kesalahan. Coba lagi.");
    } finally {
      setState(() {
        _isSending = false;
      });
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardDark,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: neonRed.withOpacity(0.7), width: 1.3),
        ),
        titlePadding: const EdgeInsets.only(top: 20, left: 20, right: 20),
        title: Text(
          title,
          style: TextStyle(color: neonRed, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 16),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        content: Text(msg, style: TextStyle(color: textMuted, fontSize: 14, height: 1.4)),
        actionsPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK", style: TextStyle(color: neonCyan, fontWeight: FontWeight.bold, fontSize: 14)),
          ),
        ],
      ),
    );
  }

  Widget _buildHeaderPanel() {
    return Container(
      padding: const EdgeInsets.all(18),
      margin: const EdgeInsets.symmetric(horizontal: 2),
      decoration: BoxDecoration(
        color: cardDark,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: neonCyan.withOpacity(0.35), width: 1.2),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(2),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: neonCyan, width: 1.5),
            ),
            child: const CircleAvatar(
              radius: 28,
              backgroundColor: Colors.transparent,
              backgroundImage: AssetImage('assets/images/logo.png'),
            ),
          ),
          const SizedBox(width: 18),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.username,
                  style: const TextStyle(
                    color: Colors.white,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w900,
                    fontSize: 18,
                    letterSpacing: 1.0,
                  ),
                ),
                const SizedBox(height: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: neonCyan.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    "ROLE: ${widget.role.toUpperCase()}  •  EXP: ${widget.expiredDate}",
                    style: TextStyle(
                      color: neonCyan,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildModeSelector() {
    return Row(
      children: [
        _buildModeTab("BUG NOMOR", "number", Icons.phone_android_rounded),
        const SizedBox(width: 14),
        _buildModeTab("BUG GROUP", "group", Icons.group_add),
      ],
    );
  }

  Widget _buildModeTab(String label, String mode, IconData icon) {
    final bool isSelected = _selectedBugMode == mode;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            _selectedBugMode = mode;
            targetController.clear();
            final newBugs = _getFilteredBugs();
            if (newBugs.isNotEmpty) {
              selectedBugId = newBugs[0]['bug_id'];
            }
          });
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            color: isSelected ? neonCyan.withOpacity(0.15) : cardDark,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isSelected ? neonCyan : neonCyan.withOpacity(0.25),
              width: 1.2,
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: isSelected ? neonCyan : textMuted, size: 19),
              const SizedBox(width: 8),
              Text(
                label,
                style: TextStyle(
                  color: isSelected ? Colors.white : textMuted,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                  fontFamily: 'Orbitron',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSenderToggle() {
    return Row(
      children: [
        _buildSenderTab("SENDER PRIVATE", "private", _privateSenderCount),
        const SizedBox(width: 14),
        _buildSenderTab("SENDER GLOBAL", "global", _globalSenderCount),
      ],
    );
  }

  Widget _buildSenderTab(String label, String mode, int count) {
    final bool isSelected = _senderMode == mode;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _senderMode = mode),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isSelected ? neonCyan.withOpacity(0.15) : cardDark,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isSelected ? neonCyan : neonCyan.withOpacity(0.25),
              width: 1.2,
            ),
          ),
          child: Column(
            children: [
              Text(
                label,
                style: TextStyle(
                  color: isSelected ? Colors.white : textMuted,
                  fontWeight: FontWeight.bold,
                  fontSize: 11,
                  fontFamily: 'Orbitron',
                ),
              ),
              const SizedBox(height: 4),
              Text(
                "$count Active",
                style: TextStyle(color: isSelected ? neonCyan : textMuted, fontSize: 10),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInputPanel() {
    final availableBugs = _getFilteredBugs();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _buildModeSelector(),
        const SizedBox(height: 22),
        
        Text(
          _selectedBugMode == "number" ? "NOMOR TARGET" : "LINK GROUP WA",
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w700,
            fontSize: 12,
            fontFamily: 'Orbitron',
            letterSpacing: 1.5,
          ),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: targetController,
          style: const TextStyle(color: Colors.white, fontSize: 15),
          cursorColor: neonCyan,
          keyboardType: _selectedBugMode == "number" ? TextInputType.phone : TextInputType.url,
          decoration: InputDecoration(
            hintText: _selectedBugMode == "number" ? "Contoh: +62xxxxxxxxxx" : "Contoh: https://chat.whatsapp.com/...",
            hintStyle: TextStyle(color: textMuted.withOpacity(0.6), fontSize: 13),
            filled: true,
            fillColor: cardDark,
            contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 18),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: neonCyan.withOpacity(0.25)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: neonCyan, width: 1.5),
            ),
            prefixIcon: Padding(
              padding: const EdgeInsets.only(left: 4),
              child: Icon(
                _selectedBugMode == "number" ? Icons.phone_android_rounded : Icons.link,
                color: neonCyan,
                size: 20,
              ),
            ),
          ),
        ),
        const SizedBox(height: 22),
        if (availableBugs.isNotEmpty) ...[
          const Text(
            "PILIH ENGINE BUG",
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w700,
              fontSize: 12,
              fontFamily: 'Orbitron',
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            decoration: BoxDecoration(
              color: cardDark,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: neonCyan.withOpacity(0.25), width: 1.2),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                dropdownColor: cardDark,
                value: selectedBugId,
                isExpanded: true,
                iconEnabledColor: neonCyan,
                style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold),
                items: availableBugs.map((bug) {
                  return DropdownMenuItem<String>(
                    value: bug['bug_id'],
                    child: Text(bug['bug_name']),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    selectedBugId = value ?? "";
                  });
                },
              ),
            ),
          ),
        ] else ...[
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 14),
            child: Center(child: Text("Tidak ada bug tersedia.", style: TextStyle(color: neonRed, fontSize: 12))),
          )
        ]
      ],
    );
  }

  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        return Container(
          height: 56,
          width: double.infinity,
          margin: const EdgeInsets.symmetric(horizontal: 2),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            color: cardDark,
            border: Border.all(color: neonRed.withOpacity(0.8), width: 1.8),
            boxShadow: [
              BoxShadow(
                color: neonRed.withOpacity(0.35),
                blurRadius: _pulseController.value * 14,
                spreadRadius: _pulseController.value * 1.2,
              ),
            ],
          ),
          child: ElevatedButton(
            onPressed: _isSending ? null : _sendBug,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              elevation: 0,
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
            child: _isSending
                ? SizedBox(height: 22, width: 22, child: CircularProgressIndicator(color: neonRed, strokeWidth: 2.2))
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.gavel_rounded, color: neonRed, size: 21),
                      const SizedBox(width: 12),
                      const Text(
                        "LAUNCH ATTACK",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 15,
                          letterSpacing: 2,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                    ],
                  ),
          ),
        );
      },
    );
  }

  Widget _buildResponseMessage() {
    if (_responseMessage == null) return const SizedBox.shrink();
    bool isSuccess = _responseMessage!.startsWith('✅');
    Color mainColor = isSuccess ? Colors.greenAccent : neonRed;
    return Padding(
      padding: const EdgeInsets.only(top: 18, bottom: 8),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: mainColor.withOpacity(0.08),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: mainColor.withOpacity(0.45), width: 1.2),
        ),
        child: Row(
          children: [
            Icon(isSuccess ? Icons.check_circle_outline_rounded : Icons.error_outline_rounded, color: mainColor, size: 22),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                _responseMessage!,
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13, height: 1.4),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildHeaderPanel(),
              const SizedBox(height: 26),
              _buildInputPanel(),
              const SizedBox(height: 26),
              
              if (widget.role == 'owner' || widget.role == 'vip' || widget.role == 'ceo' || widget.role == 'tk' || widget.role == 'developer') ...[
                _buildSenderToggle(),
                const SizedBox(height: 26),
              ],
              _buildSendButton(),
              _buildResponseMessage(),
            ],
          ),
        ),
      ),
    );
  }
}