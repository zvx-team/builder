import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '.dart';

class BugSenderPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const BugSenderPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<BugSenderPage> createState() => _BugSenderPageState();
}

class _BugSenderPageState extends State<BugSenderPage> {
  List<dynamic> senderList = [];
  bool isLoading = false;
  bool isRefreshing = false;
  String? errorMessage;

  // ✅ WARNA TETAP SAMA PERSIS
  final Color bgDark       = const Color(0xFF000000);
  final Color primaryRed   = const Color(0xFF990022);
  final Color accentRed    = const Color(0xFFFF2B4F);
  final Color lightRed     = const Color(0xFFFF738C);
  final Color primaryWhite = const Color(0xFFFFFFFF);
  final Color cardGlass    = const Color(0xFF140206).withOpacity(0.7);
  final Color borderGlass  = const Color(0xFFFF2B4F).withOpacity(0.25);

  @override
  void initState() {
    super.initState();
    _fetchSenders();
  }

  Future<void> _fetchSenders() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });
    try {
      final response = await http.get(
        Uri.parse("$apiBaseUrl/mySender?key=${widget.sessionKey}"),
        headers: {'Content-Type': 'application/json'},
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          setState(() {
            senderList = data["connections"] ?? [];
          });
        } else {
          setState(() {
            errorMessage = data["message"] ?? "Failed to fetch senders";
          });
        }
      } else {
        setState(() {
          errorMessage = "Server error: ${response.statusCode}";
        });
      }
    } catch (e) {
      setState(() {
        errorMessage = "Connection failed: $e";
      });
    } finally {
      setState(() {
        isLoading = false;
        isRefreshing = false;
      });
    }
  }

  Future<void> _refreshSenders() async {
    setState(() => isRefreshing = true);
    await _fetchSenders();
  }

  void _showAddSenderDialog() {
    final phoneController = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: bgDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: accentRed.withOpacity(0.5), width: 1.2)
        ),
        title: Row(
          children: [
            Icon(Icons.add_circle, color: accentRed, size: 26),
            const SizedBox(width: 14),
            Text(
              "Add New Sender",
              style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold, fontSize: 17)
            ),
          ],
        ),
        content: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: phoneController,
                keyboardType: TextInputType.phone,
                style: TextStyle(color: primaryWhite, fontSize: 15),
                decoration: InputDecoration(
                  labelText: "Phone Number",
                  labelStyle: TextStyle(color: lightRed, fontSize: 14),
                  hintText: "62812xxxxxxx",
                  hintStyle: TextStyle(color: Colors.white54, fontSize: 14),
                  prefixIcon: Icon(Icons.phone, color: accentRed, size: 20),
                  filled: true,
                  fillColor: const Color(0xFF1A0308),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: primaryRed),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: accentRed, width: 1.5),
                  ),
                ),
              ),
            ],
          ),
        ),
        actionsPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("CANCEL", style: TextStyle(color: Colors.white54, fontSize: 14)),
          ),
          const SizedBox(width: 8),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [primaryRed, accentRed]),
              borderRadius: BorderRadius.circular(12),
            ),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: () async {
                final number = phoneController.text.trim();
                if (number.isEmpty) {
                  _showSnackBar("Please enter phone number", isError: true);
                  return;
                }
                Navigator.pop(context);
                await _addSender(number);
              },
              child: Text(
                "ADD SENDER",
                style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold, fontSize: 14)
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _addSender(String number) async {
    setState(() => isLoading = true);
    try {
      final response = await http.get(
        Uri.parse("$apiBaseUrl/getPairing?key=${widget.sessionKey}&number=$number"),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          _showPairingCodeDialog(number, data['pairingCode']);
          _showSnackBar("Pairing code generated successfully!", isError: false);
        } else {
          _showSnackBar(data['message'] ?? "Failed to generate pairing code", isError: true);
        }
      } else {
        _showSnackBar("Server error: ${response.statusCode}", isError: true);
      }
    } catch (e) {
      _showSnackBar("Connection failed: $e", isError: true);
    } finally {
      setState(() => isLoading = false);
      _fetchSenders();
    }
  }

  void _showPairingCodeDialog(String number, String code) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: bgDark,
        insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: accentRed.withOpacity(0.4))
        ),
        titlePadding: const EdgeInsets.only(top: 20, left: 20, right: 20),
        title: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: primaryRed.withOpacity(0.18),
                shape: BoxShape.circle,
                border: Border.all(color: accentRed.withOpacity(0.3)),
              ),
              child: Icon(Icons.qr_code_2, color: accentRed, size: 40),
            ),
            const SizedBox(height: 16),
            Text(
              "Pairing Required",
              style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold, fontSize: 18)
            ),
          ],
        ),
        contentPadding: const EdgeInsets.all(20),
        content: Container(
          width: double.maxFinite,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
          decoration: BoxDecoration(
            color: cardGlass,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: accentRed.withOpacity(0.3)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text("Number: $number", style: TextStyle(color: primaryWhite, fontSize: 15)),
              const SizedBox(height: 22),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: accentRed, width: 2),
                  boxShadow: [
                    BoxShadow(color: accentRed.withOpacity(0.45), blurRadius: 18, spreadRadius: 1)
                  ],
                ),
                child: Text(
                  code,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: accentRed,
                    fontSize: 34,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 6,
                    fontFamily: 'Courier',
                  ),
                ),
              ),
              const SizedBox(height: 22),
              Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: primaryRed.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: accentRed.withOpacity(0.5)),
                ),
                child: OutlinedButton.icon(
                  icon: Icon(Icons.copy, color: accentRed, size: 18),
                  label: Text(
                    "COPY CODE",
                    style: TextStyle(color: accentRed, fontWeight: FontWeight.bold, fontSize: 14)
                  ),
                  style: OutlinedButton.styleFrom(
                    side: BorderSide.none,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: () async {
                    await Clipboard.setData(ClipboardData(text: code));
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text("Code copied to clipboard!", style: TextStyle(color: Colors.white)),
                          backgroundColor: primaryRed,
                          behavior: SnackBarBehavior.floating,
                          margin: const EdgeInsets.all(16),
                          duration: const Duration(seconds: 2),
                        ),
                      );
                    }
                  },
                ),
              ),
            ],
          ),
        ),
        actionsPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("CLOSE", style: TextStyle(color: primaryWhite, fontSize: 14)),
          ),
          const SizedBox(width: 10),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [primaryRed, accentRed]),
              borderRadius: BorderRadius.circular(12),
            ),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: () {
                Navigator.pop(context);
                _fetchSenders();
              },
              child: Text("REFRESH LIST", style: TextStyle(color: primaryWhite, fontSize: 14)),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteSender(String senderId) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: bgDark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        titlePadding: const EdgeInsets.only(top: 20, left: 20, right: 20),
        title: Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: Colors.orangeAccent, size: 24),
            const SizedBox(width: 12),
            Text("Confirm Delete", style: TextStyle(color: primaryWhite, fontSize: 16)),
          ],
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        content: Text(
          "Are you sure you want to delete this sender? This action cannot be undone.",
          style: TextStyle(color: Colors.white70, fontSize: 14, height: 1.4),
        ),
        actionsPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text("CANCEL", style: TextStyle(color: primaryWhite, fontSize: 14)),
          ),
          const SizedBox(width: 8),
          Container(
            decoration: BoxDecoration(
              color: accentRed.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: accentRed),
            ),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: () => Navigator.pop(context, true),
              child: const Text("DELETE", style: TextStyle(color: Colors.white, fontSize: 14)),
            ),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      setState(() => isLoading = true);
      try {
        final response = await http.delete(
          Uri.parse("$apiBaseUrl/deleteSender?key=${widget.sessionKey}&id=$senderId"),
        );
        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          if (data["valid"] == true) {
            _showSnackBar("Sender deleted successfully!", isError: false);
            _fetchSenders();
          } else {
            _showSnackBar(data["message"] ?? "Failed to delete sender", isError: true);
          }
        } else {
          _showSnackBar("Server error: ${response.statusCode}", isError: true);
        }
      } catch (e) {
        _showSnackBar("Connection failed: $e", isError: true);
      } finally {
        setState(() => isLoading = false);
      }
    }
  }

  void _showSnackBar(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w500, fontSize: 14)),
        backgroundColor: isError ? accentRed : const Color(0xFF009944),
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Widget _buildSenderCard(Map<String, dynamic> sender, int index) {
    final name = sender['sessionName'] ?? 'WhatsApp Sender';
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: borderGlass),
        boxShadow: [
          BoxShadow(
            color: accentRed.withOpacity(0.12),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: primaryRed.withOpacity(0.2),
                  shape: BoxShape.circle,
                  border: Border.all(color: accentRed.withOpacity(0.3)),
                ),
                child: Icon(Icons.phone_android, color: accentRed, size: 22),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Text(
                  name,
                  style: TextStyle(color: primaryWhite, fontSize: 17, fontWeight: FontWeight.w600),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              const SizedBox(width: 12),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: accentRed.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: accentRed.withOpacity(0.4)),
                ),
                child: Text(
                  "CONNECTED",
                  style: TextStyle(color: lightRed, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 0.8),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  icon: Icon(Icons.refresh, size: 16, color: primaryWhite),
                  label: Text("REFRESH", style: TextStyle(color: primaryWhite, fontSize: 13)),
                  style: OutlinedButton.styleFrom(
                    backgroundColor: Colors.white.withOpacity(0.05),
                    side: BorderSide(color: borderGlass),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: () => _refreshSenders(),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: ElevatedButton.icon(
                  icon: Icon(Icons.delete_outline, size: 16, color: accentRed),
                  label: Text("DELETE", style: TextStyle(color: accentRed, fontSize: 13)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: accentRed.withOpacity(0.2),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: () => _deleteSender(sender['id']),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(28),
              decoration: BoxDecoration(
                color: primaryRed.withOpacity(0.12),
                shape: BoxShape.circle,
                border: Border.all(color: accentRed.withOpacity(0.35)),
              ),
              child: Icon(Icons.phone_iphone, color: accentRed, size: 72),
            ),
            const SizedBox(height: 26),
            Text(
              "No Senders Found",
              style: TextStyle(color: primaryWhite, fontSize: 21, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 14),
            Text(
              "Add your first WhatsApp sender to get started",
              style: TextStyle(color: Colors.white54, fontSize: 14, height: 1.5),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 36),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [primaryRed, accentRed]),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(color: accentRed.withOpacity(0.4), blurRadius: 16)
                ],
              ),
              child: ElevatedButton.icon(
                icon: const Icon(Icons.add, size: 20),
                label: const Text("ADD FIRST SENDER", style: TextStyle(fontWeight: FontWeight.w600)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                onPressed: _showAddSenderDialog,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, color: accentRed, size: 72),
            const SizedBox(height: 26),
            Text(
              "Failed to Load",
              style: TextStyle(color: primaryWhite, fontSize: 21, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 14),
            Text(
              errorMessage ?? "Unknown error occurred",
              style: TextStyle(color: Colors.white54, fontSize: 14, height: 1.5),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 36),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [primaryRed, accentRed]),
                borderRadius: BorderRadius.circular(16),
              ),
              child: ElevatedButton.icon(
                icon: const Icon(Icons.refresh, size: 20),
                label: const Text("TRY AGAIN", style: TextStyle(fontWeight: FontWeight.w600)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                onPressed: _fetchSenders,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        title: Text(
          "Manage Bug Sender",
          style: TextStyle(
            color: primaryWhite,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
            fontSize: 18,
            shadows: [
              Shadow(color: accentRed.withOpacity(0.7), blurRadius: 8)
            ],
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: accentRed, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh, color: accentRed, size: 22),
            onPressed: isLoading ? null : _refreshSenders,
          ),
          const SizedBox(width: 6),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              bgDark,
              primaryRed.withOpacity(0.07),
              bgDark,
            ],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.only(top: 8),
          child: isLoading && senderList.isEmpty
              ? Center(child: CircularProgressIndicator(color: accentRed, strokeWidth: 2.2))
              : errorMessage != null && senderList.isEmpty
              ? _buildErrorState()
              : senderList.isEmpty
              ? _buildEmptyState()
              : RefreshIndicator(
                  color: accentRed,
                  backgroundColor: cardGlass,
                  onRefresh: _refreshSenders,
                  child: ListView.builder(
                    physics: const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    itemCount: senderList.length,
                    itemBuilder: (context, index) => _buildSenderCard(
                      Map<String, dynamic>.from(senderList[index]),
                      index,
                    ),
                  ),
                ),
        ),
      ),
      floatingActionButton: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [primaryRed, accentRed]),
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(color: accentRed.withOpacity(0.4), blurRadius: 22, spreadRadius: 2)
          ],
        ),
        child: FloatingActionButton(
          onPressed: _showAddSenderDialog,
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: Icon(Icons.add, color: primaryWhite, size: 28),
        ),
      ),
    );
  }
}