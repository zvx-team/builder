// chess_game_page.dart - VERSION SUPER LENGKAP
// DENGAN TIMER 30 DETIK + ATURAN CATUR LENGKAP
import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;

enum GameMode {
  vsPlayer,
  vsBot,
}
// ========== CONSTANTS ==========
const String baseUrl = "http://senzpterodactpblc.senzhosting.my.id:10042";
const String wsUrl = "wss://senzpterodactpblc.senzhosting.my.id:10042";
const int TURN_TIME_LIMIT = 30; // 30 detik per giliran

// ========== MODEL CHESS ==========
enum PieceType { pawn, rook, knight, bishop, queen, king }
enum PieceColor { white, black }
enum GameStatus { waiting, playing, finished, abandoned }

class ChessPiece {
  final PieceType type;
  final PieceColor color;
  bool hasMoved;

  ChessPiece({required this.type, required this.color, this.hasMoved = false});

  // SIMBOL SEDERHANA
  String get symbol {
    if (color == PieceColor.white) {
      switch (type) {
        case PieceType.king: return '♔';
        case PieceType.queen: return '♕';
        case PieceType.rook: return '♖';
        case PieceType.bishop: return '♗';
        case PieceType.knight: return '♘';
        case PieceType.pawn: return '♙';
      }
    } else {
      switch (type) {
        case PieceType.king: return '♚';
        case PieceType.queen: return '♛';
        case PieceType.rook: return '♜';
        case PieceType.bishop: return '♝';
        case PieceType.knight: return '♞';
        case PieceType.pawn: return '♟';
      }
    }
  }

  // WARNA SOLID
  Color get pieceColor => color == PieceColor.white ? Colors.white : Colors.black87;
}

// ========== MOVE CLASS ==========
class ChessMove {
  final int fromRow;
  final int fromCol;
  final int toRow;
  final int toCol;
  final PieceType? promotion;

  ChessMove({
    required this.fromRow,
    required this.fromCol,
    required this.toRow,
    required this.toCol,
    this.promotion,
  });

  String get notation {
    String from = '${String.fromCharCode(97 + fromCol)}${8 - fromRow}';
    String to = '${String.fromCharCode(97 + toCol)}${8 - toRow}';
    return '$from → $to';
  }
}

// ========== PLAYER MODEL ==========
class Player {
  final String username;
  final String role;
  int wins;
  int losses;
  int draws;
  int rating;

  Player({
    required this.username,
    required this.role,
    this.wins = 0,
    this.losses = 0,
    this.draws = 0,
    this.rating = 1200,
  });

  int get totalGames => wins + losses + draws;
  double get winRate => totalGames > 0 ? (wins / totalGames * 100) : 0;

  factory Player.fromJson(Map<String, dynamic> json) {
    return Player(
      username: json['username'] ?? '',
      role: json['role'] ?? 'user',
      wins: json['wins'] ?? 0,
      losses: json['losses'] ?? 0,
      draws: json['draws'] ?? 0,
      rating: json['rating'] ?? 1200,
    );
  }
}

// ========== GAME MODEL ==========
class ChessGame {
  final String gameId;
  final String playerWhite;
  final String playerBlack;
  GameStatus status;
  String currentTurn;
  String? winner;
  DateTime createdAt;
  List<String> moveHistory;

  ChessGame({
    required this.gameId,
    required this.playerWhite,
    required this.playerBlack,
    required this.status,
    required this.currentTurn,
    this.winner,
    required this.createdAt,
    required this.moveHistory,
  });

  factory ChessGame.fromJson(Map<String, dynamic> json) {
    return ChessGame(
      gameId: json['gameId'] ?? '',
      playerWhite: json['playerWhite'] ?? '',
      playerBlack: json['playerBlack'] ?? '',
      status: _parseGameStatus(json['status']),
      currentTurn: json['currentTurn'] ?? 'white',
      winner: json['winner'],
      createdAt: DateTime.parse(json['createdAt'] ?? DateTime.now().toIso8601String()),
      moveHistory: List<String>.from(json['moveHistory'] ?? []),
    );
  }

  static GameStatus _parseGameStatus(String? status) {
    switch (status) {
      case 'waiting': return GameStatus.waiting;
      case 'playing': return GameStatus.playing;
      case 'finished': return GameStatus.finished;
      case 'abandoned': return GameStatus.abandoned;
      default: return GameStatus.waiting;
    }
  }
}

// ========== COLOR PALETTE ==========
class ChessColors {
  static const Color backgroundDark = Color(0xFF0B0F17);
  static const Color cardDark = Color(0xFF1A1F30);
  static const Color cardLight = Color(0xFF242A3A);
  
  static const Color purple = Color(0xFF9C27B0);
  static const Color blue = Color(0xFF2196F3);
  static const Color green = Color(0xFF4CAF50);
  static const Color red = Color(0xFFF44336);
  static const Color orange = Color(0xFFFF9800);
  static const Color gold = Color(0xFFFFD700);
  static const Color silver = Color(0xFF636361);
  static const Color bronze = Color(0xFF391F02);

  
  static const Color boardLight = Color(0xFFF0D9B5);
  static const Color boardDark = Color(0xFFB58863);
  static const Color boardLightSelected = Color(0xFFCDD16A);
  static const Color boardDarkSelected = Color(0xFFAA8C5A);
}

// ========== CHESS GAME PAGE ==========
class ChessGamePage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const ChessGamePage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<ChessGamePage> createState() => _ChessGamePageState();
}

class _ChessGamePageState extends State<ChessGamePage> with TickerProviderStateMixin {
  // ========== PAGE STATE ==========
  int _selectedTabIndex = 0;
  
  // ========== GAME STATE ==========
  GameMode? _selectedMode;
  String? _inviteCode;
  ChessGame? _currentGame;
  bool _isWaiting = false;
  bool _isMyTurn = false;
  PieceColor _myColor = PieceColor.white;
  WebSocketChannel? _channel;
  
  // ========== CHESS BOARD ==========
  List<List<ChessPiece?>> _board = List.generate(8, (_) => List.filled(8, null));
  int? _selectedRow;
  int? _selectedCol;
  List<ChessMove> _validMoves = [];
  
  // ========== GAME STATE TRACKING ==========
  int? _enPassantTargetRow;
  int? _enPassantTargetCol;
  bool _whiteKingMoved = false;
  bool _blackKingMoved = false;
  bool _whiteRookKingsideMoved = false;
  bool _whiteRookQueensideMoved = false;
  bool _blackRookKingsideMoved = false;
  bool _blackRookQueensideMoved = false;
  
  // ========== TIMER ==========
  Timer? _turnTimer;
  int _timeLeft = TURN_TIME_LIMIT;
  bool _timerRunning = false;
  double _timerProgress = 1.0;
  
  // ========== LEADERBOARD ==========
  List<Player> _leaderboard = [];
  bool _isLoadingLeaderboard = false;
  
  // ========== GAME HISTORY ==========
  List<ChessGame> _gameHistory = [];
  bool _isLoadingHistory = false;
  
  // ========== ANIMATION ==========
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _initializeBoard();
    _initializeAnimations();
    _fetchLeaderboard();
    _fetchGameHistory();
  }

  void _initializeAnimations() {
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    
    _pulseAnimation = Tween<double>(begin: 0.98, end: 1.02).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  void _initializeBoard() {
    // Empty board
    for (int i = 0; i < 8; i++) {
      for (int j = 0; j < 8; j++) {
        _board[i][j] = null;
      }
    }

    // Place pawns
    for (int i = 0; i < 8; i++) {
      _board[1][i] = ChessPiece(type: PieceType.pawn, color: PieceColor.black);
      _board[6][i] = ChessPiece(type: PieceType.pawn, color: PieceColor.white);
    }

    // Place rooks
    _board[0][0] = ChessPiece(type: PieceType.rook, color: PieceColor.black);
    _board[0][7] = ChessPiece(type: PieceType.rook, color: PieceColor.black);
    _board[7][0] = ChessPiece(type: PieceType.rook, color: PieceColor.white);
    _board[7][7] = ChessPiece(type: PieceType.rook, color: PieceColor.white);

    // Place knights
    _board[0][1] = ChessPiece(type: PieceType.knight, color: PieceColor.black);
    _board[0][6] = ChessPiece(type: PieceType.knight, color: PieceColor.black);
    _board[7][1] = ChessPiece(type: PieceType.knight, color: PieceColor.white);
    _board[7][6] = ChessPiece(type: PieceType.knight, color: PieceColor.white);

    // Place bishops
    _board[0][2] = ChessPiece(type: PieceType.bishop, color: PieceColor.black);
    _board[0][5] = ChessPiece(type: PieceType.bishop, color: PieceColor.black);
    _board[7][2] = ChessPiece(type: PieceType.bishop, color: PieceColor.white);
    _board[7][5] = ChessPiece(type: PieceType.bishop, color: PieceColor.white);

    // Place queens
    _board[0][3] = ChessPiece(type: PieceType.queen, color: PieceColor.black);
    _board[7][3] = ChessPiece(type: PieceType.queen, color: PieceColor.white);

    // Place kings
    _board[0][4] = ChessPiece(type: PieceType.king, color: PieceColor.black);
    _board[7][4] = ChessPiece(type: PieceType.king, color: PieceColor.white);
    
    // Reset tracking
    _enPassantTargetRow = null;
    _enPassantTargetCol = null;
    _whiteKingMoved = false;
    _blackKingMoved = false;
    _whiteRookKingsideMoved = false;
    _whiteRookQueensideMoved = false;
    _blackRookKingsideMoved = false;
    _blackRookQueensideMoved = false;
  }

  @override
  void dispose() {
    _stopTimer();
    _channel?.sink.close(status.goingAway);
    _pulseController.dispose();
    super.dispose();
  }

  // ========== TIMER FUNCTIONS ==========
  void _startTimer() {
    _stopTimer();
    setState(() {
      _timeLeft = TURN_TIME_LIMIT;
      _timerRunning = true;
      _timerProgress = 1.0;
    });
    
    final startTime = DateTime.now().millisecondsSinceEpoch;
    
    _turnTimer = Timer.periodic(const Duration(milliseconds: 100), (timer) {
      final elapsed = (DateTime.now().millisecondsSinceEpoch - startTime) / 1000;
      final remaining = TURN_TIME_LIMIT - elapsed;
      
      setState(() {
        _timeLeft = remaining > 0 ? remaining.toInt() : 0;
        _timerProgress = remaining / TURN_TIME_LIMIT;
      });
      
      if (remaining <= 0) {
        // WAKTU HABIS - OTOMATIS JALAN ATAU KALAH
        _stopTimer();
        _handleTimeout();
        timer.cancel();
      }
    });
  }

  void _stopTimer() {
    _turnTimer?.cancel();
    setState(() {
      _timerRunning = false;
    });
  }

  void _handleTimeout() {
    if (_selectedMode == GameMode.vsBot) {
      // Vs Bot: Giliran otomatis ke bot
      if (!_isMyTurn) {
        // Seharusnya giliran player, tapi player timeout -> bot jalan
        _botMove();
      } else {
        // Giliran bot, tapi bot timeout (jarang terjadi)
        _isMyTurn = true;
        _startTimer();
      }
    } else if (_selectedMode == GameMode.vsPlayer && _currentGame != null) {
      // Vs Player: Kirim timeout ke server
      _sendTimeout();
    }
  }

  // ========== AI BOT LOGIC (AGAK PINTER) ==========
  Future<void> _botMove() async {
    if (_selectedMode != GameMode.vsBot) return;
    if (_isMyTurn) return; // Bukan giliran bot
    
    // Kasih delay biar keliatan mikir
    await Future.delayed(const Duration(milliseconds: 500));
    
    // Koleksi semua piece bot (hitam)
    List<ChessMove> allMoves = [];
    
    for (int i = 0; i < 8; i++) {
      for (int j = 0; j < 8; j++) {
        final piece = _board[i][j];
        if (piece != null && piece.color == PieceColor.black) {
          final moves = _getValidMoves(i, j, isSimulation: true);
          allMoves.addAll(moves);
        }
      }
    }
    
    if (allMoves.isEmpty) {
      // Stalemate atau skakmat
      _checkGameOver();
      return;
    }
    
    // Prioritaskan gerakan yang:
    // 1. Makan piece putih (nilai tinggi)
    // 2. Skak
    // 3. Gerakan random
    
    // Hitung nilai setiap gerakan
    Map<ChessMove, int> moveScores = {};
    
    for (var move in allMoves) {
      int score = 0;
      
      // Simulasi gerakan
      final targetPiece = _board[move.toRow][move.toCol];
      
      // Makan piece musuh
      if (targetPiece != null) {
        switch (targetPiece.type) {
          case PieceType.queen: score += 90; break;
          case PieceType.rook: score += 50; break;
          case PieceType.bishop: score += 30; break;
          case PieceType.knight: score += 30; break;
          case PieceType.pawn: score += 10; break;
          case PieceType.king: score += 900; break; // Skakmat
        }
      }
      
      // Prioritaskan gerakan yang maju
      if (move.toRow > move.fromRow) score += 2;
      
      moveScores[move] = score;
    }
    
    // Sort by score
    allMoves.sort((a, b) => (moveScores[b] ?? 0).compareTo(moveScores[a] ?? 0));
    
    // Ambil 3 gerakan terbaik, lalu pilih random dari situ
    int topCount = min(3, allMoves.length);
    List<ChessMove> topMoves = allMoves.sublist(0, topCount);
    
    final selectedMove = topMoves[Random().nextInt(topMoves.length)];
    
    // Eksekusi gerakan
    _makeMove(selectedMove);
    
    // Setelah bot jalan, giliran player
    setState(() {
      _isMyTurn = true;
    });
    _startTimer();
    
    _checkGameOver();
  }

  // ========== VALIDASI GERAKAN (LENGKAP) ==========
  List<ChessMove> _getValidMoves(int row, int col, {bool isSimulation = false}) {
    final piece = _board[row][col];
    if (piece == null) return [];
    
    // Untuk non-simulasi, cek giliran
    if (!isSimulation) {
      if (_myColor != piece.color) return [];
      if (_selectedMode == GameMode.vsPlayer && !_isMyTurn) return [];
    }

    List<ChessMove> moves = [];

    switch (piece.type) {
      case PieceType.pawn:
        _addPawnMoves(row, col, piece, moves);
        break;
      case PieceType.knight:
        _addKnightMoves(row, col, piece, moves);
        break;
      case PieceType.bishop:
        _addLineMoves(row, col, piece, [
          [1, 1], [1, -1], [-1, 1], [-1, -1]
        ], moves);
        break;
      case PieceType.rook:
        _addLineMoves(row, col, piece, [
          [1, 0], [-1, 0], [0, 1], [0, -1]
        ], moves);
        break;
      case PieceType.queen:
        _addLineMoves(row, col, piece, [
          [1, 0], [-1, 0], [0, 1], [0, -1],
          [1, 1], [1, -1], [-1, 1], [-1, -1]
        ], moves);
        break;
      case PieceType.king:
        _addKingMoves(row, col, piece, moves);
        break;
    }

    // Filter gerakan yang membuat raja sendiri dalam bahaya
    if (!isSimulation) {
      moves.removeWhere((move) => _wouldBeInCheck(move, piece.color));
    }

    return moves;
  }

  void _addPawnMoves(int row, int col, ChessPiece piece, List<ChessMove> moves) {
    final direction = piece.color == PieceColor.white ? -1 : 1;
    final startRow = piece.color == PieceColor.white ? 6 : 1;
    final promotionRow = piece.color == PieceColor.white ? 0 : 7;

    // Maju 1
    if (_isInBoard(row + direction, col) && _board[row + direction][col] == null) {
      if (row + direction == promotionRow) {
        // Promosi jadi ratu (selalu ratu untuk sekarang)
        moves.add(ChessMove(
          fromRow: row, fromCol: col,
          toRow: row + direction, toCol: col,
          promotion: PieceType.queen,
        ));
      } else {
        moves.add(ChessMove(
          fromRow: row, fromCol: col,
          toRow: row + direction, toCol: col,
        ));
      }

      // Maju 2 dari awal
      if (row == startRow && 
          _board[row + 2 * direction][col] == null &&
          _board[row + direction][col] == null) {
        moves.add(ChessMove(
          fromRow: row, fromCol: col,
          toRow: row + 2 * direction, toCol: col,
        ));
      }
    }

    // Makan diagonal kiri
    if (_isInBoard(row + direction, col - 1)) {
      final target = _board[row + direction][col - 1];
      if (target != null && target.color != piece.color) {
        if (row + direction == promotionRow) {
          moves.add(ChessMove(
            fromRow: row, fromCol: col,
            toRow: row + direction, toCol: col - 1,
            promotion: PieceType.queen,
          ));
        } else {
          moves.add(ChessMove(
            fromRow: row, fromCol: col,
            toRow: row + direction, toCol: col - 1,
          ));
        }
      }
      
      // En passant kiri
      if (_enPassantTargetRow == row + direction && 
          _enPassantTargetCol == col - 1) {
        moves.add(ChessMove(
          fromRow: row, fromCol: col,
          toRow: row + direction, toCol: col - 1,
        ));
      }
    }

    // Makan diagonal kanan
    if (_isInBoard(row + direction, col + 1)) {
      final target = _board[row + direction][col + 1];
      if (target != null && target.color != piece.color) {
        if (row + direction == promotionRow) {
          moves.add(ChessMove(
            fromRow: row, fromCol: col,
            toRow: row + direction, toCol: col + 1,
            promotion: PieceType.queen,
          ));
        } else {
          moves.add(ChessMove(
            fromRow: row, fromCol: col,
            toRow: row + direction, toCol: col + 1,
          ));
        }
      }
      
      // En passant kanan
      if (_enPassantTargetRow == row + direction && 
          _enPassantTargetCol == col + 1) {
        moves.add(ChessMove(
          fromRow: row, fromCol: col,
          toRow: row + direction, toCol: col + 1,
        ));
      }
    }
  }

  void _addKnightMoves(int row, int col, ChessPiece piece, List<ChessMove> moves) {
    const knightMoves = [
      [-2, -1], [-2, 1], [-1, -2], [-1, 2],
      [1, -2], [1, 2], [2, -1], [2, 1]
    ];
    
    for (var move in knightMoves) {
      final newRow = row + move[0];
      final newCol = col + move[1];
      
      if (_isInBoard(newRow, newCol)) {
        final target = _board[newRow][newCol];
        if (target == null || target.color != piece.color) {
          moves.add(ChessMove(
            fromRow: row, fromCol: col,
            toRow: newRow, toCol: newCol,
          ));
        }
      }
    }
  }

  void _addLineMoves(int row, int col, ChessPiece piece, List<List<int>> directions, List<ChessMove> moves) {
    for (var dir in directions) {
      for (int i = 1; i < 8; i++) {
        final newRow = row + dir[0] * i;
        final newCol = col + dir[1] * i;
        
        if (!_isInBoard(newRow, newCol)) break;
        
        final target = _board[newRow][newCol];
        
        if (target == null) {
          moves.add(ChessMove(
            fromRow: row, fromCol: col,
            toRow: newRow, toCol: newCol,
          ));
        } else {
          if (target.color != piece.color) {
            moves.add(ChessMove(
              fromRow: row, fromCol: col,
              toRow: newRow, toCol: newCol,
            ));
          }
          break;
        }
      }
    }
  }

  void _addKingMoves(int row, int col, ChessPiece piece, List<ChessMove> moves) {
    for (int dr = -1; dr <= 1; dr++) {
      for (int dc = -1; dc <= 1; dc++) {
        if (dr == 0 && dc == 0) continue;
        
        final newRow = row + dr;
        final newCol = col + dc;
        
        if (_isInBoard(newRow, newCol)) {
          final target = _board[newRow][newCol];
          if (target == null || target.color != piece.color) {
            moves.add(ChessMove(
              fromRow: row, fromCol: col,
              toRow: newRow, toCol: newCol,
            ));
          }
        }
      }
    }
    
    // Castling
    _addCastlingMoves(row, col, piece, moves);
  }

  void _addCastlingMoves(int row, int col, ChessPiece piece, List<ChessMove> moves) {
    if (piece.hasMoved) return;
    
    if (piece.color == PieceColor.white) {
      if (_whiteKingMoved) return;
      
      // Kingside castling (0-0)
      if (!_whiteRookKingsideMoved &&
          _board[7][5] == null &&
          _board[7][6] == null &&
          !_isSquareAttacked(7, 4, PieceColor.black) &&
          !_isSquareAttacked(7, 5, PieceColor.black) &&
          !_isSquareAttacked(7, 6, PieceColor.black)) {
        moves.add(ChessMove(
          fromRow: 7, fromCol: 4,
          toRow: 7, toCol: 6,
        ));
      }
      
      // Queenside castling (0-0-0)
      if (!_whiteRookQueensideMoved &&
          _board[7][1] == null &&
          _board[7][2] == null &&
          _board[7][3] == null &&
          !_isSquareAttacked(7, 4, PieceColor.black) &&
          !_isSquareAttacked(7, 3, PieceColor.black) &&
          !_isSquareAttacked(7, 2, PieceColor.black)) {
        moves.add(ChessMove(
          fromRow: 7, fromCol: 4,
          toRow: 7, toCol: 2,
        ));
      }
    } else {
      if (_blackKingMoved) return;
      
      // Kingside castling (0-0)
      if (!_blackRookKingsideMoved &&
          _board[0][5] == null &&
          _board[0][6] == null &&
          !_isSquareAttacked(0, 4, PieceColor.white) &&
          !_isSquareAttacked(0, 5, PieceColor.white) &&
          !_isSquareAttacked(0, 6, PieceColor.white)) {
        moves.add(ChessMove(
          fromRow: 0, fromCol: 4,
          toRow: 0, toCol: 6,
        ));
      }
      
      // Queenside castling (0-0-0)
      if (!_blackRookQueensideMoved &&
          _board[0][1] == null &&
          _board[0][2] == null &&
          _board[0][3] == null &&
          !_isSquareAttacked(0, 4, PieceColor.white) &&
          !_isSquareAttacked(0, 3, PieceColor.white) &&
          !_isSquareAttacked(0, 2, PieceColor.white)) {
        moves.add(ChessMove(
          fromRow: 0, fromCol: 4,
          toRow: 0, toCol: 2,
        ));
      }
    }
  }

  bool _isSquareAttacked(int row, int col, PieceColor byColor) {
    // Cek apakah square diserang oleh byColor
    // Implementasi sederhana - akan dicek dari semua piece musuh
    
    for (int i = 0; i < 8; i++) {
      for (int j = 0; j < 8; j++) {
        final piece = _board[i][j];
        if (piece != null && piece.color == byColor) {
          final moves = _getValidMoves(i, j, isSimulation: true);
          for (var move in moves) {
            if (move.toRow == row && move.toCol == col) {
              return true;
            }
          }
        }
      }
    }
    return false;
  }

  bool _wouldBeInCheck(ChessMove move, PieceColor color) {
    // Simulasi gerakan
    final tempBoard = List.generate(8, (i) => List<ChessPiece?>.filled(8, null));
    for (int i = 0; i < 8; i++) {
      for (int j = 0; j < 8; j++) {
        if (_board[i][j] != null) {
          tempBoard[i][j] = ChessPiece(
            type: _board[i][j]!.type,
            color: _board[i][j]!.color,
            hasMoved: _board[i][j]!.hasMoved,
          );
        }
      }
    }
    
    // Lakukan gerakan di papan sementara
    final piece = tempBoard[move.fromRow][move.fromCol];
    tempBoard[move.toRow][move.toCol] = piece;
    tempBoard[move.fromRow][move.fromCol] = null;
    
    // Cari posisi raja
    int kingRow = -1, kingCol = -1;
    for (int i = 0; i < 8; i++) {
      for (int j = 0; j < 8; j++) {
        final p = tempBoard[i][j];
        if (p != null && p.type == PieceType.king && p.color == color) {
          kingRow = i;
          kingCol = j;
          break;
        }
      }
    }
    
    if (kingRow == -1) return true; // Raja hilang (skakmat)
    
    // Cek apakah raja diserang
    return _isSquareAttackedInBoard(tempBoard, kingRow, kingCol, 
        color == PieceColor.white ? PieceColor.black : PieceColor.white);
  }

  bool _isSquareAttackedInBoard(List<List<ChessPiece?>> board, int row, int col, PieceColor byColor) {
    for (int i = 0; i < 8; i++) {
      for (int j = 0; j < 8; j++) {
        final piece = board[i][j];
        if (piece != null && piece.color == byColor) {
          // Cek apakah piece ini bisa menyerang (row, col)
          if (_canPieceAttack(board, i, j, piece, row, col)) {
            return true;
          }
        }
      }
    }
    return false;
  }

  bool _canPieceAttack(List<List<ChessPiece?>> board, int fromRow, int fromCol, ChessPiece piece, int targetRow, int targetCol) {
    switch (piece.type) {
      case PieceType.pawn:
        int direction = piece.color == PieceColor.white ? -1 : 1;
        return (fromRow + direction == targetRow) && 
               ((fromCol - 1 == targetCol) || (fromCol + 1 == targetCol));
               
      case PieceType.knight:
        int dr = (targetRow - fromRow).abs();
        int dc = (targetCol - fromCol).abs();
        return (dr == 2 && dc == 1) || (dr == 1 && dc == 2);
        
      case PieceType.bishop:
        if ((targetRow - fromRow).abs() != (targetCol - fromCol).abs()) return false;
        return _isPathClear(board, fromRow, fromCol, targetRow, targetCol);
        
      case PieceType.rook:
        if (targetRow != fromRow && targetCol != fromCol) return false;
        return _isPathClear(board, fromRow, fromCol, targetRow, targetCol);
        
      case PieceType.queen:
        if ((targetRow - fromRow).abs() != (targetCol - fromCol).abs() && 
            targetRow != fromRow && targetCol != fromCol) return false;
        return _isPathClear(board, fromRow, fromCol, targetRow, targetCol);
        
      case PieceType.king:
        return (targetRow - fromRow).abs() <= 1 && (targetCol - fromCol).abs() <= 1;
    }
  }

  bool _isPathClear(List<List<ChessPiece?>> board, int fromRow, int fromCol, int toRow, int toCol) {
    int rowStep = (toRow - fromRow).sign;
    int colStep = (toCol - fromCol).sign;
    
    int currentRow = fromRow + rowStep;
    int currentCol = fromCol + colStep;
    
    while (currentRow != toRow || currentCol != toCol) {
      if (board[currentRow][currentCol] != null) return false;
      currentRow += rowStep;
      currentCol += colStep;
    }
    
    return true;
  }

  bool _isInBoard(int row, int col) => row >= 0 && row < 8 && col >= 0 && col < 8;

  // ========== EKSEKUSI GERAKAN ==========
  void _makeMove(ChessMove move) {
    final piece = _board[move.fromRow][move.fromCol];
    if (piece == null) return;
    
    // Catat en passant target sebelum gerakan
    int? oldEnPassantRow = _enPassantTargetRow;
    int? oldEnPassantCol = _enPassantTargetCol;
    _enPassantTargetRow = null;
    _enPassantTargetCol = null;
    
    // Handle en passant capture
    if (piece.type == PieceType.pawn) {
      if (move.toCol != move.fromCol && 
          _board[move.toRow][move.toCol] == null) {
        // En passant capture - hapus pawn yang di-skip
        _board[move.fromRow][move.toCol] = null;
      }
      
      // Set en passant target untuk double pawn move
      if ((move.toRow - move.fromRow).abs() == 2) {
        _enPassantTargetRow = (move.fromRow + move.toRow) ~/ 2;
        _enPassantTargetCol = move.fromCol;
      }
    }
    
    // Handle castling
    if (piece.type == PieceType.king && (move.toCol - move.fromCol).abs() == 2) {
      if (move.toCol == 6) { // Kingside
        _board[move.toRow][5] = _board[move.toRow][7];
        _board[move.toRow][7] = null;
        if (_board[move.toRow][5] != null) {
          _board[move.toRow][5]!.hasMoved = true;
        }
      } else if (move.toCol == 2) { // Queenside
        _board[move.toRow][3] = _board[move.toRow][0];
        _board[move.toRow][0] = null;
        if (_board[move.toRow][3] != null) {
          _board[move.toRow][3]!.hasMoved = true;
        }
      }
    }
    
    // Handle promosi
    if (move.promotion != null) {
      _board[move.toRow][move.toCol] = ChessPiece(
        type: move.promotion!,
        color: piece.color,
        hasMoved: true,
      );
      _board[move.fromRow][move.fromCol] = null;
    } else {
      // Gerakan biasa
      _board[move.toRow][move.toCol] = piece;
      _board[move.fromRow][move.fromCol] = null;
      piece.hasMoved = true;
    }
    
    // Update castling flags
    if (piece.type == PieceType.king) {
      if (piece.color == PieceColor.white) _whiteKingMoved = true;
      else _blackKingMoved = true;
    }
    
    if (piece.type == PieceType.rook) {
      if (piece.color == PieceColor.white) {
        if (move.fromRow == 7 && move.fromCol == 7) _whiteRookKingsideMoved = true;
        if (move.fromRow == 7 && move.fromCol == 0) _whiteRookQueensideMoved = true;
      } else {
        if (move.fromRow == 0 && move.fromCol == 7) _blackRookKingsideMoved = true;
        if (move.fromRow == 0 && move.fromCol == 0) _blackRookQueensideMoved = true;
      }
    }
    
    // Bersihkan seleksi
    setState(() {
      _selectedRow = null;
      _selectedCol = null;
      _validMoves.clear();
    });
    
    // Update history
    if (_currentGame != null) {
      _currentGame!.moveHistory.add(move.notation);
    }
  }

  void _handleSquareTap(int row, int col) {
    final piece = _board[row][col];
    
    // Pilih piece
    if (piece != null && piece.color == _myColor && 
        (_selectedMode != GameMode.vsPlayer || _isMyTurn)) {
      setState(() {
        _selectedRow = row;
        _selectedCol = col;
        _validMoves = _getValidMoves(row, col);
      });
      return;
    }
    
    // Coba gerakkan piece yang dipilih
    if (_selectedRow != null && _selectedCol != null) {
      for (var move in _validMoves) {
        if (move.toRow == row && move.toCol == col) {
          // Gerakan valid
          _makeMove(move);
          
          // Handle setelah gerakan
          if (_selectedMode == GameMode.vsPlayer && _currentGame != null) {
            _sendMove(move);
            _isMyTurn = false;
            _stopTimer();
          } else if (_selectedMode == GameMode.vsBot) {
            _isMyTurn = false;
            _stopTimer();
            Future.delayed(const Duration(milliseconds: 500), () {
              if (mounted) _botMove();
            });
          }
          
          _checkGameOver();
          return;
        }
      }
    }
  }

  void _checkGameOver() {
    // Cek apakah raja masih ada
    bool whiteKingFound = false;
    bool blackKingFound = false;
    
    for (int i = 0; i < 8; i++) {
      for (int j = 0; j < 8; j++) {
        final piece = _board[i][j];
        if (piece != null && piece.type == PieceType.king) {
          if (piece.color == PieceColor.white) whiteKingFound = true;
          else blackKingFound = true;
        }
      }
    }
    
    if (!whiteKingFound) {
      _showGameOverDialog('Hitam Menang! Raja Putih mati');
    } else if (!blackKingFound) {
      _showGameOverDialog('Putih Menang! Raja Hitam mati');
    } else {
      // Cek skakmat atau stalemate
      bool hasValidMoves = false;
      for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
          final piece = _board[i][j];
          if (piece != null && piece.color == (_isMyTurn ? _myColor : 
              (_myColor == PieceColor.white ? PieceColor.black : PieceColor.white))) {
            if (_getValidMoves(i, j, isSimulation: true).isNotEmpty) {
              hasValidMoves = true;
              break;
            }
          }
        }
        if (hasValidMoves) break;
      }
      
      if (!hasValidMoves) {
        // Cek apakah raja sedang dalam skak
        int kingRow = -1, kingCol = -1;
        PieceColor currentColor = _isMyTurn ? _myColor : 
            (_myColor == PieceColor.white ? PieceColor.black : PieceColor.white);
        
        for (int i = 0; i < 8; i++) {
          for (int j = 0; j < 8; j++) {
            final piece = _board[i][j];
            if (piece != null && piece.type == PieceType.king && piece.color == currentColor) {
              kingRow = i;
              kingCol = j;
              break;
            }
          }
        }
        
        if (kingRow != -1 && _isSquareAttacked(kingRow, kingCol, 
            currentColor == PieceColor.white ? PieceColor.black : PieceColor.white)) {
          _showGameOverDialog('${currentColor == PieceColor.white ? "Hitam" : "Putih"} Menang! Skakmat');
        } else {
          _showGameOverDialog('Stalemate! Game berakhir imbang');
        }
      }
    }
  }

  // ========== ONLINE FUNCTIONS ==========
  Future<void> _createOnlineGame() async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/chess/create'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username': widget.username,
          'sessionKey': widget.sessionKey,
        }),
      ).timeout(const Duration(seconds: 10));
      
      final data = jsonDecode(response.body);
      
      if (data['valid'] == true) {
        setState(() {
          _inviteCode = data['inviteCode'];
          _isWaiting = true;
          _myColor = PieceColor.white;
          _currentGame = ChessGame.fromJson(data['game']);
        });
        
        _connectToGame(data['gameId']);
        _showSnackBar('Kode Invite: ${data['inviteCode']}', isSuccess: true);
      } else {
        _showSnackBar(data['message'] ?? 'Gagal membuat game');
      }
    } catch (e) {
      _showSnackBar('Error: $e');
    }
  }

  Future<void> _joinOnlineGame(String code) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/chess/join'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username': widget.username,
          'sessionKey': widget.sessionKey,
          'inviteCode': code,
        }),
      ).timeout(const Duration(seconds: 10));
      
      final data = jsonDecode(response.body);
      
      if (data['valid'] == true) {
        setState(() {
          _inviteCode = code;
          _isWaiting = false;
          _myColor = PieceColor.black;
          _isMyTurn = false;
          _currentGame = ChessGame.fromJson(data['game']);
        });
        
        _connectToGame(data['gameId']);
        _showSnackBar('Bergabung ke game $code', isSuccess: true);
      } else {
        _showSnackBar(data['message'] ?? 'Gagal bergabung');
      }
    } catch (e) {
      _showSnackBar('Error: $e');
    }
  }

  void _connectToGame(String gameId) {
    try {
      _channel = WebSocketChannel.connect(Uri.parse(wsUrl));
      
      _channel!.sink.add(jsonEncode({
        'type': 'chess_join',
        'gameId': gameId,
        'username': widget.username,
        'sessionKey': widget.sessionKey,
      }));
      
      _channel!.stream.listen((message) {
        final data = jsonDecode(message);
        
        switch (data['type']) {
          case 'game_start':
            setState(() {
              _isWaiting = false;
              _isMyTurn = data['currentTurn'] == widget.username;
            });
            if (_isMyTurn) _startTimer();
            _showSnackBar('Game dimulai!', isSuccess: true);
            break;
            
          case 'opponent_move':
            _applyOpponentMove(data);
            break;
            
          case 'game_over':
            _handleGameOver(data);
            break;
            
          case 'opponent_left':
            _showSnackBar('Lawan meninggalkan game');
            _resetGame();
            break;
            
          case 'timeout':
            setState(() {
              _isMyTurn = true;
            });
            _startTimer();
            break;
        }
      }, onError: (error) {
        debugPrint('WebSocket error: $error');
      });
    } catch (e) {
      debugPrint('Connection error: $e');
    }
  }

  void _applyOpponentMove(Map<String, dynamic> data) {
    final move = ChessMove(
      fromRow: data['from'][0],
      fromCol: data['from'][1],
      toRow: data['to'][0],
      toCol: data['to'][1],
    );
    
    _makeMove(move);
    
    setState(() {
      _isMyTurn = true;
    });
    
    _startTimer();
    _checkGameOver();
  }

  void _handleGameOver(Map<String, dynamic> data) {
    _stopTimer();
    setState(() {
      _isMyTurn = false;
    });
    
    String message;
    if (data['winner'] == widget.username) {
      message = 'Selamat! Anda Menang! 🎉';
    } else if (data['winner'] == 'draw') {
      message = 'Game berakhir imbang';
    } else {
      message = 'Anda kalah. Coba lagi!';
    }
    
    _showGameOverDialog(message);
    _fetchLeaderboard();
    _fetchGameHistory();
  }

  void _sendMove(ChessMove move) {
    _channel?.sink.add(jsonEncode({
      'type': 'chess_move',
      'gameId': _currentGame?.gameId,
      'from': [move.fromRow, move.fromCol],
      'to': [move.toRow, move.toCol],
      'notation': move.notation,
    }));
  }

  void _sendTimeout() {
    _channel?.sink.add(jsonEncode({
      'type': 'chess_timeout',
      'gameId': _currentGame?.gameId,
      'username': widget.username,
    }));
  }

  // ========== FETCH DATA ==========
  Future<void> _fetchLeaderboard() async {
    setState(() => _isLoadingLeaderboard = true);
    
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/chess/leaderboard'),
      ).timeout(const Duration(seconds: 10));
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _leaderboard = (data['leaderboard'] as List)
                .map((e) => Player.fromJson(e))
                .toList();
          });
        }
      }
    } catch (e) {
      debugPrint('Error fetching leaderboard: $e');
    } finally {
      setState(() => _isLoadingLeaderboard = false);
    }
  }

  Future<void> _fetchGameHistory() async {
    setState(() => _isLoadingHistory = true);
    
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/chess/history?username=${widget.username}'),
      ).timeout(const Duration(seconds: 10));
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _gameHistory = (data['history'] as List)
                .map((e) => ChessGame.fromJson(e))
                .toList();
          });
        }
      }
    } catch (e) {
      debugPrint('Error fetching history: $e');
    } finally {
      setState(() => _isLoadingHistory = false);
    }
  }

  // ========== RESET GAME ==========
  void _resetGame() {
    _stopTimer();
    setState(() {
      _initializeBoard();
      _selectedMode = null;
      _inviteCode = null;
      _isWaiting = false;
      _isMyTurn = false;
      _myColor = PieceColor.white;
      _selectedRow = null;
      _selectedCol = null;
      _validMoves.clear();
      _currentGame = null;
      _timeLeft = TURN_TIME_LIMIT;
      _timerProgress = 1.0;
    });
    
    _channel?.sink.close(status.goingAway);
  }

  // ========== UI HELPERS ==========
  void _showSnackBar(String message, {bool isSuccess = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isSuccess ? Icons.check_circle : Icons.info,
              color: Colors.white,
              size: 20,
            ),
            const SizedBox(width: 12),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: isSuccess ? ChessColors.green : ChessColors.blue,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }

  void _showGameOverDialog(String message) {
    _stopTimer();
    
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: ChessColors.cardDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: ChessColors.green),
        ),
        title: const Text(
          'GAME OVER',
          style: TextStyle(
            color: ChessColors.green,
            fontWeight: FontWeight.bold,
          ),
        ),
        content: Text(
          message,
          style: const TextStyle(color: Colors.white, fontSize: 18),
        ),
        actions: [
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _resetGame();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: ChessColors.blue,
            ),
            child: const Text('MAIN LAGI'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() => _selectedTabIndex = 1);
            },
            child: const Text(
              'LEADERBOARD',
              style: TextStyle(color: ChessColors.blue),
            ),
          ),
        ],
      ),
    );
  }

  void _showJoinDialog() {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: ChessColors.cardDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        title: const Text(
          'MASUKKAN KODE',
          style: TextStyle(color: Colors.white),
        ),
        content: TextField(
          controller: controller,
          style: const TextStyle(color: Colors.white),
          textAlign: TextAlign.center,
          decoration: InputDecoration(
            hintText: 'CONTOH: ABC123',
            hintStyle: TextStyle(color: Colors.white.withOpacity(0.3)),
            filled: true,
            fillColor: ChessColors.cardLight,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none,
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('BATAL', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _joinOnlineGame(controller.text);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: ChessColors.blue,
            ),
            child: const Text('JOIN'),
          ),
        ],
      ),
    );
  }

  void _startVsBot() {
    setState(() {
      _selectedMode = GameMode.vsBot;
      _isMyTurn = true;
      _myColor = PieceColor.white;
    });
    _startTimer();
    _showSnackBar('Game vs Bot dimulai! (Putih jalan)', isSuccess: true);
  }

  // ========== BUILD ==========
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: ChessColors.backgroundDark,
        appBar: AppBar(
          backgroundColor: ChessColors.cardDark,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.pop(context),
          ),
          title: const Text(
            '♜ CHESS ARENA ♞',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          bottom: const TabBar(
            indicatorColor: ChessColors.blue,
            labelColor: ChessColors.blue,
            unselectedLabelColor: Colors.white54,
            tabs: [
              Tab(icon: Icon(Icons.grid_on), text: 'GAME'),
              Tab(icon: Icon(Icons.leaderboard), text: 'RANKING'),
              Tab(icon: Icon(Icons.history), text: 'HISTORY'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _selectedMode == null ? _buildModeSelection() : _buildGameBoard(),
            _buildLeaderboard(),
            _buildGameHistory(),
          ],
        ),
      ),
    );
  }

  // ========== MODE SELECTION ==========
  Widget _buildModeSelection() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          const SizedBox(height: 20),
          
          AnimatedBuilder(
            animation: _pulseAnimation,
            builder: (context, child) {
              return Transform.scale(
                scale: _pulseAnimation.value,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [ChessColors.purple, ChessColors.blue],
                    ),
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: const Text(
                    '♜ WELCOME TO CHESS ♞',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              );
            },
          ),
          
          const SizedBox(height: 40),
          
          _buildModeCard(
            icon: Icons.smart_toy,
            title: 'VS BOT',
            subtitle: 'Latihan melawan AI (Timer 30 detik)',
            color: ChessColors.blue,
            onTap: _startVsBot,
          ),
          
          const SizedBox(height: 20),
          
          _buildModeCard(
            icon: Icons.people,
            title: 'ONLINE PLAYER',
            subtitle: 'Bermain dengan pemain lain (Timer 30 detik)',
            color: ChessColors.green,
            onTap: () => setState(() => _selectedMode = GameMode.vsPlayer),
          ),
          
          const SizedBox(height: 30),
          
          if (_selectedMode == GameMode.vsPlayer) ...[
            _buildOnlineSection(),
          ],
        ],
      ),
    );
  }

  Widget _buildModeCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: ChessColors.cardDark,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color.withOpacity(0.5), width: 2),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: color.withOpacity(0.2),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Icon(icon, color: color, size: 30),
            ),
            const SizedBox(width: 20),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: color,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: const TextStyle(color: Colors.white70),
                  ),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios, color: color),
          ],
        ),
      ),
    );
  }

  Widget _buildOnlineSection() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: ChessColors.cardDark,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: ChessColors.green.withOpacity(0.5)),
      ),
      child: Column(
        children: [
          if (_inviteCode == null && !_isWaiting) ...[
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: _createOnlineGame,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: ChessColors.blue,
                      padding: const EdgeInsets.symmetric(vertical: 15),
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.add_link),
                        SizedBox(width: 8),
                        Text('BUAT GAME'),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: _showJoinDialog,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: ChessColors.green,
                      padding: const EdgeInsets.symmetric(vertical: 15),
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.login),
                        SizedBox(width: 8),
                        Text('GABUNG'),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ] else if (_isWaiting) ...[
            AnimatedBuilder(
              animation: _pulseAnimation,
              builder: (context, child) {
                return Column(
                  children: [
                    const Text(
                      'KODE INVITE:',
                      style: TextStyle(color: Colors.white70),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      _inviteCode!,
                      style: TextStyle(
                        color: ChessColors.green,
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 4,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 8,
                          height: 8,
                          decoration: BoxDecoration(
                            color: ChessColors.green,
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 8),
                        const Text(
                          'Menunggu lawan bergabung...',
                          style: TextStyle(color: Colors.white54),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    TextButton(
                      onPressed: _resetGame,
                      child: const Text(
                        'BATALKAN',
                        style: TextStyle(color: ChessColors.red),
                      ),
                    ),
                  ],
                );
              },
            ),
          ],
        ],
      ),
    );
  }

  // ========== GAME BOARD UI ==========
  Widget _buildGameBoard() {
    final bool isPlayerTurn = _isMyTurn && _selectedMode == GameMode.vsPlayer;
    final bool isBotGame = _selectedMode == GameMode.vsBot;
    final bool canMove = (isBotGame && _isMyTurn) || (isPlayerTurn);
    
    Color timerColor = _timerProgress > 0.5 
        ? ChessColors.green 
        : (_timerProgress > 0.2 ? ChessColors.orange : ChessColors.red);
    
    return Column(
      children: [
        // Timer Bar
        if (_timerRunning)
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: ChessColors.cardDark,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: timerColor),
            ),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'WAKTU GILIRAN',
                      style: TextStyle(color: timerColor, fontWeight: FontWeight.bold),
                    ),
                    Text(
                      '$_timeLeft detik',
                      style: TextStyle(
                        color: timerColor,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                LinearProgressIndicator(
                  value: _timerProgress,
                  backgroundColor: Colors.white12,
                  valueColor: AlwaysStoppedAnimation<Color>(timerColor),
                  minHeight: 8,
                  borderRadius: BorderRadius.circular(4),
                ),
              ],
            ),
          ),
        
        // Game Info
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16),
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
          decoration: BoxDecoration(
            color: ChessColors.cardDark,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: canMove ? ChessColors.green : ChessColors.red),
          ),
          child: Row(
            children: [
              Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  color: _myColor == PieceColor.white ? Colors.white : Colors.black,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  widget.username,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: canMove ? ChessColors.green.withOpacity(0.2) : ChessColors.red.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: canMove ? ChessColors.green : ChessColors.red),
                ),
                child: Text(
                  canMove ? 'GILIRAN ANDA' : (isBotGame ? 'BOT' : 'LAWAN'),
                  style: TextStyle(
                    color: canMove ? ChessColors.green : ChessColors.red,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),

        // Chess Board
        Expanded(
          child: Center(
            child: AspectRatio(
              aspectRatio: 1.0,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: ChessColors.green, width: 3),
                    boxShadow: [
                      BoxShadow(
                        color: ChessColors.green.withOpacity(0.3),
                        blurRadius: 20,
                        spreadRadius: 5,
                      ),
                    ],
                  ),
                  child: GridView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 8,
                    ),
                    itemCount: 64,
                    itemBuilder: (context, index) {
                      final row = index ~/ 8;
                      final col = index % 8;
                      final piece = _board[row][col];
                      final isSelected = _selectedRow == row && _selectedCol == col;
                      
                      bool isValidMove = false;
                      for (var move in _validMoves) {
                        if (move.toRow == row && move.toCol == col) {
                          isValidMove = true;
                          break;
                        }
                      }
                      
                      final isLightSquare = (row + col) % 2 == 0;
                      
                      Color squareColor;
                      if (isSelected) {
                        squareColor = isLightSquare 
                            ? ChessColors.boardLightSelected 
                            : ChessColors.boardDarkSelected;
                      } else if (isValidMove) {
                        squareColor = ChessColors.green.withOpacity(0.3);
                      } else {
                        squareColor = isLightSquare ? ChessColors.boardLight : ChessColors.boardDark;
                      }
                      
                      return GestureDetector(
                        onTap: () => _handleSquareTap(row, col),
                        child: Container(
                          color: squareColor,
                          child: Stack(
                            children: [
                              // Valid move dot
                              if (isValidMove && piece == null)
                                Center(
                                  child: Container(
                                    width: 12,
                                    height: 12,
                                    decoration: BoxDecoration(
                                      color: ChessColors.green,
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                ),
                              
                              // Piece
                              if (piece != null)
                                Center(
                                  child: Text(
                                    piece.symbol,
                                    style: TextStyle(
                                      fontSize: 32 + (isSelected ? 4 : 0),
                                      color: piece.pieceColor,
                                      shadows: [
                                        Shadow(
                                          color: piece.pieceColor == Colors.white
                                              ? Colors.black.withOpacity(0.5)
                                              : Colors.white.withOpacity(0.5),
                                          blurRadius: 3,
                                          offset: const Offset(1, 1),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
          ),
        ),

        // Move History
        Container(
          height: 60,
          margin: const EdgeInsets.all(16),
          padding: const EdgeInsets.symmetric(horizontal: 8),
          decoration: BoxDecoration(
            color: ChessColors.cardDark,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: ChessColors.green.withOpacity(0.3)),
          ),
          child: _currentGame?.moveHistory.isEmpty ?? true
              ? const Center(
                  child: Text(
                    'Belum ada langkah',
                    style: TextStyle(color: Colors.white54),
                  ),
                )
              : ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: _currentGame?.moveHistory.length ?? 0,
                  itemBuilder: (context, index) {
                    return Container(
                      margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 12),
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: index % 2 == 0 
                            ? ChessColors.blue.withOpacity(0.2)
                            : ChessColors.green.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: index % 2 == 0 ? ChessColors.blue : ChessColors.green,
                        ),
                      ),
                      child: Center(
                        child: Text(
                          '${index + 1}. ${_currentGame!.moveHistory[index]}',
                          style: const TextStyle(color: Colors.white, fontSize: 12),
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  // ========== LEADERBOARD UI ==========
  Widget _buildLeaderboard() {
    if (_isLoadingLeaderboard) {
      return const Center(child: CircularProgressIndicator(color: ChessColors.blue));
    }

    if (_leaderboard.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.emoji_events, size: 80, color: ChessColors.gold.withOpacity(0.3)),
            const SizedBox(height: 20),
            const Text(
              'Belum ada data leaderboard',
              style: TextStyle(color: Colors.white54, fontSize: 16),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _fetchLeaderboard,
              style: ElevatedButton.styleFrom(
                backgroundColor: ChessColors.blue,
              ),
              child: const Text('REFRESH'),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _leaderboard.length,
      itemBuilder: (context, index) {
        final player = _leaderboard[index];
        final isCurrentUser = player.username == widget.username;
        
        Color rankColor;
        IconData rankIcon;
        
        if (index == 0) {
          rankColor = ChessColors.gold;
          rankIcon = Icons.emoji_events;
        } else if (index == 1) {
          rankColor = ChessColors.silver;
          rankIcon = Icons.military_tech;
        } else if (index == 2) {
          rankColor = ChessColors.bronze;
          rankIcon = Icons.military_tech;
        } else {
          rankColor = ChessColors.blue;
          rankIcon = Icons.fiber_manual_record;
        }

        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: isCurrentUser ? ChessColors.blue.withOpacity(0.1) : ChessColors.cardDark,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: isCurrentUser ? ChessColors.blue : ChessColors.blue.withOpacity(0.3),
              width: isCurrentUser ? 2 : 1,
            ),
          ),
          child: Row(
            children: [
              // Rank
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: rankColor.withOpacity(0.2),
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: index < 3
                      ? Icon(rankIcon, color: rankColor, size: 20)
                      : Text(
                          '${index + 1}',
                          style: TextStyle(color: rankColor, fontWeight: FontWeight.bold),
                        ),
                ),
              ),
              
              const SizedBox(width: 16),
              
              // Player info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          player.username,
                          style: TextStyle(
                            color: isCurrentUser ? ChessColors.blue : Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        if (isCurrentUser) ...[
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: ChessColors.blue,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: const Text(
                              'ANDA',
                              style: TextStyle(color: Colors.white, fontSize: 8),
                            ),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: ChessColors.green.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text('${player.wins} W', style: const TextStyle(color: ChessColors.green)),
                        ),
                        const SizedBox(width: 4),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: ChessColors.red.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text('${player.losses} L', style: const TextStyle(color: ChessColors.red)),
                        ),
                        const SizedBox(width: 4),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: ChessColors.blue.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text('${player.draws} D', style: const TextStyle(color: ChessColors.blue)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              
              // Rating
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    '${player.rating}',
                    style: TextStyle(color: rankColor, fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    '${player.winRate.toStringAsFixed(1)}%',
                    style: const TextStyle(color: Colors.white54, fontSize: 11),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  // ========== GAME HISTORY UI ==========
  Widget _buildGameHistory() {
    if (_isLoadingHistory) {
      return const Center(child: CircularProgressIndicator(color: ChessColors.blue));
    }

    if (_gameHistory.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.history, size: 80, color: Colors.white.withOpacity(0.3)),
            const SizedBox(height: 20),
            const Text(
              'Belum ada riwayat game',
              style: TextStyle(color: Colors.white54, fontSize: 16),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _fetchGameHistory,
              style: ElevatedButton.styleFrom(
                backgroundColor: ChessColors.blue,
              ),
              child: const Text('REFRESH'),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _gameHistory.length,
      itemBuilder: (context, index) {
        final game = _gameHistory[index];
        
        final isWinner = game.winner == widget.username;
        final isDraw = game.winner == 'draw';
        
        Color resultColor;
        IconData resultIcon;
        String resultText;
        
        if (isDraw) {
          resultColor = ChessColors.blue;
          resultIcon = Icons.handshake;
          resultText = 'IMBANG';
        } else if (isWinner) {
          resultColor = ChessColors.green;
          resultIcon = Icons.emoji_events;
          resultText = 'MENANG';
        } else {
          resultColor = ChessColors.red;
          resultIcon = Icons.close;
          resultText = 'KALAH';
        }

        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: ChessColors.cardDark,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: resultColor.withOpacity(0.3)),
          ),
          child: Row(
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: resultColor.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(resultIcon, color: resultColor, size: 24),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          game.playerWhite,
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                        const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 8),
                          child: Text('vs', style: TextStyle(color: Colors.white54)),
                        ),
                        Text(
                          game.playerBlack,
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: resultColor.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text(resultText, style: TextStyle(color: resultColor, fontSize: 10)),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          '${game.moveHistory.length} langkah',
                          style: const TextStyle(color: Colors.white54, fontSize: 10),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Text(
                '${game.createdAt.day}/${game.createdAt.month}',
                style: const TextStyle(color: Colors.white54, fontSize: 12),
              ),
            ],
          ),
        );
      },
    );
  }
}