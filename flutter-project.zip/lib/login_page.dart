import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'splash.dart'; // Mengarah ke splash.dart bawaan proyek Anda

const String baseUrl = "http://arkzzxrizz.private.omdhancivok.my.id:2152";

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with SingleTickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool isLoading = false;
  bool _obscurePassword = true;
  String? androidId;

  late AnimationController _controller;
  late Animation<double> _fadeAnim;

  // --- TEMA NEW DARKVERSE / CYAN NEON ---
  final Color bgDark = const Color(0xFF050911);
  final Color surfaceDark = const Color(0xFF070D1A);
  final Color inputBg = const Color(0xFF091020);
  final Color inputBorder = const Color(0xFF162542);
  final Color accentCyan = const Color(0xFF00E5FF);
  final Color textMuted = const Color(0xFF475569);

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _fadeAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );
    _controller.forward();
    initLogin();
  }

  // Auto-login & Inisialisasi Android ID
  Future<void> initLogin() async {
    androidId = await getAndroidId();

    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null) {
      final uri = Uri.parse(
          "$baseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey");

      try {
        final res = await http.get(uri);
        final data = jsonDecode(res.body);

        if (data['valid'] == true) {
          if (mounted) {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (_) => SplashScreen(
                  username: savedUser,
                  password: savedPass,
                  role: data['role'],
                  sessionKey: data['key'],
                  expiredDate: data['expiredDate'],
                  listBug: (data['listBug'] as List? ?? [])
                      .map((e) => Map<String, dynamic>.from(e as Map))
                      .toList(),
                  listDoos: (data['listDDoS'] as List? ?? [])
                      .map((e) => Map<String, dynamic>.from(e as Map))
                      .toList(),
                  news: (data['news'] as List? ?? [])
                      .map((e) => Map<String, dynamic>.from(e as Map))
                      .toList(),
                ),
              ),
            );
          }
        }
      } catch (_) {}
    }
  }

  Future<String> getAndroidId() async {
    try {
      final deviceInfo = DeviceInfoPlugin();
      final android = await deviceInfo.androidInfo;
      return android.id;
    } catch (e) {
      return "unknown_device";
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    userController.dispose();
    passController.dispose();
    super.dispose();
  }

  // Fungsi untuk Membuka Telegram Buy Link
  Future<void> _launchTelegram() async {
    final Uri url = Uri.parse("https://t.me/Renkajpg");
    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    } else {
      _showCustomDialog(
        "Gagal Membuka Tautan",
        "Tidak dapat membuka Telegram. Silakan hubungi admin secara manual di @Renkajpg.",
        Colors.redAccent,
      );
    }
  }

  // Request Login ke API Server
  Future<void> login() async {
    if (!_formKey.currentState!.validate()) return;
    
    final username = userController.text.trim();
    final password = passController.text.trim();

    setState(() => isLoading = true);

    try {
      final response = await http.post(
        Uri.parse("$baseUrl/validate"),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId ?? "unknown_device",
        },
      ).timeout(const Duration(seconds: 10));

      final validData = jsonDecode(response.body);

      if (validData['expired'] == true) {
        _showCustomDialog(
          "Access Expired",
          "Masa akses Anda telah habis.\nSilakan perpanjang akses.",
          const Color(0xFFFF9800),
          showContact: true,
        );
      } else if (validData['valid'] != true) {
        final String errorMsg = (validData['message'] ?? "").toLowerCase();

        if (errorMsg.contains("perangkat") ||
            errorMsg.contains("device") ||
            errorMsg.contains("another")) {
          _showCustomDialog(
            "Sesi Aktif",
            "Akun ini sedang login di perangkat lain.\nSilakan logout terlebih dahulu di perangkat lama.",
            const Color(0xFFFF9800),
          );
        } else {
          _showCustomDialog(
            "Login Gagal",
            "Username atau password salah.",
            const Color(0xFFEF4444),
          );
        }
      } else {
        // Simpan sesi login lokal
        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", username);
        prefs.setString("password", password);
        prefs.setString("key", validData['key']);

        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => SplashScreen(
                username: username,
                password: password,
                role: validData['role'],
                sessionKey: validData['key'],
                expiredDate: validData['expiredDate'],
                listBug: (validData['listBug'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
                listDoos: (validData['listDDoS'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
                news: (validData['news'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
              ),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        _showCustomDialog(
          "Kesalahan Koneksi",
          "Gagal terhubung ke server.\nPeriksa koneksi internet Anda.",
          const Color(0xFFEF4444),
        );
      }
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  // AlertDialog Kustom Sesuai Mockup UI DarkVerse
  void _showCustomDialog(String title, String message, Color titleColor, {bool showContact = false}) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) {
        return FadeTransition(
          opacity: CurvedAnimation(
            parent: ModalRoute.of(context)!.animation!,
            curve: Curves.easeOut,
          ),
          child: AlertDialog(
            backgroundColor: const Color(0xFF091020),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
              side: BorderSide(color: inputBorder),
            ),
            title: Text(
              title,
              style: TextStyle(
                color: titleColor,
                fontWeight: FontWeight.bold,
                fontSize: 18,
                fontFamily: 'ShareTechMono',
              ),
            ),
            content: Text(
              message,
              style: const TextStyle(
                color: Color(0xFF94A3B8),
                fontSize: 13,
                height: 1.5,
              ),
            ),
            actions: [
              if (showContact)
                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                    _launchTelegram();
                  },
                  child: Text(
                    "Contact Admin",
                    style: TextStyle(
                      color: accentCyan,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text(
                  "Close",
                  style: TextStyle(color: textMuted),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnim,
          child: LayoutBuilder(
            builder: (context, constraints) {
              return SingleChildScrollView(
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    minHeight: constraints.maxHeight,
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 28.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        const SizedBox(height: 40),
                        
                        // --- AREA LOGO POLOS (assets/images/dnsrn.jpg) ---
                        Column(
                          children: [
                            Container(
                              width: 150,
                              height: 150,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(24),
                              ),
                              clipBehavior: Clip.antiAlias,
                              child: Image.asset(
                                "assets/images/dnsrn.jpg",
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) {
                                  // Fallback jika asset gambar lokal tidak ditemukan
                                  return Container(
                                    width: 150,
                                    height: 150,
                                    decoration: BoxDecoration(
                                      color: surfaceDark.withOpacity(0.8),
                                      border: Border.all(color: const Color(0xFF101B2F)),
                                      borderRadius: BorderRadius.circular(24),
                                    ),
                                    child: Icon(
                                      Icons.image_outlined,
                                      color: accentCyan,
                                      size: 52,
                                    ),
                                  );
                                },
                              ),
                            ),
                            const SizedBox(height: 35),
                            const Text(
                              "Welcome",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 28,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1.5,
                                fontFamily: 'ShareTechMono',
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              "Please sign in to continue",
                              style: TextStyle(
                                color: textMuted,
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                                letterSpacing: 1.5,
                                fontFamily: 'ShareTechMono',
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 25),

                        // --- FORM CONTAINER BOX ---
                        Form(
                          key: _formKey,
                          child: Container(
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: surfaceDark.withOpacity(0.6),
                              borderRadius: BorderRadius.circular(24),
                              border: Border.all(color: const Color(0xFF101B2F)),
                            ),
                            child: Column(
                              children: [
                                _buildTextField(
                                  controller: userController,
                                  hintText: "Username",
                                  icon: Icons.person_outline,
                                  obscure: false,
                                ),
                                const SizedBox(height: 16),
                                _buildTextField(
                                  controller: passController,
                                  hintText: "Password",
                                  icon: Icons.lock_outline,
                                  obscure: _obscurePassword,
                                  suffixIcon: IconButton(
                                    icon: Icon(
                                      _obscurePassword
                                          ? Icons.visibility_off_outlined
                                          : Icons.visibility_outlined,
                                      color: _obscurePassword ? textMuted : accentCyan,
                                      size: 20,
                                    ),
                                    onPressed: () {
                                      setState(() {
                                        _obscurePassword = !_obscurePassword;
                                      });
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),

                        // --- BUY ACCESS LINK ---
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 16.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                "No Access? ",
                                style: TextStyle(
                                  color: textMuted,
                                  fontSize: 12,
                                  fontFamily: 'ShareTechMono',
                                ),
                              ),
                              GestureDetector(
                                onTap: _launchTelegram,
                                child: const Text(
                                  "Buy here",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    decoration: TextDecoration.underline,
                                    fontFamily: 'ShareTechMono',
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),

                        // --- ACTION BUTTON & TERMS OF SERVICE ---
                        Column(
                          children: [
                            _buildLoginButton(),
                            const SizedBox(height: 24),
                            Text(
                              "By continuing, you agree to our Terms of Service",
                              style: TextStyle(
                                color: textMuted,
                                fontSize: 10,
                                fontFamily: 'ShareTechMono',
                                letterSpacing: 0.8,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  // Widget Pembantu untuk Text Field Input
  Widget _buildTextField({
    required TextEditingController controller,
    required String hintText,
    required IconData icon,
    required bool obscure,
    Widget? suffixIcon,
  }) {
    return Container(
      height: 52,
      decoration: BoxDecoration(
        color: inputBg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: inputBorder),
      ),
      child: TextFormField(
        controller: controller,
        obscureText: obscure,
        style: const TextStyle(color: Colors.white, fontSize: 14),
        cursorColor: accentCyan,
        validator: (value) {
          if (value == null || value.trim().isEmpty) {
            return ''; // Di-handle kosongnya agar tidak merusak tata letak
          }
          return null;
        },
        decoration: InputDecoration(
          hintText: hintText,
          hintStyle: TextStyle(color: textMuted, fontSize: 14, fontWeight: FontWeight.w500),
          prefixIcon: Icon(icon, color: textMuted, size: 20),
          suffixIcon: suffixIcon,
          border: InputBorder.none,
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: accentCyan, width: 1.5),
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
      ),
    );
  }

  // Widget Pembantu untuk Tombol Cyan Neon Glow
  Widget _buildLoginButton() {
    return Container(
      width: double.infinity,
      height: 52,
      decoration: BoxDecoration(
        color: accentCyan,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: accentCyan.withOpacity(0.35),
            blurRadius: 20,
            offset: const Offset(0, 0),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          onTap: isLoading ? null : login,
          borderRadius: BorderRadius.circular(16),
          child: Center(
            child: isLoading
                ? SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: bgDark,
                    ),
                  )
                : Text(
                    "Login",
                    style: TextStyle(
                      color: bgDark,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.0,
                    ),
                  ),
          ),
        ),
      ),
    );
  }
}