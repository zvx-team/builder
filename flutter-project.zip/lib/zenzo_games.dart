import 'package:flutter/material.dart';

class ZenzoGamesPage extends StatelessWidget {
  const ZenzoGamesPage({super.key});

  static const quotes = [
   "🔥 \"Jangan takut gagal, Sesungguhnya tidak ada kesuksesan tanpa ada kegagalan.\"",
   "🧸 \"jika keluarga mu tidak memiliki nama besar, buatlah sejarah itu atas namamu sendiri\"",
   "🌟 \"jangan berusaha lebih baik dari orang lain,tapi jadilah lebih baik dari dirimu yang kemarin\"",
   "🤲 \"Tuhan tidak berjanji hidupmu akan selalu mulus, tapi ✨ 'fa inna ma'al usri yusra' ✨\"",
   "💻 \"prestasi tidak menentukan mu sukses, tetapi sukses di tentukan oleh cara mu berproses\"",
   "🔥 \"Hidupmu bukan sekadar bertahan, tapi menaklukkan perkataan yang menyakitkan.\"",
   ];
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1A0D0D),
      appBar: AppBar(
       title: const Text("Nted Crasher Games 🎮",
        style: TextStyle(
         fontFamily: "Orbitron",
         fontSize: 18,
         fontWeight: FontWeight.bold,
         letterSpacing: 1.5,
         color: Colors.white,
        ),
      ),
      backgroundColor: const Color(0xFF8B0000),
    ),
      body: GridView.count(
        crossAxisCount: 2,
        padding: const EdgeInsets.all(16),
        children: [
          _buildAnimatedCard(
            icon: Icons.emoji_emotions,
            title: "Quotes",
            color: const Color(0xFFB22222),
             onTap: () {
              final randomQuote = (quotes..shuffle()).first;
              ScaffoldMessenger.of(context).showSnackBar(
               SnackBar(content: Text(randomQuote)),
               );
              },
            ),
          _buildAnimatedCard(
            icon: Icons.videogame_asset,
            title: "Guess Number",
            color: const Color(0xFF3C0A0A),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const GuessNumberGame()),
              );
            },
          ),
          _buildAnimatedCard(
            icon: Icons.mood,
            title: "Jokes",
            color: const Color(0xFF8B0000),
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("😂 Programmer suka kopi, karena tanpa Java mereka error!")),
              );
            },
          ),
          _buildAnimatedCard(
            icon: Icons.casino,
            title: "Randomizer",
            color: const Color(0xFF2B0D0D),
            onTap: () {
              final random = (1 + (DateTime.now().millisecond % 100));
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text("🎲 Angka acak: $random")),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildAnimatedCard({
    required IconData icon,
    required String title,
    required Color color,
    required VoidCallback onTap,
  }) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.9, end: 1.0),
      duration: const Duration(milliseconds: 500),
      curve: Curves.easeOutBack,
      builder: (context, scale, child) {
        return Transform.scale(
          scale: scale,
          child: child,
        );
      },
      child: Card(
        color: color,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, size: 48, color: Colors.white),
                const SizedBox(height: 8),
                Text(title,
                    style: const TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class GuessNumberGame extends StatefulWidget {
  const GuessNumberGame({super.key});

  @override
  State<GuessNumberGame> createState() => _GuessNumberGameState();
}

class _GuessNumberGameState extends State<GuessNumberGame> {
  final int secret = DateTime.now().second % 10 + 1;
  final TextEditingController controller = TextEditingController();
  String message = "Tebak angka 1-10";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1A0D0D),
      appBar: AppBar(
        title: const Text("Guess Number 🎮"),
        backgroundColor: const Color(0xFF8B0000),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text(message,
                style: const TextStyle(color: Colors.white, fontSize: 18)),
            TextField(
              controller: controller,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                hintText: "Masukkan angka",
                hintStyle: TextStyle(color: Colors.white54),
              ),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFB22222)),
              onPressed: () {
                final guess = int.tryParse(controller.text);
                if (guess == secret) {
                  setState(() => message = "🎉 Benar! Angkanya $secret");
                } else {
                  setState(() => message = "❌ Salah, coba lagi!");
                }
              },
              child: const Text("Cek"),
            )
          ],
        ),
      ),
    );
  }
}