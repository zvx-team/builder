// ignore_for_file: use_build_context_synchronously
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'theme_provider.dart';

// ═══════════════════════════════════════════════════════════════
//  AdminPage  –  Entry point, dispatch ke halaman per-role
//
//  Hierarki Role (tinggi → rendah):
//    developer > high owner > owner > high admin > admin > vip > reseller > member
//
//  Aturan buat akun (sesuai API permissionMap):
//    developer  → semua role
//    high admin → admin, high owner, owner, reseller, vip, member
//    admin      → high owner, owner, reseller, member
//    high owner → owner, reseller, member
//    owner      → reseller, member
//    reseller   → member
//    vip, member → tidak bisa buat akun
// ═══════════════════════════════════════════════════════════════

class AdminPage extends StatelessWidget {
  final String sessionKey;
  final String role;
  final List<String> creatableRoles;

  const AdminPage({
    super.key,
    required this.sessionKey,
    this.role = 'member',
    this.creatableRoles = const [],
  });

  // ── Warna per role ──────────────────────────────────────────
  static const Map<String, Color> roleColor = {
    'developer':  Color(0xFFFF5252), // Merah terang
    'high owner': Color(0xFFFF6D00), // Oranye
    'owner':      Color(0xFFE040FB), // Ungu
    'high admin': Color(0xFFFFAB40), // Amber
    'admin':      Color(0xFFFFD740), // Kuning
    'vip':        Color(0xFF69F0AE), // Hijau
    'reseller':   Color(0xFF448AFF), // Biru
    'member':     Color(0xFFD6D6D6), // Abu
  };

  // ── Icon per role ───────────────────────────────────────────
  static const Map<String, IconData> roleIcon = {
    'developer':  Icons.code_rounded,
    'high owner': Icons.diamond_outlined,
    'owner':      Icons.workspace_premium_rounded,
    'high admin': Icons.admin_panel_settings_rounded,
    'admin':      Icons.manage_accounts_rounded,
    'vip':        Icons.star_rounded,
    'reseller':   Icons.storefront_rounded,
    'member':     Icons.person_rounded,
  };

  // ── Deskripsi per role ──────────────────────────────────────
  static const Map<String, String> roleDesc = {
    'developer':  'Akses penuh semua fitur & semua role',
    'high owner': 'Akses penuh kecuali buat Developer',
    'owner':      'Bisa buat admin, reseller & member',
    'high admin': 'Bisa buat hampir semua role di bawah',
    'admin':      'Bisa buat owner, reseller & member',
    'vip':        'Akses fitur premium, tidak bisa buat akun',
    'reseller':   'Hanya bisa buat akun member',
    'member':     'User biasa',
  };

  // ── Role yang bisa dibuat — diambil dari API (creatableRoles)
  // Tidak lagi hardcode di sini

  // ── Label halaman per role ──────────────────────────────────
  static const Map<String, String> pageLabel = {
    'developer':  '⚡ DEVELOPER PAGE',
    'high owner': '💎 HIGH OWNER PAGE',
    'owner':      '👑 OWNER PAGE',
    'high admin': '🛡️ HIGH ADMIN PAGE',
    'admin':      '⚙️ ADMIN PAGE',
    'vip':        '⭐ VIP PAGE',
    'reseller':   '🏪 RESELLER PAGE',
    'member':     '👤 MEMBER PAGE',
  };

  @override
  Widget build(BuildContext context) {
    final r = role.toLowerCase() == 'dev' ? 'developer' : role.toLowerCase();
    // Gunakan creatableRoles dari API jika tersedia, fallback ke kosong
    final allowed = creatableRoles.isNotEmpty ? creatableRoles : <String>[];
    final accent = roleColor[r] ?? const Color(0xFFD6D6D6);
    final icon = roleIcon[r] ?? Icons.person_rounded;
    final label = pageLabel[r] ?? 'PANEL';
    final desc = roleDesc[r] ?? '';

    return _RolePage(
      sessionKey: sessionKey,
      currentRole: r,
      pageLabel: label,
      accent: accent,
      roleIcon: icon,
      roleDesc: desc,
      allowedRoles: allowed,
      roleColorMap: roleColor,
      roleIconMap: roleIcon,
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  _RolePage  –  UI utama
// ═══════════════════════════════════════════════════════════════

class _RolePage extends StatefulWidget {
  final String sessionKey;
  final String currentRole;
  final String pageLabel;
  final Color accent;
  final IconData roleIcon;
  final String roleDesc;
  final List<String> allowedRoles;
  final Map<String, Color> roleColorMap;
  final Map<String, IconData> roleIconMap;

  const _RolePage({
    required this.sessionKey,
    required this.currentRole,
    required this.pageLabel,
    required this.accent,
    required this.roleIcon,
    required this.roleDesc,
    required this.allowedRoles,
    required this.roleColorMap,
    required this.roleIconMap,
  });

  @override
  State<_RolePage> createState() => _RolePageState();
}

class _RolePageState extends State<_RolePage> with TickerProviderStateMixin {
  static const String _base = 'http://arullll.private-rexy.web.id:11235';

  late AnimationController _glowCtrl;
  late Animation<double> _glowAnim;
  late TabController _tabCtrl;

  // Form create
  final _usernameCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  final _dayCtrl      = TextEditingController();
  late String _newRole;
  bool _obscurePass = true;

  // User list
  List<dynamic> _fullList     = [];
  List<dynamic> _filteredList = [];
  String _filterRole          = 'semua';
  bool _isLoading = false;

  // Edit days
  final _addDaysCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();

    _glowCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))
      ..repeat(reverse: true);
    _glowAnim = Tween<double>(begin: 0.3, end: 1.0).animate(_glowCtrl);

    // Tab: 0=info, 1=create (jika punya izin), 2=user list
    final tabCount = widget.allowedRoles.isEmpty ? 2 : 3;
    _tabCtrl = TabController(length: tabCount, vsync: this);

    _newRole = widget.allowedRoles.isNotEmpty ? widget.allowedRoles.first : '';
    _fetchUsers();
  }

  @override
  void dispose() {
    _glowCtrl.dispose();
    _tabCtrl.dispose();
    _usernameCtrl.dispose();
    _passwordCtrl.dispose();
    _dayCtrl.dispose();
    _addDaysCtrl.dispose();
    super.dispose();
  }

  // ── API ──────────────────────────────────────────────────────

  Future<void> _fetchUsers() async {
    if (_isLoading) return;
    setState(() => _isLoading = true);
    try {
      final res = await http.get(Uri.parse('$_base/api/user/listUsers?key=${widget.sessionKey}'));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        _fullList = data['users'] ?? [];
        _applyFilter();
      }
    } catch (_) {
      _snack('Gagal memuat user list.', err: true);
    }
    setState(() => _isLoading = false);
  }

  void _applyFilter() {
    setState(() {
      if (_filterRole == 'semua') {
        // Tampilkan user yang rolenya ada di allowedRoles + role sendiri
        final visible = [...widget.allowedRoles, widget.currentRole];
        _filteredList = _fullList
            .where((u) => visible.contains((u['role'] ?? '').toString().toLowerCase()))
            .toList();
      } else {
        _filteredList = _fullList
            .where((u) => (u['role'] ?? '').toString().toLowerCase() == _filterRole)
            .toList();
      }
    });
  }

  Future<void> _createAccount() async {
    final username = _usernameCtrl.text.trim();
    final password = _passwordCtrl.text.trim();
    final day      = _dayCtrl.text.trim();
    if (username.isEmpty || password.isEmpty || day.isEmpty) {
      _snack('Semua field wajib diisi.', err: true);
      return;
    }
    setState(() => _isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          '$_base/api/user/userAdd?key=${widget.sessionKey}&username=$username&password=$password&role=$_newRole&day=$day'));
      final data = jsonDecode(res.body);
      if (data['created'] == true) {
        _snack("✅ Akun '$username' (${_newRole.toUpperCase()}) berhasil dibuat!");
        _usernameCtrl.clear();
        _passwordCtrl.clear();
        _dayCtrl.clear();
        setState(() => _newRole = widget.allowedRoles.first);
        _fetchUsers();
      } else {
        _snack(data['message'] ?? 'Gagal membuat akun.', err: true);
      }
    } catch (_) {
      _snack('Gagal menghubungi server.', err: true);
    }
    setState(() => _isLoading = false);
  }

  Future<void> _deleteUser(String username) async {
    setState(() => _isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          '$_base/api/user/deleteUser?key=${widget.sessionKey}&username=$username'));
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _snack("🗑️ User '$username' dihapus.");
        _fetchUsers();
      } else {
        _snack(data['message'] ?? 'Gagal menghapus.', err: true);
      }
    } catch (_) {
      _snack('Tidak dapat menghubungi server.', err: true);
    }
    setState(() => _isLoading = false);
  }

  Future<void> _editUser(String username) async {
    final days = _addDaysCtrl.text.trim();
    if (days.isEmpty) { _snack('Masukkan jumlah hari.', err: true); return; }
    setState(() => _isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          '$_base/api/user/editUser?key=${widget.sessionKey}&username=$username&addDays=$days'));
      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        _snack("✅ Masa aktif '$username' +$days hari");
        _addDaysCtrl.clear();
        Navigator.pop(context);
        _fetchUsers();
      } else {
        _snack(data['message'] ?? 'Gagal edit.', err: true);
      }
    } catch (_) {
      _snack('Error koneksi.', err: true);
    }
    setState(() => _isLoading = false);
  }

  // ── Helpers ──────────────────────────────────────────────────

  void _snack(String msg, {bool err = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 12)),
      backgroundColor: err ? Colors.red.shade900 : widget.accent.withOpacity(0.9),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      duration: const Duration(seconds: 3),
    ));
  }

  void _confirmDelete(String username) {
    final bg   = const Color(0xFF141414);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: bg,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: const Color(0x4CFFFFFF)),
        ),
        title: const Text('Hapus User', style: TextStyle(color: Colors.redAccent, fontFamily: 'Orbitron', fontSize: 14)),
        content: Text('Hapus akun "$username"?\nTindakan ini tidak dapat dibatalkan.',
            style: const TextStyle(color: Colors.white60, fontFamily: 'ShareTechMono', fontSize: 13)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context),
              child: const Text('Batal', style: TextStyle(color: Colors.white38))),
          TextButton(
            onPressed: () { Navigator.pop(context); _deleteUser(username); },
            child: const Text('Hapus', style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _showEditSheet(Map user) {
    final username = user['username'] ?? '';
    final roleColor = widget.roleColorMap[(user['role'] ?? '').toLowerCase()] ?? Colors.white;
    final bg = const Color(0xFF141414);

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: Container(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
            border: Border(top: BorderSide(color: widget.accent.withOpacity(0.3))),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(child: Container(width: 36, height: 4,
                  decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2)))),
              const SizedBox(height: 16),
              Row(children: [
                Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(color: roleColor.withOpacity(0.12), borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: roleColor.withOpacity(0.4))),
                  child: Text((user['role'] ?? '').toUpperCase(),
                      style: TextStyle(color: roleColor, fontFamily: 'Orbitron', fontSize: 10, fontWeight: FontWeight.bold))),
                const SizedBox(width: 10),
                Text(username.toUpperCase(), style: const TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 14, fontWeight: FontWeight.bold)),
              ]),
              const SizedBox(height: 6),
              Text('Expire: ${user['expiry'] ?? user['expiredDate'] ?? '-'}',
                  style: const TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 12)),
              const SizedBox(height: 16),
              TextField(
                controller: _addDaysCtrl,
                keyboardType: TextInputType.number,
                style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono'),
                cursorColor: widget.accent,
                decoration: InputDecoration(
                  hintText: 'Tambah berapa hari?',
                  hintStyle: const TextStyle(color: Colors.white30),
                  prefixIcon: Icon(Icons.add_circle_outline, color: widget.accent, size: 18),
                  filled: true, fillColor: const Color(0xFF0A0A0A),
                  enabledBorder: OutlineInputBorder(borderSide: const BorderSide(color: Colors.white12), borderRadius: BorderRadius.circular(10)),
                  focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: widget.accent.withOpacity(0.6)), borderRadius: BorderRadius.circular(10)),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton.icon(
                  onPressed: () => _editUser(username),
                  icon: const Icon(Icons.add, size: 16),
                  label: const Text('TAMBAH MASA AKTIF', style: TextStyle(fontFamily: 'Orbitron', fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: widget.accent, foregroundColor: const Color(0xFF0A0A0A),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), elevation: 0,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────
  //  BUILD
  // ─────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final bg   = const Color(0xFF0A0A0A);
    final card = const Color(0xFF141414);
    final hasBuat = widget.allowedRoles.isNotEmpty;

    return Scaffold(
      backgroundColor: bg,
      appBar: _buildAppBar(bg),
      body: Column(children: [
        _buildTabBar(hasBuat),
        Expanded(
          child: TabBarView(
            controller: _tabCtrl,
            children: [
              _buildInfoTab(bg, card),
              if (hasBuat) _buildCreateTab(bg, card),
              _buildUserListTab(bg, card),
            ],
          ),
        ),
      ]),
    );
  }

  // ── AppBar ────────────────────────────────────────────────────

  PreferredSizeWidget _buildAppBar(Color bg) {
    return AppBar(
      backgroundColor: bg,
      elevation: 0,
      leading: IconButton(
        icon: Icon(Icons.arrow_back_ios_new_rounded, color: widget.accent, size: 18),
        onPressed: () => Navigator.pop(context),
      ),
      title: Row(children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: widget.accent.withOpacity(0.15),
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: widget.accent.withOpacity(0.4)),
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(widget.roleIcon, color: widget.accent, size: 12),
            const SizedBox(width: 5),
            Text(widget.currentRole.toUpperCase(),
                style: TextStyle(color: widget.accent, fontSize: 9, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, letterSpacing: 1)),
          ]),
        ),
        const SizedBox(width: 10),
        Expanded(child: Text(widget.pageLabel,
            style: const TextStyle(color: Colors.white, fontSize: 12, fontFamily: 'Orbitron', fontWeight: FontWeight.bold),
            overflow: TextOverflow.ellipsis)),
      ]),
      actions: [
        IconButton(
          icon: Icon(Icons.refresh_rounded, color: widget.accent, size: 20),
          onPressed: _fetchUsers,
        ),
      ],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1),
        child: AnimatedBuilder(
          animation: _glowAnim,
          builder: (_, __) => Container(
            height: 1,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [
                Colors.transparent,
                widget.accent.withOpacity(_glowAnim.value * 0.5),
                Colors.transparent,
              ]),
            ),
          ),
        ),
      ),
    );
  }

  // ── TabBar ────────────────────────────────────────────────────

  Widget _buildTabBar(bool hasBuat) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: const Color(0xFF141414),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: widget.accent.withOpacity(0.15)),
      ),
      child: TabBar(
        controller: _tabCtrl,
        indicator: BoxDecoration(
          color: widget.accent.withOpacity(0.15),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: widget.accent.withOpacity(0.5)),
        ),
        indicatorSize: TabBarIndicatorSize.tab,
        dividerColor: Colors.transparent,
        labelColor: widget.accent,
        unselectedLabelColor: Colors.white30,
        labelStyle: const TextStyle(fontFamily: 'Orbitron', fontSize: 9, fontWeight: FontWeight.bold),
        unselectedLabelStyle: const TextStyle(fontFamily: 'Orbitron', fontSize: 9),
        tabs: [
          const Tab(icon: Icon(Icons.info_outline_rounded, size: 14), text: 'INFO'),
          if (hasBuat) const Tab(icon: Icon(Icons.person_add_alt_1_rounded, size: 14), text: 'BUAT AKUN'),
          const Tab(icon: Icon(Icons.group_rounded, size: 14), text: 'USER LIST'),
        ],
      ),
    );
  }

  // ── Tab 1: INFO ───────────────────────────────────────────────

  Widget _buildInfoTab(Color bg, Color card) {
    // Urutan hierarki semua role
    const hierarchy = [
      'developer', 'high owner', 'owner', 'high admin', 'admin', 'vip', 'reseller', 'member'
    ];

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const SizedBox(height: 6),

        // Banner role aktif
        AnimatedBuilder(
          animation: _glowAnim,
          builder: (_, __) => Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: card,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: widget.accent.withOpacity(0.3 + _glowAnim.value * 0.2)),
              boxShadow: [BoxShadow(color: widget.accent.withOpacity(_glowAnim.value * 0.12), blurRadius: 20)],
            ),
            child: Row(children: [
              Container(
                width: 56, height: 56,
                decoration: BoxDecoration(
                  color: widget.accent.withOpacity(0.15),
                  shape: BoxShape.circle,
                  border: Border.all(color: widget.accent.withOpacity(0.5), width: 2),
                ),
                child: Icon(widget.roleIcon, color: widget.accent, size: 26),
              ),
              const SizedBox(width: 16),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(widget.currentRole.toUpperCase(),
                    style: TextStyle(color: widget.accent, fontFamily: 'Orbitron', fontSize: 15, fontWeight: FontWeight.bold, letterSpacing: 1)),
                const SizedBox(height: 4),
                Text(widget.roleDesc,
                    style: const TextStyle(color: Colors.white54, fontFamily: 'ShareTechMono', fontSize: 11)),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(color: widget.accent.withOpacity(0.12), borderRadius: BorderRadius.circular(6)),
                  child: Text(
                    widget.allowedRoles.isEmpty
                        ? 'Tidak bisa buat akun'
                        : 'Bisa buat: ${widget.allowedRoles.length} role',
                    style: TextStyle(color: widget.accent.withOpacity(0.8), fontFamily: 'ShareTechMono', fontSize: 10),
                  ),
                ),
              ])),
            ]),
          ),
        ),
        const SizedBox(height: 20),

        // Hierarki semua role
        _sectionLabel('HIERARKI ROLE'),
        const SizedBox(height: 10),
        ...hierarchy.map((r) {
          final isMe = r == widget.currentRole;
          final canCreate = widget.allowedRoles.contains(r);
          final rColor = AdminPage.roleColor[r] ?? Colors.white;
          final rIcon  = AdminPage.roleIcon[r] ?? Icons.person_rounded;
          final rDesc  = AdminPage.roleDesc[r] ?? '';
          final level  = hierarchy.indexOf(r);

          return Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
            decoration: BoxDecoration(
              color: isMe ? rColor.withOpacity(0.12) : card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: isMe ? rColor.withOpacity(0.6) : rColor.withOpacity(0.1),
                width: isMe ? 1.5 : 1,
              ),
              boxShadow: isMe ? [BoxShadow(color: rColor.withOpacity(0.2), blurRadius: 10)] : null,
            ),
            child: Row(children: [
              // Level number
              Container(
                width: 24, height: 24,
                decoration: BoxDecoration(
                  color: rColor.withOpacity(0.15),
                  shape: BoxShape.circle,
                  border: Border.all(color: rColor.withOpacity(0.4)),
                ),
                child: Center(child: Text('${level + 1}',
                    style: TextStyle(color: rColor, fontFamily: 'Orbitron', fontSize: 9, fontWeight: FontWeight.bold))),
              ),
              const SizedBox(width: 10),
              Icon(rIcon, color: rColor, size: 16),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(r.toUpperCase(), style: TextStyle(color: isMe ? rColor : Colors.white70,
                    fontFamily: 'Orbitron', fontSize: 10, fontWeight: isMe ? FontWeight.bold : FontWeight.normal, letterSpacing: 0.5)),
                Text(rDesc, style: const TextStyle(color: Colors.white30, fontFamily: 'ShareTechMono', fontSize: 9)),
              ])),
              // Badge
              if (isMe)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(color: rColor.withOpacity(0.15), borderRadius: BorderRadius.circular(6)),
                  child: Text('KAMU', style: TextStyle(color: rColor, fontFamily: 'Orbitron', fontSize: 8, fontWeight: FontWeight.bold)),
                )
              else if (canCreate)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(color: const Color(0x0DFFFFFF), borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: Colors.white12)),
                  child: const Text('BISA BUAT', style: TextStyle(color: Colors.white30, fontFamily: 'Orbitron', fontSize: 7)),
                ),
            ]),
          );
        }),
      ]),
    );
  }

  // ── Tab 2: CREATE ACCOUNT ─────────────────────────────────────

  Widget _buildCreateTab(Color bg, Color card) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const SizedBox(height: 6),

        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: card,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: widget.accent.withOpacity(0.2)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Icon(Icons.person_add_alt_1_rounded, color: widget.accent, size: 18),
              const SizedBox(width: 8),
              Text('CREATE ACCOUNT', style: TextStyle(color: widget.accent, fontFamily: 'Orbitron',
                  fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
            ]),
            const SizedBox(height: 6),
            Text('Kamu bisa membuat role: ${widget.allowedRoles.map((r) => r.toUpperCase()).join(", ")}',
                style: const TextStyle(color: Colors.white30, fontFamily: 'ShareTechMono', fontSize: 10)),
            const SizedBox(height: 18),

            // Username
            _inputField(ctrl: _usernameCtrl, label: 'Username', icon: Icons.person_outline),
            const SizedBox(height: 12),

            // Password
            _inputField(
              ctrl: _passwordCtrl, label: 'Password', icon: Icons.lock_outline, obscure: _obscurePass,
              suffix: IconButton(
                icon: Icon(_obscurePass ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                    color: Colors.white30, size: 18),
                onPressed: () => setState(() => _obscurePass = !_obscurePass),
              ),
            ),
            const SizedBox(height: 12),

            // Durasi
            _inputField(ctrl: _dayCtrl, label: 'Durasi (Hari)', icon: Icons.calendar_month_outlined,
                keyboardType: TextInputType.number),
            const SizedBox(height: 12),

            // Role selector visual
            _sectionLabel('PILIH ROLE'),
            const SizedBox(height: 8),
            _buildRoleSelector(),
            const SizedBox(height: 18),

            // Button
            AnimatedBuilder(
              animation: _glowAnim,
              builder: (_, __) => Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [BoxShadow(color: widget.accent.withOpacity(_glowAnim.value * 0.4), blurRadius: 16)],
                ),
                child: SizedBox(
                  width: double.infinity, height: 50,
                  child: ElevatedButton.icon(
                    onPressed: _isLoading ? null : _createAccount,
                    icon: _isLoading
                        ? SizedBox(width: 15, height: 15, child: CircularProgressIndicator(color: bg, strokeWidth: 2))
                        : const Icon(Icons.person_add_rounded, size: 16),
                    label: Text(_isLoading ? 'MEMBUAT...' : 'CREATE ACCOUNT',
                        style: const TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 12, letterSpacing: 1.2)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: widget.accent, foregroundColor: bg,
                      disabledBackgroundColor: widget.accent.withOpacity(0.2),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), elevation: 0,
                    ),
                  ),
                ),
              ),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _buildRoleSelector() {
    return Column(
      children: widget.allowedRoles.map((r) {
        final isSelected = _newRole == r;
        final rColor = widget.roleColorMap[r] ?? Colors.white;
        final rIcon  = widget.roleIconMap[r] ?? Icons.person_rounded;
        final rDesc  = AdminPage.roleDesc[r] ?? '';
        return GestureDetector(
          onTap: () => setState(() => _newRole = r),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
            decoration: BoxDecoration(
              color: isSelected ? rColor.withOpacity(0.12) : const Color(0xFF0A0A0A),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: isSelected ? rColor.withOpacity(0.6) : Colors.white12),
              boxShadow: isSelected ? [BoxShadow(color: rColor.withOpacity(0.2), blurRadius: 10)] : null,
            ),
            child: Row(children: [
              Icon(isSelected ? Icons.radio_button_checked : Icons.radio_button_unchecked,
                  color: isSelected ? rColor : Colors.white24, size: 16),
              const SizedBox(width: 10),
              Icon(rIcon, color: rColor, size: 15),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(r.toUpperCase(), style: TextStyle(color: isSelected ? rColor : Colors.white70,
                    fontFamily: 'Orbitron', fontSize: 10, fontWeight: isSelected ? FontWeight.bold : FontWeight.normal)),
                Text(rDesc, style: const TextStyle(color: Colors.white30, fontFamily: 'ShareTechMono', fontSize: 9)),
              ])),
              if (isSelected)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(color: rColor.withOpacity(0.15), borderRadius: BorderRadius.circular(6)),
                  child: Text('DIPILIH', style: TextStyle(color: rColor, fontFamily: 'Orbitron', fontSize: 8, fontWeight: FontWeight.bold)),
                ),
            ]),
          ),
        );
      }).toList(),
    );
  }

  // ── Tab 3: USER LIST ──────────────────────────────────────────

  Widget _buildUserListTab(Color bg, Color card) {
    final filterOptions = ['semua', ...widget.allowedRoles];
    return _isLoading
        ? Center(child: CircularProgressIndicator(color: widget.accent, strokeWidth: 2))
        : SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const SizedBox(height: 6),
              // Header count
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Row(children: [
                  Icon(Icons.group_rounded, color: widget.accent, size: 18),
                  const SizedBox(width: 8),
                  Text('USER LIST', style: TextStyle(color: widget.accent, fontFamily: 'Orbitron',
                      fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
                ]),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.white12)),
                  child: Text('${_filteredList.length} user',
                      style: const TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 11)),
                ),
              ]),
              const SizedBox(height: 12),

              // Filter chips
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: filterOptions.map((r) {
                    final isSelected = _filterRole == r;
                    final chipColor = r == 'semua' ? widget.accent : (widget.roleColorMap[r] ?? Colors.white);
                    return Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: GestureDetector(
                        onTap: () { setState(() => _filterRole = r); _applyFilter(); },
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 180),
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                          decoration: BoxDecoration(
                            color: isSelected ? chipColor.withOpacity(0.15) : Colors.transparent,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: isSelected ? chipColor.withOpacity(0.7) : Colors.white12,
                                width: isSelected ? 1.5 : 1),
                          ),
                          child: Text(r == 'semua' ? 'Semua' : r.toUpperCase(),
                              style: TextStyle(color: isSelected ? chipColor : Colors.white30, fontSize: 10,
                                  fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                                  fontFamily: 'ShareTechMono')),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
              const SizedBox(height: 12),

              // List
              Container(
                decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: widget.accent.withOpacity(0.15))),
                child: _filteredList.isEmpty
                    ? Padding(
                        padding: const EdgeInsets.all(32),
                        child: Center(child: Text('Tidak ada user.',
                            style: const TextStyle(color: Colors.white24, fontFamily: 'ShareTechMono', fontSize: 12))),
                      )
                    : ListView.separated(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: _filteredList.length,
                        separatorBuilder: (_, __) => Divider(color: const Color(0x0DFFFFFF), height: 1),
                        itemBuilder: (_, i) => _buildUserTile(_filteredList[i]),
                      ),
              ),
            ]),
          );
  }

  Widget _buildUserTile(dynamic user) {
    final username  = (user['username'] ?? 'N/A').toString();
    final role      = (user['role'] ?? 'member').toString().toLowerCase();
    final expiry    = (user['expiryDate'] ?? user['expiredDate'] ?? '-').toString();
    final parent    = (user['parent'] ?? 'SYSTEM').toString();
    final initial   = username.isNotEmpty ? username[0].toUpperCase() : '?';
    final roleColor = widget.roleColorMap[role] ?? const Color(0xFFD6D6D6);
    final rIcon     = widget.roleIconMap[role] ?? Icons.person_rounded;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      child: Row(children: [
        // Avatar
        Container(
          width: 44, height: 44,
          decoration: BoxDecoration(shape: BoxShape.circle,
            color: roleColor.withOpacity(0.12), border: Border.all(color: roleColor.withOpacity(0.35), width: 1.5)),
          child: Center(child: Text(initial,
              style: TextStyle(color: roleColor, fontWeight: FontWeight.bold, fontSize: 16, fontFamily: 'Orbitron'))),
        ),
        const SizedBox(width: 12),
        // Info
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(username.toUpperCase(),
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13,
                  fontFamily: 'Orbitron', letterSpacing: 0.5)),
          const SizedBox(height: 4),
          Row(children: [
            // Role badge
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
              decoration: BoxDecoration(color: roleColor.withOpacity(0.12), borderRadius: BorderRadius.circular(4),
                  border: Border.all(color: roleColor.withOpacity(0.4))),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(rIcon, color: roleColor, size: 9),
                const SizedBox(width: 4),
                Text(role.toUpperCase(),
                    style: TextStyle(color: roleColor, fontSize: 8, fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron', letterSpacing: 0.5)),
              ]),
            ),
            const SizedBox(width: 8),
            Icon(Icons.calendar_today_outlined, size: 10, color: Colors.white24),
            const SizedBox(width: 3),
            Text(expiry, style: const TextStyle(color: Colors.white38, fontSize: 10, fontFamily: 'ShareTechMono')),
          ]),
          const SizedBox(height: 2),
          Text('by: $parent', style: const TextStyle(color: Colors.white24, fontSize: 9, fontFamily: 'ShareTechMono')),
        ])),
        // Actions
        Row(mainAxisSize: MainAxisSize.min, children: [
          IconButton(icon: Icon(Icons.add_circle_outline, color: widget.accent, size: 18),
              tooltip: 'Tambah hari', onPressed: () => _showEditSheet(user)),
          IconButton(icon: const Icon(Icons.delete_outline_rounded, color: Colors.redAccent, size: 18),
              tooltip: 'Hapus user', onPressed: () => _confirmDelete(username)),
        ]),
      ]),
    );
  }

  // ── Shared ────────────────────────────────────────────────────

  Widget _sectionLabel(String text) => Text(text,
      style: TextStyle(color: widget.accent.withOpacity(0.5), fontFamily: 'Orbitron', fontSize: 9, letterSpacing: 2));

  Widget _inputField({
    required TextEditingController ctrl,
    required String label,
    required IconData icon,
    bool obscure = false,
    TextInputType? keyboardType,
    Widget? suffix,
  }) {
    return TextField(
      controller: ctrl,
      obscureText: obscure,
      keyboardType: keyboardType,
      style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 14),
      cursorColor: widget.accent,
      decoration: InputDecoration(
        hintText: label,
        hintStyle: const TextStyle(color: Colors.white30, fontSize: 13),
        prefixIcon: Icon(icon, color: Colors.white30, size: 18),
        suffixIcon: suffix,
        filled: true, fillColor: const Color(0xFF0A0A0A),
        enabledBorder: OutlineInputBorder(borderSide: const BorderSide(color: Colors.white12), borderRadius: BorderRadius.circular(10)),
        focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: widget.accent.withOpacity(0.6), width: 1.5), borderRadius: BorderRadius.circular(10)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
    );
  }
}
