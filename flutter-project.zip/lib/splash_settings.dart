// ignore_for_file: use_build_context_synchronously
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

// ─────────────────────────────────────────────────────────────
//  SplashSettings  –  Kelola konfigurasi splash custom
// ─────────────────────────────────────────────────────────────

class SplashSettings {
  static const _keyCustomEnabled = 'splash_custom_enabled';
  static const _keyVideoPath = 'splash_video_path';
  static const _keyStyle = 'splash_style'; // 'default', 'cyberpunk', 'anime', 'minimal'
  static const _keyTitle = 'splash_title';
  static const _keySubtitle = 'splash_subtitle';
  static const _keyAccentHex = 'splash_accent_hex';

  static Future<bool> isCustomEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_keyCustomEnabled) ?? false;
  }

  static Future<String> getStyle() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyStyle) ?? 'default';
  }

  static Future<String> getTitle() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyTitle) ?? 'RDP V1';
  }

  static Future<String> getSubtitle() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keySubtitle) ?? 'hi i"m rdp v1 by @maulkoncet';
  }

  static Future<String> getAccentHex() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyAccentHex) ?? 'FFFFFF';
  }

  static Future<String> getVideoPath() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyVideoPath) ?? '';
  }

  static Future<void> save({
    required bool customEnabled,
    required String style,
    required String title,
    required String subtitle,
    required String accentHex,
    String? videoPath,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyCustomEnabled, customEnabled);
    await prefs.setString(_keyStyle, style);
    await prefs.setString(_keyTitle, title);
    await prefs.setString(_keySubtitle, subtitle);
    await prefs.setString(_keyAccentHex, accentHex);
    if (videoPath != null) await prefs.setString(_keyVideoPath, videoPath);
  }
}

// ─────────────────────────────────────────────────────────────
//  CustomSplashPage  –  Splash screen dengan style yang bisa 
//  dikustomisasi dari SplashSettings
// ─────────────────────────────────────────────────────────────

class CustomSplashPage extends StatefulWidget {
  final Map<String, dynamic> data;
  final Widget Function(Map<String, dynamic> data) onFinish;

  const CustomSplashPage({
    super.key,
    required this.data,
    required this.onFinish,
  });

  @override
  State<CustomSplashPage> createState() => _CustomSplashPageState();
}

class _CustomSplashPageState extends State<CustomSplashPage>
    with SingleTickerProviderStateMixin {
  VideoPlayerController? _videoCtrl;
  bool _videoReady = false;
  String _style = 'default';
  String _title = 'RDP V1';
  String _subtitle = 'hi i"m rdp v1 by @maulkoncet';
  Color _accent = Colors.white;
  String _videoPath = '';
  late AnimationController _animCtrl;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    );
    _fadeAnim = CurvedAnimation(parent: _animCtrl, curve: Curves.easeIn);
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    _style = await SplashSettings.getStyle();
    _title = await SplashSettings.getTitle();
    _subtitle = await SplashSettings.getSubtitle();
    final hex = await SplashSettings.getAccentHex();
    _accent = _hexToColor(hex);
    _videoPath = await SplashSettings.getVideoPath();

    if (_videoPath.isNotEmpty && File(_videoPath).existsSync()) {
      _videoCtrl = VideoPlayerController.file(File(_videoPath))
        ..initialize().then((_) {
          if (mounted) {
            setState(() { _videoReady = true; });
            _videoCtrl?.setLooping(false);
            _videoCtrl?.play();
            _animCtrl.forward();
            _videoCtrl?.addListener(_checkVideoEnd);
          }
        });
    } else {
      // Gunakan asset default
      _videoCtrl = VideoPlayerController.asset('assets/videos/load.mp4')
        ..initialize().then((_) {
          if (mounted) {
            setState(() { _videoReady = true; });
            _videoCtrl?.play();
            _animCtrl.forward();
            _videoCtrl?.addListener(_checkVideoEnd);
          }
        });
    }
  }

  void _checkVideoEnd() {
    final c = _videoCtrl;
    if (c == null) return;
    if (c.value.isInitialized &&
        c.value.position >= c.value.duration - const Duration(milliseconds: 200)) {
      _finish();
    }
  }

  void _finish() {
    if (!mounted) return;
    _videoCtrl?.removeListener(_checkVideoEnd);
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => widget.onFinish(widget.data)),
    );
  }

  Color _hexToColor(String hex) {
    try {
      final clean = hex.replaceAll('#', '');
      return Color(int.parse('FF$clean', radix: 16));
    } catch (_) {
      return Colors.white;
    }
  }

  @override
  void dispose() {
    _videoCtrl?.dispose();
    _animCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Video layer
          if (_videoReady && _videoCtrl != null)
            FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _videoCtrl!.value.size.width,
                height: _videoCtrl!.value.size.height,
                child: VideoPlayer(_videoCtrl!),
              ),
            )
          else
            Container(color: Colors.black),

          // Style overlay
          _buildStyleOverlay(),

          // Title + subtitle
          FadeTransition(
            opacity: _fadeAnim,
            child: Positioned(
              bottom: 80,
              left: 0,
              right: 0,
              child: _buildTitleSection(),
            ),
          ),

          // Skip button
          Positioned(
            top: 50,
            right: 25,
            child: GestureDetector(
              onTap: _finish,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: Colors.white24),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('SKIP', style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold,
                      fontSize: 12, letterSpacing: 1.5,
                    )),
                    SizedBox(width: 5),
                    Icon(Icons.arrow_forward_ios_rounded, color: Colors.white, size: 12),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStyleOverlay() {
    switch (_style) {
      case 'cyberpunk':
        return Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                _accent.withOpacity(0.05),
                Colors.black.withOpacity(0.6),
                Colors.purple.withOpacity(0.1),
              ],
            ),
          ),
        );
      case 'anime':
        return Container(
          color: Colors.black.withOpacity(0.3),
        );
      case 'minimal':
        return Container(
          color: Colors.black.withOpacity(0.5),
        );
      default:
        return Container(color: Colors.black.withOpacity(0.4));
    }
  }

  Widget _buildTitleSection() {
    switch (_style) {
      case 'cyberpunk':
        return Column(
          children: [
            // Glitch-style title
            Stack(
              alignment: Alignment.center,
              children: [
                Text(_title, style: TextStyle(
                  fontFamily: 'Orbitron', fontSize: 38, fontWeight: FontWeight.bold,
                  color: _accent.withOpacity(0.3), letterSpacing: 4,
                )),
                Transform.translate(
                  offset: const Offset(2, 2),
                  child: Text(_title, style: TextStyle(
                    fontFamily: 'Orbitron', fontSize: 38, fontWeight: FontWeight.bold,
                    color: Colors.red.withOpacity(0.3), letterSpacing: 4,
                  )),
                ),
                Text(_title, style: TextStyle(
                  fontFamily: 'Orbitron', fontSize: 38, fontWeight: FontWeight.bold,
                  color: _accent, letterSpacing: 4,
                  shadows: [Shadow(blurRadius: 20, color: _accent.withOpacity(0.8))],
                )),
              ],
            ),
            const SizedBox(height: 8),
            Text(_subtitle, style: TextStyle(
              fontFamily: 'ShareTechMono', fontSize: 11,
              color: _accent.withOpacity(0.7), letterSpacing: 5,
            )),
          ],
        );
      case 'anime':
        return Column(
          children: [
            Text(_title, style: TextStyle(
              fontFamily: 'Orbitron', fontSize: 42, fontWeight: FontWeight.bold,
              color: Colors.white,
              shadows: [
                Shadow(blurRadius: 30, color: _accent),
                Shadow(blurRadius: 60, color: _accent.withOpacity(0.5)),
              ],
            )),
            const SizedBox(height: 8),
            Text(_subtitle, style: const TextStyle(
              fontFamily: 'ShareTechMono', fontSize: 12,
              color: Colors.white70, letterSpacing: 4,
            )),
          ],
        );
      case 'minimal':
        return Column(
          children: [
            Text(_title, style: const TextStyle(
              fontFamily: 'Orbitron', fontSize: 32, fontWeight: FontWeight.w300,
              color: Colors.white, letterSpacing: 8,
            )),
            const SizedBox(height: 8),
            Container(width: 60, height: 1, color: Colors.white38),
            const SizedBox(height: 8),
            Text(_subtitle, style: const TextStyle(
              fontFamily: 'ShareTechMono', fontSize: 10,
              color: Colors.white38, letterSpacing: 4,
            )),
          ],
        );
      default:
        return Column(
          children: [
            Text(_title, style: TextStyle(
              fontFamily: 'Orbitron', fontSize: 42, fontWeight: FontWeight.bold,
              color: Colors.white, letterSpacing: 2,
              shadows: const [Shadow(blurRadius: 15, color: Color(0x80FFFFFF))],
            )),
            const SizedBox(height: 8),
            Text(_subtitle, style: const TextStyle(
              fontFamily: 'ShareTechMono', fontSize: 12,
              color: Color(0xB2FFFFFF), letterSpacing: 5,
            )),
          ],
        );
    }
  }
}

// ─────────────────────────────────────────────────────────────
//  SplashSettingsWidget  –  UI settings di Settings page
// ─────────────────────────────────────────────────────────────

class SplashSettingsWidget extends StatefulWidget {
  const SplashSettingsWidget({super.key});

  @override
  State<SplashSettingsWidget> createState() => _SplashSettingsWidgetState();
}

class _SplashSettingsWidgetState extends State<SplashSettingsWidget> {
  bool _customEnabled = false;
  String _style = 'default';
  String _title = 'RDP V1';
  String _subtitle = 'hi i"m rdp v1 by @maulkoncet;
  String _accentHex = 'FFFFFF';

  final _titleCtrl = TextEditingController();
  final _subtitleCtrl = TextEditingController();
  final _accentCtrl = TextEditingController();

  final List<Map<String, dynamic>> _styles = [
    {'id': 'default', 'label': 'Default', 'icon': Icons.stars_outlined},
    {'id': 'cyberpunk', 'label': 'Cyberpunk', 'icon': Icons.developer_board},
    {'id': 'anime', 'label': 'Anime', 'icon': Icons.auto_awesome},
    {'id': 'minimal', 'label': 'Minimal', 'icon': Icons.remove},
  ];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final enabled = await SplashSettings.isCustomEnabled();
    final style = await SplashSettings.getStyle();
    final title = await SplashSettings.getTitle();
    final sub = await SplashSettings.getSubtitle();
    final hex = await SplashSettings.getAccentHex();

    setState(() {
      _customEnabled = enabled;
      _style = style;
      _title = title;
      _subtitle = sub;
      _accentHex = hex;
    });
    _titleCtrl.text = title;
    _subtitleCtrl.text = sub;
    _accentCtrl.text = hex;
  }

  Future<void> _save() async {
    await SplashSettings.save(
      customEnabled: _customEnabled,
      style: _style,
      title: _titleCtrl.text,
      subtitle: _subtitleCtrl.text,
      accentHex: _accentCtrl.text,
    );
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('✅ Splash disimpan!', style: TextStyle(fontFamily: 'ShareTechMono')),
          backgroundColor: Color(0xFF071828),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _subtitleCtrl.dispose();
    _accentCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFF00C6FF);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('ANIMATED SPLASH', style: TextStyle(
          color: accent, fontFamily: 'Orbitron', fontSize: 12,
          fontWeight: FontWeight.bold, letterSpacing: 2,
        )),
        const SizedBox(height: 12),

        // Enable custom splash
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: const Color(0xFF071828),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: accent.withOpacity(0.15)),
          ),
          child: Row(
            children: [
              const Icon(Icons.play_circle_outline, color: accent, size: 20),
              const SizedBox(width: 14),
              const Expanded(
                child: Text('Custom Splash', style: TextStyle(
                  color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 13,
                )),
              ),
              Switch(
                value: _customEnabled,
                activeColor: accent,
                onChanged: (v) => setState(() { _customEnabled = v; }),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),

        // Style picker
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: const Color(0xFF071828),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: accent.withOpacity(0.15)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Style', style: TextStyle(
                color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 13,
              )),
              const SizedBox(height: 10),
              Row(
                children: _styles.map((s) {
                  final isActive = _style == s['id'];
                  return Expanded(
                    child: GestureDetector(
                      onTap: () => setState(() { _style = s['id']; }),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        margin: const EdgeInsets.symmetric(horizontal: 3),
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        decoration: BoxDecoration(
                          color: isActive ? accent.withOpacity(0.1) : Colors.transparent,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: isActive ? accent : accent.withOpacity(0.2),
                            width: isActive ? 1.5 : 1,
                          ),
                        ),
                        child: Column(
                          children: [
                            Icon(s['icon'] as IconData, color: isActive ? accent : Colors.white38, size: 18),
                            const SizedBox(height: 3),
                            Text(s['label'] as String, style: TextStyle(
                              color: isActive ? accent : Colors.white38,
                              fontFamily: 'Orbitron', fontSize: 7,
                              fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                            )),
                          ],
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),

        // Title input
        _inputField('Judul Splash', Icons.title, _titleCtrl),
        const SizedBox(height: 8),

        // Subtitle input
        _inputField('Subtitle', Icons.subtitles_outlined, _subtitleCtrl),
        const SizedBox(height: 8),

        // Accent color input
        _inputField('Warna Accent (hex, e.g. 00C6FF)', Icons.palette_outlined, _accentCtrl),
        const SizedBox(height: 16),

        // Save button
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.save_outlined),
            label: const Text('SIMPAN SPLASH'),
          ),
        ),
      ],
    );
  }

  Widget _inputField(String hint, IconData icon, TextEditingController ctrl) {
    const accent = Color(0xFF00C6FF);
    return TextField(
      controller: ctrl,
      style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 13),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 12),
        prefixIcon: Icon(icon, color: accent, size: 18),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: accent.withOpacity(0.2)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: accent),
        ),
        filled: true,
        fillColor: const Color(0xFF071828),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      ),
    );
  }
}
