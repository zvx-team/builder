import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'brutal_button.dart';
import 'theme_provider.dart';

/// Halaman tools untuk preview & generate kode BrutalButton
class ButtonEditorPage extends StatefulWidget {
  const ButtonEditorPage({super.key});

  @override
  State<ButtonEditorPage> createState() => _ButtonEditorPageState();
}

class _ButtonEditorPageState extends State<ButtonEditorPage> {
  // Config
  String _label = 'BUTTON';// fixed
  bool _hasIcon = false;
  bool _outlined = false;
  double _borderRadius = 12;
  double _borderWidth = 2.5;
  double _shadowOffset = 4;
  double _fontSize = 13;
  double _paddingH = 20;
  double _paddingV = 14;
  bool _useCustomColor = false;
  Color _customColor = const Color(0xFF00C6FF);

  final _labelCtrl = TextEditingController(text: 'IKY SOFSPOKEN');

  @override
  void dispose() {
    _labelCtrl.dispose();
    super.dispose();
  }

  String _generateCode() {
    final lines = <String>[];
    lines.add(_hasIcon ? 'BrutalButtonIcon(' : 'BrutalButton(');
    lines.add('  onPressed: () {},');
    if (_useCustomColor) lines.add('  accentColor: Color(0x${_customColor.value.toRadixString(16).toUpperCase().padLeft(8, '0')}),');
    if (_outlined) lines.add('  outlined: true,');
    if (_borderRadius != 12) lines.add('  borderRadius: $_borderRadius,');
    if (_borderWidth != 2.5) lines.add('  borderWidth: $_borderWidth,');
    if (_shadowOffset != 4) lines.add('  shadowOffset: $_shadowOffset,');
    if (_paddingH != 20 || _paddingV != 14) {
      lines.add('  padding: const EdgeInsets.symmetric(');
      lines.add('    horizontal: $_paddingH, vertical: $_paddingV,');
      lines.add('  ),');
    }
    if (_hasIcon) {
      lines.add('  icon: const Icon(Icons.star, size: 18),');
      lines.add('  label: const Text(\'$_label\'),');
    } else {
      lines.add('  child: const Text(\'$_label\',');
      lines.add('    style: TextStyle(fontSize: $_fontSize),');
      lines.add('  ),');
    }
    lines.add(')');
    return lines.join('\n');
  }

  @override
  Widget build(BuildContext context) {
    final theme = AppThemeScope.of(context);
    return Scaffold(
      backgroundColor: theme.bg,
      body: Column(
        children: [
          _buildHeader(theme),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
              children: [
                // Preview
                _buildPreviewCard(theme),
                const SizedBox(height: 20),
                // Controls
                _buildSection(theme, 'TEKS BUTTON', [
                  _buildTextInput(theme),
                ]),
                const SizedBox(height: 16),
                _buildSection(theme, 'STYLE', [
                  _buildToggleRow(theme, 'Outlined (transparan bg)', _outlined,
                    (v) => setState(() => _outlined = v)),
                  _buildToggleRow(theme, 'Dengan Icon', _hasIcon,
                    (v) => setState(() => _hasIcon = v)),
                  _buildToggleRow(theme, 'Custom Color', _useCustomColor,
                    (v) => setState(() => _useCustomColor = v)),
                  if (_useCustomColor) _buildColorPicker(theme),
                ]),
                const SizedBox(height: 16),
                _buildSection(theme, 'UKURAN & BENTUK', [
                  _buildSlider(theme, 'Border Radius', _borderRadius, 0, 40,
                    (v) => setState(() => _borderRadius = v)),
                  _buildSlider(theme, 'Border Width', _borderWidth, 1, 6,
                    (v) => setState(() => _borderWidth = v)),
                  _buildSlider(theme, 'Shadow Offset', _shadowOffset, 0, 12,
                    (v) => setState(() => _shadowOffset = v)),
                  _buildSlider(theme, 'Font Size', _fontSize, 10, 22,
                    (v) => setState(() => _fontSize = v)),
                ]),
                const SizedBox(height: 16),
                _buildSection(theme, 'PADDING', [
                  _buildSlider(theme, 'Horizontal', _paddingH, 8, 40,
                    (v) => setState(() => _paddingH = v)),
                  _buildSlider(theme, 'Vertical', _paddingV, 8, 32,
                    (v) => setState(() => _paddingV = v)),
                ]),
                const SizedBox(height: 16),
                // Generated code
                _buildCodeCard(theme),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(ThemeProvider theme) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 50, 16, 16),
      decoration: BoxDecoration(
        color: theme.card,
        border: Border(bottom: BorderSide(color: theme.accent.withOpacity(0.2))),
      ),
      child: Row(
        children: [
          IconButton(
            icon: Icon(Icons.arrow_back_ios_new, color: theme.accent, size: 20),
            onPressed: () => Navigator.pop(context),
          ),
          const SizedBox(width: 8),
          Icon(Icons.tune_rounded, color: theme.accent, size: 26),
          const SizedBox(width: 10),
          Text('BUTTON EDITOR', style: TextStyle(
            color: theme.accent, fontSize: 18, fontWeight: FontWeight.w900,
            fontFamily: 'Orbitron', letterSpacing: 2,
          )),
          const Spacer(),
          // Reset
          GestureDetector(
            onTap: () => setState(() {
              _label = 'IKY SOFSPOKEN'; _labelCtrl.text = 'IKY SOFSPOKEN';
              _hasIcon = false; _outlined = false;
              _borderRadius = 12; _borderWidth = 2.5; _shadowOffset = 4;
              _fontSize = 13; _paddingH = 20; _paddingV = 14;
              _useCustomColor = false;
            }),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                border: Border.all(color: theme.accent.withOpacity(0.4)),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text('RESET', style: TextStyle(
                color: theme.accent, fontSize: 10,
                fontFamily: 'Orbitron', letterSpacing: 1,
              )),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPreviewCard(ThemeProvider theme) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 24),
      decoration: BoxDecoration(
        color: theme.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: theme.accent.withOpacity(0.15)),
      ),
      child: Column(
        children: [
          Text('PREVIEW', style: TextStyle(
            color: theme.accent.withOpacity(0.4),
            fontSize: 9, fontFamily: 'Orbitron', letterSpacing: 3,
          )),
          const SizedBox(height: 24),
          _hasIcon
            ? BrutalButtonIcon(
                onPressed: () {},
                accentColor: _useCustomColor ? _customColor : null,
                outlined: _outlined,
                padding: EdgeInsets.symmetric(horizontal: _paddingH, vertical: _paddingV),
                icon: Icon(Icons.star, size: _fontSize),
                label: Text(_label, style: TextStyle(fontSize: _fontSize)),
              )
            : BrutalButton(
                onPressed: () {},
                accentColor: _useCustomColor ? _customColor : null,
                outlined: _outlined,
                borderRadius: _borderRadius,
                borderWidth: _borderWidth,
                shadowOffset: _shadowOffset,
                padding: EdgeInsets.symmetric(horizontal: _paddingH, vertical: _paddingV),
                child: Text(_label, style: TextStyle(fontSize: _fontSize)),
              ),
        ],
      ),
    );
  }

  Widget _buildSection(ThemeProvider theme, String title, List<Widget> children) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Text(title, style: TextStyle(
            color: theme.accent.withOpacity(0.6),
            fontSize: 9, fontFamily: 'Orbitron', letterSpacing: 2,
          )),
        ),
        Container(
          decoration: BoxDecoration(
            color: theme.card,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: theme.accent.withOpacity(0.1)),
          ),
          child: Column(children: children),
        ),
      ],
    );
  }

  Widget _buildTextInput(ThemeProvider theme) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: TextField(
        controller: _labelCtrl,
        style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 13),
        decoration: InputDecoration(
          hintText: 'Label button...',
          hintStyle: const TextStyle(color: Colors.white24),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: theme.accent.withOpacity(0.3)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: theme.accent.withOpacity(0.3)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: theme.accent),
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        ),
        onChanged: (v) => setState(() => _label = v.isEmpty ? 'BUTTON' : v.toUpperCase()),
      ),
    );
  }

  Widget _buildToggleRow(ThemeProvider theme, String label, bool value, ValueChanged<bool> onChanged) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Row(
        children: [
          Text(label, style: const TextStyle(color: Colors.white70, fontSize: 13, fontFamily: 'ShareTechMono')),
          const Spacer(),
          Switch(
            value: value,
            onChanged: onChanged,
            activeColor: theme.accent,
            activeTrackColor: theme.accent.withOpacity(0.3),
            inactiveThumbColor: Colors.white30,
            inactiveTrackColor: Colors.white12,
          ),
        ],
      ),
    );
  }

  Widget _buildColorPicker(ThemeProvider theme) {
    final colors = [
      const Color(0xFF00C6FF), const Color(0xFFFF3B3B), const Color(0xFF00FF88),
      const Color(0xFFBB86FC), const Color(0xFFFF8C00), const Color(0xFFFFD700),
      const Color(0xFFFF4DDA), const Color(0xFFD6D6D6),
    ];
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
      child: Wrap(
        spacing: 10,
        children: colors.map((c) => GestureDetector(
          onTap: () => setState(() => _customColor = c),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            width: 30, height: 30,
            decoration: BoxDecoration(
              color: c,
              shape: BoxShape.circle,
              border: Border.all(
                color: _customColor == c ? Colors.white : Colors.transparent,
                width: 2,
              ),
              boxShadow: _customColor == c
                ? [BoxShadow(color: c.withOpacity(0.6), blurRadius: 8)]
                : null,
            ),
          ),
        )).toList(),
      ),
    );
  }

  Widget _buildSlider(ThemeProvider theme, String label, double value, double min, double max, ValueChanged<double> onChanged) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
      child: Row(
        children: [
          SizedBox(
            width: 110,
            child: Text(label, style: const TextStyle(color: Colors.white54, fontSize: 12, fontFamily: 'ShareTechMono')),
          ),
          Expanded(
            child: SliderTheme(
              data: SliderThemeData(
                trackHeight: 2,
                thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 7),
                overlayShape: const RoundSliderOverlayShape(overlayRadius: 14),
                activeTrackColor: theme.accent,
                inactiveTrackColor: theme.accent.withOpacity(0.15),
                thumbColor: theme.accent,
                overlayColor: theme.accent.withOpacity(0.2),
              ),
              child: Slider(value: value, min: min, max: max, onChanged: onChanged),
            ),
          ),
          SizedBox(
            width: 36,
            child: Text(value.toStringAsFixed(0),
              style: TextStyle(color: theme.accent, fontSize: 12, fontFamily: 'ShareTechMono'),
              textAlign: TextAlign.right,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCodeCard(ThemeProvider theme) {
    final code = _generateCode();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Text('GENERATED CODE', style: TextStyle(
            color: theme.accent.withOpacity(0.6),
            fontSize: 9, fontFamily: 'Orbitron', letterSpacing: 2,
          )),
        ),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.black,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: theme.accent.withOpacity(0.3)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('dart', style: TextStyle(
                    color: theme.accent.withOpacity(0.4),
                    fontSize: 10, fontFamily: 'ShareTechMono',
                  )),
                  GestureDetector(
                    onTap: () {
                      Clipboard.setData(ClipboardData(text: code));
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: const Text('Kode disalin!', style: TextStyle(color: Colors.white)),
                        backgroundColor: theme.accent.withOpacity(0.8),
                        behavior: SnackBarBehavior.floating,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        duration: const Duration(seconds: 1),
                      ));
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        border: Border.all(color: theme.accent.withOpacity(0.4)),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.copy, color: theme.accent, size: 12),
                          const SizedBox(width: 4),
                          Text('COPY', style: TextStyle(
                            color: theme.accent, fontSize: 9,
                            fontFamily: 'Orbitron', letterSpacing: 1,
                          )),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(code, style: TextStyle(
                color: Colors.white70,
                fontFamily: 'ShareTechMono',
                fontSize: 12,
                height: 1.6,
              )),
            ],
          ),
        ),
      ],
    );
  }
}
