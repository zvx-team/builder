import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:gallery_saver_plus/gallery_saver.dart';

class TikTokPage extends StatefulWidget {
  const TikTokPage({Key? key}) : super(key: key);

  @override
  State<TikTokPage> createState() => _TikTokPageState();
}

class _TikTokPageState extends State<TikTokPage> {
  final TextEditingController _urlController = TextEditingController();
  String? _videoUrl;
  String? _audioUrl;
  String? _caption;
  bool _loading = false;

  VideoPlayerController? _videoController;
  ChewieController? _chewieController;

  Future<void> _downloadTikTok(String version) async {
    final url = _urlController.text.trim();
    if (url.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Masukkan URL TikTok terlebih dahulu!")),
      );
      return;
    }

    setState(() => _loading = true);

    try {
      Uri api;
      if (version == "v1") {
        api = Uri.parse("https://api.ikyyxd.my.id/download/tiktok?apikey=kyzz&query=$url");
      } else if (version == "v2") {
        api = Uri.parse("https://api.ikyyxd.my.id/download/tiktokv2?url=$url");
      } else if (version == "v3") {
        api = Uri.parse("https://www.tikwm.com/api/?url=$url");
      } else if (version == "v4") {
        api = Uri.parse("https://tikdown.ikyzxz.my.id/api/v1?url=$url");
      } else if (version == "v5") {
        api = Uri.parse("https://api.ikyyxd.my.id/download/tiktokv3?url=$url");
      } else {
        api = Uri.parse("https://api.ikyyxd.my.id/download/tiktokv4?url=$url");
      }

      final resp = await http.get(api);
      final data = jsonDecode(resp.body);

      String? video;
      String? audio;
      String? cap;

      if (version == "v3" && data["code"] == 0) {
        video = data["data"]["play"];
        audio = data["data"]["music"];
        cap = data["data"]["title"];
      } else if (version == "v4" && data["status"] == true) {
        video = data["download"]["nowm"];
        audio = data["download"]["music"];
        cap = data["title"];
      } else if (version == "v5" && data["status"] == true) {
        video = data["result"]["download"]["nowm"];
        audio = data["result"]["download"]["music"];
        cap = data["result"]["caption"];
      } else if (version == "v6" && data["status"] == true) {
        video = data["result"]["media"]["nowm"];
        audio = data["result"]["music"];
        cap = "HD Video";
      } else if (version == "v1" && data["status"] == true) {
        video = data["result"]["video"];
        audio = data["result"]["music"];
        cap = "TikTok Video";
      } else if (version == "v2" && data["status"] == true) {
        video = data["result"]["video"][0];
        audio = data["result"]["music"];
        cap = data["result"]["title"];
      } else {
        throw Exception("Download gagal");
      }

      if (video != null) {
        _videoController?.dispose();
        _chewieController?.dispose();

        _videoController = VideoPlayerController.network(video);
        await _videoController!.initialize();

        _chewieController = ChewieController(
          videoPlayerController: _videoController!,
          autoPlay: true,
          looping: false,
          allowFullScreen: true,
          allowPlaybackSpeedChanging: true,
        );

        setState(() {
          _videoUrl = video;
          _audioUrl = audio;
          _caption = cap;
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    }

    setState(() => _loading = false);
  }

  Future<void> _saveToGallery() async {
    if (_videoUrl != null) {
      final success = await GallerySaver.saveVideo(_videoUrl!);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(success == true
              ? "✅ Video tersimpan ke galeri!"
              : "❌ Gagal simpan video"),
        ),
      );
    }
  }

  Future<void> _saveAudio() async {
    if (_audioUrl != null) {
      final success = await GallerySaver.saveVideo(_audioUrl!);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(success == true
              ? "🎵 Audio tersimpan ke galeri!"
              : "❌ Gagal simpan audio"),
        ),
      );
    }
  }

  @override
  void dispose() {
    _videoController?.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1A0D0D),
      appBar: AppBar(
        title: const Text("TikTok Downloader"),
        backgroundColor: const Color(0xFF8B0000),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _urlController,
              decoration: const InputDecoration(
                labelText: "Masukkan URL TikTok",
                filled: true,
                fillColor: Colors.white10,
              ),
              style: const TextStyle(color: Colors.white),
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 8,
              children: [
                ElevatedButton(onPressed: () => _downloadTikTok("v1"), child: const Text("API V1")),
                ElevatedButton(onPressed: () => _downloadTikTok("v2"), child: const Text("API V2")),
                ElevatedButton(onPressed: () => _downloadTikTok("v3"), child: const Text("API V3")),
                ElevatedButton(onPressed: () => _downloadTikTok("v4"), child: const Text("API V4")),
                ElevatedButton(onPressed: () => _downloadTikTok("v5"), child: const Text("API V5")),
                ElevatedButton(onPressed: () => _downloadTikTok("v6"), child: const Text("API V6")),
              ],
            ),
            const SizedBox(height: 20),
            if (_loading) const CircularProgressIndicator(color: Colors.red),
            if (_chewieController != null && _videoController!.value.isInitialized)
              Column(
                children: [
                  Text(_caption ?? "", style: const TextStyle(color: Colors.white)),
                  const SizedBox(height: 10),
                  AspectRatio(
                    aspectRatio: _videoController!.value.aspectRatio,
                    child: Chewie(controller: _chewieController!),
                  ),
                  const SizedBox(height: 10),
                  // Menu tiga titik
                  PopupMenuButton<String>(
                    icon: const Icon(Icons.more_vert, color: Colors.white),
                    onSelected: (value) {
                      if (value == 'video') {
                        _saveToGallery();
                      } else if (value == 'audio') {
                        _saveAudio();
                      }
                    },
                    itemBuilder: (context) => [
                      const PopupMenuItem(
                        value: 'video',
                        child: Text("Unduh Video"),
                      ),
                      if (_audioUrl != null)
                        const PopupMenuItem(
                          value: 'audio',
                          child: Text("Unduh Audio"),
                        ),
                    ],
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }
}