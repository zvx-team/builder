import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:video_player/video_player.dart';
import 'config.dart';

class TestFuncPage extends StatefulWidget {
  @override
  _TestFuncPageState createState() => _TestFuncPageState();
}

class _TestFuncPageState extends State<TestFuncPage> {
  final _numController = TextEditingController();
  final _countController = TextEditingController(text: "1");
  final _funcController = TextEditingController();

  bool _loading = false;
  String _result = "";
  
  static const Color primaryWhite = Color(0xFFFFFFFF);
  
  late VideoPlayerController _videoController;
  bool _isVideoInitialized = false;
  
  @override
void initState() {
  super.initState();
  _videoController = VideoPlayerController.asset("assets/videos/landing.mp4")
    ..initialize().then((_) {
      setState(() => _isVideoInitialized = true);
      _videoController.setLooping(true);
      _videoController.setVolume(1.0);
      _videoController.play();
    });
}

@override
void dispose() {
  _videoController.dispose();
  super.dispose();
}

  Future<void> _sendTest() async {
  setState(() => _loading = true);

  final target = _numController.text.replaceAll(RegExp(r'[^0-9]'), '');
  final count = int.tryParse(_countController.text) ?? 1;

  showDialog(
   context: context,
   barrierDismissible: false,
   builder: (_) => AlertDialog(
     backgroundColor: Colors.black,
     content: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text("Sedang proses...", style: TextStyle(color: Colors.redAccent)),
        SizedBox(height: 12),
        _isVideoInitialized
            ? AspectRatio(
                aspectRatio: _videoController.value.aspectRatio,
                child: VideoPlayer(_videoController),
              )
            : Container(
                height: 200,
                color: Colors.black,
                child: Center(
                  child: CircularProgressIndicator(color: Colors.redAccent),
                ),
              ),
            ],
          ),
        ),
     );
  try {
    final response = await http.post(
      Uri.parse("$Kbase/testfunc?target=$target"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "count": count > 300 ? 300 : count,
        "funcCode": _funcController.text,
      }),
    );

    Navigator.pop(context);

    setState(() {
      _loading = false;
      _result = response.body;
    });

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black,
        title: Text("✔️ Selesai Test Function",
            style: TextStyle(color: Colors.redAccent)),
        content: Text("Target: $target\nLoop: $count",
            style: TextStyle(color: Colors.red[200])),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK", style: TextStyle(color: Colors.redAccent)),
          )
        ],
      ),
    );
  } catch (e) {
    Navigator.pop(context);
    setState(() {
      _loading = false;
      _result = "Error: $e";
    });
  }
}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black87,
      appBar: AppBar(
        title: const Text("Test Function Code",
         style: TextStyle(
          color: primaryWhite,
          fontSize: 13,
          fontWeight: FontWeight.bold,
          letterSpacing: 1,
          fontFamily: "Orbitron",
         ),
       ),
      backgroundColor: Colors.red[900],
     ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _numController,
              style: TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: "Example: 62xxx",
                labelStyle: TextStyle(color: Colors.red[300]),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.red),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.redAccent),
                ),
              ),
            ),
            SizedBox(height: 12),
            TextField(
              controller: _countController,
              style: TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: "Jumlah Loop Max 300",
                labelStyle: TextStyle(color: Colors.red[300]),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.red),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.redAccent),
                ),
              ),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 12),
            TextField(
             controller: _funcController,
             style: TextStyle(
              color: Colors.white),
              maxLines: 6,
              decoration: InputDecoration(
               labelText: "Paste func disini",
               labelStyle: TextStyle(
                color: Colors.red[300]),
                enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.red),
                ),
               focusedBorder: OutlineInputBorder(
               borderSide: BorderSide(color: Colors.redAccent),
              ),
              helperText: "⚠️ Function Harus targetJid bukan target",
              helperStyle: TextStyle(color: Colors.redAccent),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: _loading ? null : _sendTest,
              icon: Icon(Icons.play_arrow),
              label: Text("Tes Function"),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red[800],
                foregroundColor: Colors.white,
              ),
            ),
            SizedBox(height: 20),
            Expanded(
              child: SingleChildScrollView(
                child: Text(
                  _result,
                  style: TextStyle(color: Colors.red[200]),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}