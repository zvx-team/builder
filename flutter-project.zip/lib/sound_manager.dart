// ignore_for_file: use_build_context_synchronously
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ─────────────────────────────────────────────────────────────
//  SoundManager  –  Manager efek suara global
// ─────────────────────────────────────────────────────────────
//  CARA PAKAI:
//  SoundManager.playAttack();   // saat bug dikirim
//  SoundManager.playSuccess();  // saat berhasil
//  SoundManager.playClick();    // saat tombol ditekan
//  SoundManager.playCooldown(); // saat cooldown habis
//  SoundManager.playError();    // saat error
// ─────────────────────────────────────────────────────────────

class SoundManager {
  static const _keyEnabled = 'sound_enabled';
  static const _keyPack = 'sound_pack';

  static bool _enabled = true;
  static String _pack = 'cyber';

  static final _player = AudioPlayer();

  static const Map<String, Map<String, String>> _sounds = {
    'cyber': {
      'click':    'https://assets.mixkit.co/sfx/preview/mixkit-modern-technology-select-3124.mp3',
      'attack':   'https://assets.mixkit.co/sfx/preview/mixkit-fast-rocket-whoosh-1714.mp3',
      'success':  'https://assets.mixkit.co/sfx/preview/mixkit-correct-answer-tone-2870.mp3',
      'cooldown': 'https://assets.mixkit.co/sfx/preview/mixkit-notification-bell-timer-1164.mp3',
      'error':    'https://assets.mixkit.co/sfx/preview/mixkit-wrong-answer-fail-notification-946.mp3',
    },
    'retro': {
      'click':    'https://assets.mixkit.co/sfx/preview/mixkit-arcade-retro-game-over-213.mp3',
      'attack':   'https://assets.mixkit.co/sfx/preview/mixkit-retro-arcade-casino-notification-267.mp3',
      'success':  'https://assets.mixkit.co/sfx/preview/mixkit-winning-a-coin-video-game-2069.mp3',
      'cooldown': 'https://assets.mixkit.co/sfx/preview/mixkit-player-losing-or-failing-2042.mp3',
      'error':    'https://assets.mixkit.co/sfx/preview/mixkit-negative-guitar-tone-2324.mp3',
    },
    'minimal': {
      'click':    'https://assets.mixkit.co/sfx/preview/mixkit-light-button-2580.mp3',
      'attack':   'https://assets.mixkit.co/sfx/preview/mixkit-select-click-1109.mp3',
      'success':  'https://assets.mixkit.co/sfx/preview/mixkit-software-interface-start-2574.mp3',
      'cooldown': 'https://assets.mixkit.co/sfx/preview/mixkit-simple-countdown-922.mp3',
      'error':    'https://assets.mixkit.co/sfx/preview/mixkit-system-beep-buzzer-fail-2964.mp3',
    },
  };

  static Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _enabled = prefs.getBool(_keyEnabled) ?? true;
    _pack = prefs.getString(_keyPack) ?? 'cyber';
  }

  static Future<void> setEnabled(bool v) async {
    _enabled = v;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyEnabled, v);
  }

  static Future<void> setPack(String pack) async {
    _pack = pack;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyPack, pack);
  }

  static bool get isEnabled => _enabled;
  static String get currentPack => _pack;
  static List<String> get availablePacks => _sounds.keys.toList();

  static Future<void> _play(String type) async {
    if (!_enabled) return;
    final url = _sounds[_pack]?[type];
    if (url == null) return;
    try {
      await _player.play(UrlSource(url));
    } catch (_) {}
  }

  static Future<void> playClick()    => _play('click');
  static Future<void> playAttack()   => _play('attack');
  static Future<void> playSuccess()  => _play('success');
  static Future<void> playCooldown() => _play('cooldown');
  static Future<void> playError()    => _play('error');
}

// ─────────────────────────────────────────────────────────────
//  SoundSettingsWidget  –  UI Settings suara di settings page
// ─────────────────────────────────────────────────────────────

class SoundSettingsWidget extends StatefulWidget {
  const SoundSettingsWidget({super.key});

  @override
  State<SoundSettingsWidget> createState() => _SoundSettingsWidgetState();
}

class _SoundSettingsWidgetState extends State<SoundSettingsWidget> {
  bool _enabled = true;
  String _pack = 'cyber';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    await SoundManager.init();
    setState(() {
      _enabled = SoundManager.isEnabled;
      _pack = SoundManager.currentPack;
    });
  }

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFF00C6FF);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('EFEK SUARA', style: TextStyle(
          color: accent, fontFamily: 'Orbitron', fontSize: 12,
          fontWeight: FontWeight.bold, letterSpacing: 2,
        )),
        const SizedBox(height: 12),

        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: const Color(0xFF071828),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: accent.withOpacity(0.15)),
          ),
          child: Row(
            children: [
              const Icon(Icons.volume_up_rounded, color: accent, size: 20),
              const SizedBox(width: 14),
              const Expanded(
                child: Text('Sound Effects', style: TextStyle(
                  color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 13,
                )),
              ),
              Switch(
                value: _enabled,
                activeColor: accent,
                onChanged: (v) async {
                  await SoundManager.setEnabled(v);
                  setState(() { _enabled = v; });
                },
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),

        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: const Color(0xFF071828),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: accent.withOpacity(0.15)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Sound Pack', style: TextStyle(
                color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 13,
              )),
              const SizedBox(height: 12),
              Row(
                children: SoundManager.availablePacks.map((pack) {
                  final isActive = _pack == pack;
                  return Expanded(
                    child: GestureDetector(
                      onTap: () async {
                        await SoundManager.setPack(pack);
                        setState(() { _pack = pack; });
                        SoundManager.playClick();
                      },
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        decoration: BoxDecoration(
                          color: isActive ? accent.withOpacity(0.1) : Colors.transparent,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: isActive ? accent : accent.withOpacity(0.2),
                            width: isActive ? 1.5 : 1,
                          ),
                        ),
                        child: Column(
                          children: [
                            Icon(
                              pack == 'cyber' ? Icons.developer_board
                                : pack == 'retro' ? Icons.gamepad_outlined
                                : Icons.graphic_eq,
                              color: isActive ? accent : Colors.white38,
                              size: 20,
                            ),
                            const SizedBox(height: 4),
                            Text(
                              pack.toUpperCase(),
                              style: TextStyle(
                                color: isActive ? accent : Colors.white38,
                                fontFamily: 'Orbitron', fontSize: 8,
                                fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                                letterSpacing: 1,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ],
          ),
        ),

        const SizedBox(height: 8),

        Row(
          children: [
            Expanded(child: _testBtn('Attack', Icons.bolt, () => SoundManager.playAttack())),
            const SizedBox(width: 8),
            Expanded(child: _testBtn('Success', Icons.check_circle_outline, () => SoundManager.playSuccess())),
            const SizedBox(width: 8),
            Expanded(child: _testBtn('Error', Icons.error_outline, () => SoundManager.playError())),
          ],
        ),
      ],
    );
  }

  Widget _testBtn(String label, IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: const Color(0xFF071828),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFF00C6FF).withOpacity(0.2)),
        ),
        child: Column(
          children: [
            Icon(icon, color: const Color(0xFF00C6FF), size: 18),
            const SizedBox(height: 4),
            Text(label, style: const TextStyle(
              color: Colors.white54, fontFamily: 'ShareTechMono', fontSize: 10,
            )),
          ],
        ),
      ),
    );
  }
}
