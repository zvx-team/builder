import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

enum AiType { groq, gpt4 }

class ChatMessage {
  final String text;
  final bool isUser;
  final DateTime timestamp;
  final AiType? aiType;

  ChatMessage({
    required this.text,
    required this.isUser,
    required this.timestamp,
    this.aiType,
  });
}

class AiService {
  static const String _groqBase = 'https://next-api-v1.vercel.app/ai/groq';
  static const String _gpt4Base = 'https://next-api-v1.vercel.app/ai/gpt4';

  static Future<String> sendMessage({
    required String message,
    required AiType type,
  }) async {
    final Uri uri;
    if (type == AiType.groq) {
      uri = Uri.parse('$_groqBase?text=${Uri.encodeComponent(message)}');
    } else {
      uri = Uri.parse('$_gpt4Base?prompt=${Uri.encodeComponent(message)}');
    }

    try {
      final response = await http.get(
        uri,
        headers: {'Content-Type': 'application/json'},
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true && data['result'] != null) {
          return data['result'] as String;
        } else {
          throw Exception('Invalid response');
        }
      } else {
        throw Exception('HTTP Error: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Failed to connect: $e');
    }
  }
}

class AppColors {
  static const Color bg = Color(0xFF0A0A0A);
  static const Color surface = Color(0xFF1A0A0A);
  static const Color surfaceElevated = Color(0xFF2A1A1A);
  static const Color border = Color(0xFF3A1A1A);

  static const Color groqPrimary = Color(0xFF8B0000);   // Dark Red
  static const Color groqSecondary = Color(0xFFB22222); // Firebrick
  static const Color groqGlow = Color(0x30FF1744);      // Soft Red Glow
  static const Color groqBubble = Color(0xFF1A0A0A);    // Deep Red Bubble

  static const Color gpt4Primary = Color(0xFF7A1A1A);   // Burgundy
  static const Color gpt4Secondary = Color(0xFF992222); // Wine Red
  static const Color gpt4Glow = Color(0x30992222);      // Glow Burgundy
  static const Color gpt4Bubble = Color(0xFF2A0D0D);    // Dark Bubble

  static const Color userBubble = Color(0xFF1E0A0A);
  static const Color userBorder = Color(0xFF3A1A1A);

  static const Color textPrimary = Color(0xFFFFEAEA);   // Soft White‑Red
  static const Color textSecondary = Color(0xFFCC8888); // Muted Red‑Grey
  static const Color textMuted = Color(0xFF663A3A);     // Dark Muted Red
}

class AiPage extends StatefulWidget {
  const AiPage({super.key});

  @override
  State<AiPage> createState() => _AiPageState();
}

class _AiPageState extends State<AiPage> with TickerProviderStateMixin {
  final List<ChatMessage> _messages = [];
  final TextEditingController _inputController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  AiType _selectedAi = AiType.groq;
  bool _isLoading = false;

  late AnimationController _typingController;
  late AnimationController _switchController;
  late Animation<double> _switchAnimation;

  @override
  void initState() {
    super.initState();
    _typingController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..repeat(reverse: true);

    _switchController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _switchAnimation = CurvedAnimation(
      parent: _switchController,
      curve: Curves.easeInOut,
    );

    _messages.add(ChatMessage(
      text:
          'Halo! Pilih model AI di atas lalu mulai percakapan!',
      isUser: false,
      timestamp: DateTime.now(),
      aiType: AiType.groq,
    ));
  }

  @override
  void dispose() {
    _typingController.dispose();
    _switchController.dispose();
    _inputController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Color get _primaryColor =>
      _selectedAi == AiType.groq ? AppColors.groqPrimary : AppColors.gpt4Primary;

  Color get _glowColor =>
      _selectedAi == AiType.groq ? AppColors.groqGlow : AppColors.gpt4Glow;

  void _switchAi(AiType type) {
    if (type == _selectedAi) return;
    HapticFeedback.selectionClick();
    setState(() => _selectedAi = type);
    _switchController.forward(from: 0);
  }

  Future<void> _sendMessage() async {
    final text = _inputController.text.trim();
    if (text.isEmpty || _isLoading) return;

    HapticFeedback.lightImpact();
    _inputController.clear();

    setState(() {
      _messages.add(ChatMessage(
        text: text,
        isUser: true,
        timestamp: DateTime.now(),
      ));
      _isLoading = true;
    });

    _scrollToBottom();

    try {
      final response = await AiService.sendMessage(
        message: text,
        type: _selectedAi,
      );
      setState(() {
        _messages.add(ChatMessage(
          text: response,
          isUser: false,
          timestamp: DateTime.now(),
          aiType: _selectedAi,
        ));
      });
    } catch (e) {
      setState(() {
        _messages.add(ChatMessage(
          text: 'Oops! Gagal mendapat respons: ${e.toString()}',
          isUser: false,
          timestamp: DateTime.now(),
          aiType: _selectedAi,
        ));
      });
    } finally {
      setState(() => _isLoading = false);
      _scrollToBottom();
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 400),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _clearChat() {
    HapticFeedback.mediumImpact();
    setState(() {
      _messages.clear();
      _messages.add(ChatMessage(
        text: 'chat dibersihkan. mulai percakapan baru!',
        isUser: false,
        timestamp: DateTime.now(),
        aiType: _selectedAi,
      ));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            _buildAiSelector(),
            Expanded(child: _buildMessageList()),
            _buildInputArea(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 16, 16, 12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border(
          bottom: BorderSide(color: AppColors.border, width: 1),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: _glowColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _primaryColor.withOpacity(0.5), width: 1),
              boxShadow: [
                BoxShadow(
                  color: _glowColor,
                  blurRadius: 12,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: Icon(
              _selectedAi == AiType.groq ? Icons.flash_on : Icons.auto_awesome,
              color: _primaryColor,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _selectedAi == AiType.groq ? 'Groq AI' : 'GPT-4',
                  style: TextStyle(
                    color: _primaryColor,
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.5,
                  ),
                ),
                Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: _isLoading ? Colors.orange : Colors.greenAccent,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: (_isLoading ? Colors.orange : Colors.greenAccent)
                                .withOpacity(0.6),
                            blurRadius: 4,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 5),
                    Text(
                      _isLoading ? 'Sedang mengetik...' : 'Online',
                      style: const TextStyle(
                        color: AppColors.textSecondary,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: _clearChat,
            icon: const Icon(Icons.cleaning_services_rounded, size: 20),
            color: AppColors.textSecondary,
            tooltip: 'Hapus chat',
          ),
        ],
      ),
    );
  }

  Widget _buildAiSelector() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      color: AppColors.surface,
      child: Row(
        children: [
          const Text(
            'Model:',
            style: TextStyle(
              color: AppColors.textSecondary,
              fontSize: 12,
              fontWeight: FontWeight.w500,
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Container(
              height: 38,
              decoration: BoxDecoration(
                color: AppColors.surfaceElevated,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppColors.border),
              ),
              child: Row(
                children: [
                  _buildSelectorTab(
                    label: 'Groq AI',
                    type: AiType.groq,
                    activeColor: AppColors.groqPrimary,
                    activeGlow: AppColors.groqGlow,
                  ),
                  _buildSelectorTab(
                    label: 'GPT-4 AI',
                    type: AiType.gpt4,
                    activeColor: AppColors.gpt4Primary,
                    activeGlow: AppColors.gpt4Glow,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSelectorTab({
    required String label,
    required AiType type,
    required Color activeColor,
    required Color activeGlow,
  }) {
    final isActive = _selectedAi == type;
    return Expanded(
      child: GestureDetector(
        onTap: () => _switchAi(type),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeInOut,
          margin: const EdgeInsets.all(3),
          decoration: BoxDecoration(
            color: isActive ? activeColor.withOpacity(0.15) : Colors.transparent,
            borderRadius: BorderRadius.circular(7),
            border: isActive
                ? Border.all(color: activeColor.withOpacity(0.5), width: 1)
                : Border.all(color: Colors.transparent),
            boxShadow: isActive
                ? [BoxShadow(color: activeGlow, blurRadius: 8)]
                : null,
          ),
          alignment: Alignment.center,
          child: Text(
            label,
            style: TextStyle(
              color: isActive ? activeColor : AppColors.textMuted,
              fontSize: 12,
              fontWeight: isActive ? FontWeight.w700 : FontWeight.w400,
              letterSpacing: 0.3,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMessageList() {
    return ListView.builder(
      controller: _scrollController,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      itemCount: _messages.length + (_isLoading ? 1 : 0),
      itemBuilder: (ctx, i) {
        if (i == _messages.length && _isLoading) {
          return _buildTypingIndicator();
        }
        return _buildMessageBubble(_messages[i]);
      },
    );
  }

  Widget _buildMessageBubble(ChatMessage msg) {
    final isUser = msg.isUser;
    final isGroq = msg.aiType == AiType.groq;
    final bubbleColor = isUser
        ? AppColors.userBubble
        : (isGroq ? AppColors.groqBubble : AppColors.gpt4Bubble);
    final borderColor = isUser
        ? AppColors.userBorder
        : (isGroq
            ? AppColors.groqPrimary.withOpacity(0.3)
            : AppColors.gpt4Primary.withOpacity(0.3));
    final glowColor = isUser
        ? Colors.transparent
        : (isGroq ? AppColors.groqGlow : AppColors.gpt4Glow);

    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.82,
        ),
        child: Column(
          crossAxisAlignment:
              isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            if (!isUser)
              Padding(
                padding: const EdgeInsets.only(left: 4, bottom: 4),
                child: Text(
                  isGroq ? 'Groq' : 'GPT-4',
                  style: TextStyle(
                    color: isGroq ? AppColors.groqPrimary : AppColors.gpt4Primary,
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.8,
                  ),
                ),
              ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: bubbleColor,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(16),
                  topRight: const Radius.circular(16),
                  bottomLeft: Radius.circular(isUser ? 16 : 4),
                  bottomRight: Radius.circular(isUser ? 4 : 16),
                ),
                border: Border.all(color: borderColor, width: 1),
                boxShadow: [
                  BoxShadow(
                    color: glowColor,
                    blurRadius: 10,
                    spreadRadius: 0,
                  ),
                ],
              ),
              child: SelectableText(
                msg.text,
                style: const TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 14,
                  height: 1.5,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 3, left: 4, right: 4),
              child: Text(
                _formatTime(msg.timestamp),
                style: const TextStyle(
                  color: AppColors.textMuted,
                  fontSize: 10,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTypingIndicator() {
    final isGroq = _selectedAi == AiType.groq;
    final color = isGroq ? AppColors.groqPrimary : AppColors.gpt4Primary;
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: isGroq ? AppColors.groqBubble : AppColors.gpt4Bubble,
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(16),
            topRight: Radius.circular(16),
            bottomRight: Radius.circular(16),
            bottomLeft: Radius.circular(4),
          ),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(3, (i) {
            return AnimatedBuilder(
              animation: _typingController,
              builder: (ctx, _) {
                final offset = (i * 0.3).clamp(0.0, 1.0);
                final opacity = (((_typingController.value - offset).abs() < 0.4)
                        ? 1.0
                        : 0.3)
                    .clamp(0.3, 1.0);
                return Container(
                  margin: EdgeInsets.only(right: i < 2 ? 4 : 0),
                  width: 7,
                  height: 7,
                  decoration: BoxDecoration(
                    color: color.withOpacity(opacity),
                    shape: BoxShape.circle,
                  ),
                );
              },
            );
          }),
        ),
      ),
    );
  }

  Widget _buildInputArea() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border(
          top: BorderSide(color: AppColors.border),
        ),
        boxShadow: [
          BoxShadow(
            color: _glowColor.withOpacity(0.1),
            blurRadius: 20,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: AppColors.surfaceElevated,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: _isLoading
                      ? AppColors.border
                      : _primaryColor.withOpacity(0.4),
                  width: 1,
                ),
                boxShadow: [
                  BoxShadow(
                    color: _isLoading ? Colors.transparent : _glowColor,
                    blurRadius: 8,
                  ),
                ],
              ),
              child: TextField(
                controller: _inputController,
                enabled: !_isLoading,
                maxLines: 4,
                minLines: 1,
                textInputAction: TextInputAction.newline,
                style: const TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 14,
                ),
                decoration: InputDecoration(
                  hintText: _isLoading
                      ? 'Menunggu respons...'
                      : 'Ketik pesan...',
                  hintStyle: const TextStyle(
                    color: AppColors.textMuted,
                    fontSize: 14,
                  ),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 12,
                  ),
                ),
                onSubmitted: (_) => _sendMessage(),
              ),
            ),
          ),
          const SizedBox(width: 10),
          GestureDetector(
            onTap: _sendMessage,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: _isLoading
                    ? AppColors.surfaceElevated
                    : _primaryColor.withOpacity(0.15),
                borderRadius: BorderRadius.circular(13),
                border: Border.all(
                  color: _isLoading
                      ? AppColors.border
                      : _primaryColor.withOpacity(0.6),
                  width: 1,
                ),
                boxShadow: _isLoading
                    ? null
                    : [
                        BoxShadow(
                          color: _glowColor,
                          blurRadius: 12,
                        ),
                      ],
              ),
              child: Icon(
                _isLoading ? Icons.hourglass_top_rounded : Icons.send_rounded,
                color: _isLoading ? AppColors.textMuted : _primaryColor,
                size: 20,
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _formatTime(DateTime time) {
    final h = time.hour.toString().padLeft(2, '0');
    final m = time.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }
}

void main() {
  runApp(const AiApp());
}

class AiApp extends StatelessWidget {
  const AiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AI Chat',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: AppColors.bg,
        colorScheme: ColorScheme.dark(
          primary: AppColors.groqPrimary,
          surface: AppColors.surface,
        ),
      ),
      home: const AiPage(),
    );
  }
}