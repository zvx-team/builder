import 'dart:convert';
import 'package:http/http.dart' as http;

class LyricLine {
  final Duration time;
  final String text;
  LyricLine(this.time, this.text);
}

class LyricsResult {
  final String? plainLyrics;
  final List<LyricLine> syncedLines;

  LyricsResult({this.plainLyrics, this.syncedLines = const []});

  bool get hasSynced => syncedLines.isNotEmpty;
}

/// Port of the lrclib.net calls seen in test-lrclib.js / test-lyrics*.js.
/// lrclib.net is a free, open community lyrics database — no auth needed.
class LyricsService {
  static const _base = 'https://lrclib.net/api/get';

  Future<LyricsResult?> fetch({
    required String trackName,
    required String artistName,
  }) async {
    final uri = Uri.parse(_base).replace(queryParameters: {
      'track_name': trackName,
      'artist_name': artistName,
    });

    final res = await http.get(uri);
    if (res.statusCode != 200) return null;

    final data = jsonDecode(res.body);
    final synced = data['syncedLyrics'] as String?;
    final plain = data['plainLyrics'] as String?;

    List<LyricLine> lines = [];
    if (synced != null && synced.isNotEmpty) {
      lines = _parseLrc(synced);
    }

    return LyricsResult(plainLyrics: plain, syncedLines: lines);
  }

  /// Parses standard `[mm:ss.xx] lyric text` LRC format.
  List<LyricLine> _parseLrc(String lrc) {
    final lines = <LyricLine>[];
    final regex = RegExp(r'\[(\d+):(\d+)\.(\d+)\](.*)');
    for (final raw in lrc.split('\n')) {
      final match = regex.firstMatch(raw);
      if (match == null) continue;
      final minutes = int.parse(match.group(1)!);
      final seconds = int.parse(match.group(2)!);
      final millisStr = match.group(3)!;
      final millis = int.parse(millisStr.padRight(3, '0').substring(0, 3));
      final text = match.group(4)!.trim();
      lines.add(LyricLine(
        Duration(minutes: minutes, seconds: seconds, milliseconds: millis),
        text,
      ));
    }
    return lines;
  }
}
