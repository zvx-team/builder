import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/track.dart';

/// Port of `lib/ytmusic.ts` (which wraps the `ytmusic-api` npm package).
///
/// NOTE: There is no official public API for YouTube Music. This calls the
/// same internal `/youtubei/v1/search` endpoint that the `ytmusic-api` /
/// `ytmusicapi` open-source libraries use. It can break if Google changes
/// their internal response format, and using it in a widely-distributed app
/// runs against YouTube's Terms of Service — same caveat that applied to the
/// Next.js version. Fine for a personal/learning project; think twice before
/// shipping it publicly at scale.
class YTMusicService {
  static const _baseUrl = 'https://music.youtube.com/youtubei/v1';
  static const _apiKey = 'AIzaSyC9XL3ZjWddXya6X74dJoCTL-WEYFDNX30'; // public, used by web client

  static Map<String, dynamic> _context() => {
        'context': {
          'client': {
            'clientName': 'WEB_REMIX',
            'clientVersion': '1.20241201.01.00',
            'hl': 'en',
            'gl': 'US',
          },
        },
      };

  Future<List<Track>> search(String query) async {
    final uri = Uri.parse('$_baseUrl/search?key=$_apiKey');
    final body = {
      ..._context(),
      'query': query,
      'params': 'EgWKAQIIAWoKEAMQBBAJEAoQBQ%3D%3D', // filter: songs
    };

    final res = await http.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(body),
    );

    if (res.statusCode != 200) {
      throw Exception('YTMusic search failed: ${res.statusCode}');
    }

    final data = jsonDecode(res.body);
    return _parseSearchResults(data);
  }

  /// Walks the (fairly deep/unstable) YouTube Music response tree to pull out
  /// song results. Kept isolated here so if Google changes the shape, only
  /// this method needs updating.
  List<Track> _parseSearchResults(Map<String, dynamic> data) {
    final List<Track> results = [];
    try {
      final contents = data['contents']?['tabbedSearchResultsRenderer']
              ?['tabs']?[0]?['tabRenderer']?['content']?['sectionListRenderer']
          ?['contents'] as List?;

      if (contents == null) return results;

      for (final section in contents) {
        final shelfContents =
            section['musicShelfRenderer']?['contents'] as List?;
        if (shelfContents == null) continue;

        for (final item in shelfContents) {
          final renderer = item['musicResponsiveListItemRenderer'];
          if (renderer == null) continue;

          final videoId = renderer['playlistItemData']?['videoId'] ??
              renderer['overlay']?['musicItemThumbnailOverlayRenderer']
                  ?['content']?['musicPlayButtonRenderer']?['playNavigationEndpoint']
                  ?['watchEndpoint']?['videoId'];
          if (videoId == null) continue;

          final flexColumns =
              renderer['flexColumns'] as List? ?? [];
          final title = _extractText(flexColumns, 0);
          final artist = _extractText(flexColumns, 1);

          final thumbs = (renderer['thumbnail']?['musicThumbnailRenderer']
                  ?['thumbnail']?['thumbnails'] as List?) ??
              [];

          results.add(Track(
            videoId: videoId,
            name: title ?? 'Unknown Title',
            artists: [Artist(name: artist ?? 'Unknown Artist')],
            thumbnails: thumbs.map((t) => Thumbnail.fromJson(t)).toList(),
          ));
        }
      }
    } catch (_) {
      // Response shape changed or unexpected item — return what we have.
    }
    return results;
  }

  String? _extractText(List flexColumns, int index) {
    try {
      final runs = flexColumns[index]['musicResponsiveListItemFlexColumnRenderer']
          ['text']['runs'] as List;
      return runs.map((r) => r['text']).join();
    } catch (_) {
      return null;
    }
  }
}
