import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:audioplayers/audioplayers.dart';
import 'theme_provider.dart';

class MusicPage extends StatefulWidget {
  const MusicPage({super.key});

  @override
  State<MusicPage> createState() => _MusicPageState();
}

class _MusicPageState extends State<MusicPage> with TickerProviderStateMixin {
  final _searchCtrl = TextEditingController();
  List<Map<String, dynamic>> _results = [];
  bool _isLoading = false;
  String _status = '';

  // Audio
  final AudioPlayer _audioPlayer = AudioPlayer();
  Map<String, dynamic>? _currentSong;
  bool _isPlaying = false;
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;

  late AnimationController _discCtrl;
  late AnimationController _waveCtrl;

  @override
  void initState() {
    super.initState();
    _discCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 4))..repeat();
    _waveCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800))..repeat(reverse: true);

    _audioPlayer.onPlayerStateChanged.listen((state) {
      if (!mounted) return;
      setState(() => _isPlaying = state == PlayerState.playing);
    });
    _audioPlayer.onPositionChanged.listen((pos) {
      if (!mounted) return;
      setState(() => _position = pos);
    });
    _audioPlayer.onDurationChanged.listen((dur) {
      if (!mounted) return;
      setState(() => _duration = dur);
    });
    _audioPlayer.onPlayerComplete.listen((_) {
      if (!mounted) return;
      setState(() { _isPlaying = false; _position = Duration.zero; });
    });
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    _audioPlayer.dispose();
    _discCtrl.dispose();
    _waveCtrl.dispose();
    super.dispose();
  }

  Future<void> _search(String q) async {
    if (q.trim().isEmpty) return;
    setState(() { _isLoading = true; _results = []; _status = ''; });
    try {
      final res = await http.get(
        Uri.parse('https://itunes.apple.com/search?term=${Uri.encodeComponent(q)}&media=music&limit=20&country=ID'),
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      final results = data['results'] as List? ?? [];
      setState(() {
        _results = results.map<Map<String, dynamic>>((s) {
          final image = (s['artworkUrl100'] as String?)?.replaceAll('100x100', '500x500') ?? '';
          final previewUrl = s['previewUrl'] ?? '';
          final durationMs = s['trackTimeMillis'] ?? 0;
          return {
            'id': s['trackId']?.toString() ?? UniqueKey().toString(),
            'title': s['trackName'] ?? 'Unknown',
            'artist': s['artistName'] ?? 'Unknown',
            'image': image,
            'dlUrl': previewUrl,
            'duration': (durationMs / 1000).round(),
            'previewUrl': previewUrl,
          };
        }).toList();
        _isLoading = false;
        _status = _results.isEmpty ? 'Tidak ada hasil ditemukan' : '';
      });
    } catch (e) {
      setState(() { _isLoading = false; _status = 'Gagal: $e'; });
    }
  }

  Future<void> _playSong(Map<String, dynamic> song) async {
    final url = song['previewUrl'] as String? ?? '';
    if (url.isEmpty) { _snack('Preview tidak tersedia untuk lagu ini'); return; }

    if (_currentSong?['id'] == song['id']) {
      _isPlaying ? await _audioPlayer.pause() : await _audioPlayer.resume();
      return;
    }

    setState(() {
      _currentSong = song;
      _position = Duration.zero;
      _duration = Duration(seconds: song['duration'] ?? 0);
    });
    try {
      await _audioPlayer.stop();
      await _audioPlayer.play(UrlSource(url));
    } catch (e) {
      _snack('Gagal memutar: $e');
    }
  }

  void _togglePlay() async {
    _isPlaying ? await _audioPlayer.pause() : await _audioPlayer.resume();
  }

  Future<void> _seekTo(double value) async {
    await _audioPlayer.seek(Duration(seconds: (value * _duration.inSeconds).round()));
  }

  Future<void> _download(String url, String title) async {
    if (url.isEmpty) { _snack('Link download tidak tersedia'); return; }
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      _snack('Tidak bisa membuka link download');
    }
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(color: Colors.white)),
      backgroundColor: const Color(0xFF1A1A1A),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ));
  }

  String _fmtDuration(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final theme = AppThemeScope.of(context);
    return Scaffold(
      backgroundColor: theme.bg,
      body: Column(
        children: [
          _buildHeader(theme),
          if (_currentSong != null) _buildMiniPlayer(theme),
          _buildSearchBar(theme),
          Expanded(child: _buildBody(theme)),
        ],
      ),
    );
  }

  Widget _buildHeader(ThemeProvider theme) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 50, 16, 16),
      decoration: BoxDecoration(
        color: theme.card,
        border: Border(bottom: BorderSide(color: theme.accent.withOpacity(0.2))),
      ),
      child: Row(
        children: [
          IconButton(
            icon: Icon(Icons.arrow_back_ios_new, color: theme.accent, size: 20),
            onPressed: () => Navigator.pop(context),
          ),
          const SizedBox(width: 8),
          Icon(Icons.music_note_rounded, color: theme.accent, size: 28),
          const SizedBox(width: 10),
          Text('MUSIC SEARCH', style: TextStyle(
            color: theme.accent, fontSize: 20, fontWeight: FontWeight.w900,
            fontFamily: 'Orbitron', letterSpacing: 2,
          )),
        ],
      ),
    );
  }

  Widget _buildMiniPlayer(ThemeProvider theme) {
    final song = _currentSong!;
    final progress = _duration.inSeconds > 0
        ? (_position.inSeconds / _duration.inSeconds).clamp(0.0, 1.0)
        : 0.0;

    return Container(
      margin: const EdgeInsets.all(12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [theme.accent.withOpacity(0.15), theme.card],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: theme.accent.withOpacity(0.3)),
        boxShadow: [BoxShadow(color: theme.accent.withOpacity(0.1), blurRadius: 20)],
      ),
      child: Column(
        children: [
          Row(
            children: [
              AnimatedBuilder(
                animation: _discCtrl,
                builder: (_, child) => Transform.rotate(
                  angle: _isPlaying ? _discCtrl.value * 2 * pi : 0,
                  child: child,
                ),
                child: Container(
                  width: 56, height: 56,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: theme.accent, width: 2),
                    boxShadow: [BoxShadow(color: theme.accent.withOpacity(0.3), blurRadius: 10)],
                  ),
                  child: ClipOval(
                    child: song['image'].isNotEmpty
                        ? Image.network(song['image'], fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Icon(Icons.music_note, color: theme.accent))
                        : Icon(Icons.music_note, color: theme.accent),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(song['title'],
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 2),
                    Text(song['artist'],
                      style: const TextStyle(color: Colors.white54, fontSize: 12),
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                  ],
                ),
              ),
              if (_isPlaying)
                AnimatedBuilder(
                  animation: _waveCtrl,
                  builder: (_, __) => Row(
                    children: List.generate(3, (i) => Container(
                      margin: const EdgeInsets.symmetric(horizontal: 2),
                      width: 3,
                      height: 8 + (i * 6 * _waveCtrl.value),
                      decoration: BoxDecoration(color: theme.accent, borderRadius: BorderRadius.circular(2)),
                    )),
                  ),
                ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: _togglePlay,
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: theme.accent, shape: BoxShape.circle),
                  child: Icon(_isPlaying ? Icons.pause : Icons.play_arrow, color: theme.bg, size: 20),
                ),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: () => _download(song['dlUrl'], song['title']),
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: theme.accent.withOpacity(0.5)),
                  ),
                  child: Icon(Icons.download_rounded, color: theme.accent, size: 20),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          SliderTheme(
            data: SliderThemeData(
              trackHeight: 3,
              thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
              overlayShape: const RoundSliderOverlayShape(overlayRadius: 12),
              activeTrackColor: theme.accent,
              inactiveTrackColor: theme.accent.withOpacity(0.2),
              thumbColor: theme.accent,
              overlayColor: theme.accent.withOpacity(0.2),
            ),
            child: Slider(value: progress.toDouble(), onChanged: _seekTo),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(_fmtDuration(_position),
                  style: TextStyle(color: theme.accent, fontSize: 11, fontFamily: 'ShareTechMono')),
                Text(_fmtDuration(_duration),
                  style: const TextStyle(color: Colors.white38, fontSize: 11, fontFamily: 'ShareTechMono')),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar(ThemeProvider theme) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: Row(
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: theme.card,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: theme.accent.withOpacity(0.3)),
              ),
              child: TextField(
                controller: _searchCtrl,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'Cari lagu / artis...',
                  hintStyle: const TextStyle(color: Colors.white38),
                  prefixIcon: Icon(Icons.search, color: theme.accent),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(vertical: 14),
                ),
                onSubmitted: _search,
              ),
            ),
          ),
          const SizedBox(width: 10),
          GestureDetector(
            onTap: () => _search(_searchCtrl.text),
            child: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: theme.accent, borderRadius: BorderRadius.circular(14)),
              child: Icon(Icons.search, color: theme.bg, size: 22),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBody(ThemeProvider theme) {
    if (_isLoading) {
      return Center(child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(color: theme.accent),
          const SizedBox(height: 16),
          Text('Mencari lagu...', style: TextStyle(color: theme.accent, fontFamily: 'ShareTechMono')),
        ],
      ));
    }
    if (_status.isNotEmpty) {
      return Center(child: Text(_status, style: const TextStyle(color: Colors.white54)));
    }
    if (_results.isEmpty) {
      return Center(child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.music_note_rounded, color: Colors.white12, size: 80),
          const SizedBox(height: 16),
          const Text('Cari lagu favoritmu', style: TextStyle(color: Colors.white38, fontSize: 16)),
          const SizedBox(height: 8),
          const Text('Preview 30 detik via iTunes',
            style: TextStyle(color: Colors.white24, fontSize: 12, fontFamily: 'ShareTechMono')),
        ],
      ));
    }
    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 100, left: 12, right: 12),
      itemCount: _results.length,
      itemBuilder: (ctx, i) => _buildSongCard(theme, _results[i]),
    );
  }

  Widget _buildSongCard(ThemeProvider theme, Map<String, dynamic> song) {
    final isActive = _currentSong?['id'] == song['id'];
    return GestureDetector(
      onTap: () => _playSong(song),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isActive ? theme.accent.withOpacity(0.12) : theme.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isActive ? theme.accent.withOpacity(0.5) : Colors.white.withOpacity(0.05)),
        ),
        child: Row(
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: SizedBox(
                    width: 54, height: 54,
                    child: song['image'].isNotEmpty
                        ? Image.network(song['image'], fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) =>
                              Container(color: theme.card, child: Icon(Icons.music_note, color: theme.accent)))
                        : Container(color: theme.card, child: Icon(Icons.music_note, color: theme.accent)),
                  ),
                ),
                if (isActive)
                  Container(
                    width: 54, height: 54,
                    decoration: BoxDecoration(
                      color: Colors.black54,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      _isPlaying ? Icons.pause : Icons.play_arrow,
                      color: theme.accent, size: 24,
                    ),
                  ),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(song['title'],
                    style: TextStyle(
                      color: isActive ? theme.accent : Colors.white,
                      fontWeight: FontWeight.bold, fontSize: 14),
                    maxLines: 1, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 4),
                  Text(song['artist'],
                    style: const TextStyle(color: Colors.white54, fontSize: 12),
                    maxLines: 1, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 4),
                  Text(_fmtDuration(Duration(seconds: song['duration'] ?? 0)),
                    style: TextStyle(
                      color: theme.accent.withOpacity(0.7),
                      fontSize: 11, fontFamily: 'ShareTechMono')),
                ],
              ),
            ),
            GestureDetector(
              onTap: () => _download(song['dlUrl'], song['title']),
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: theme.accent.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: theme.accent.withOpacity(0.3)),
                ),
                child: Icon(Icons.download_rounded, color: theme.accent, size: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
