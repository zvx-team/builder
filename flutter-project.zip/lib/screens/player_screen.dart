import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:youtube_player_iframe/youtube_player_iframe.dart';
import '../state/player_state.dart';
import '../services/lyrics_service.dart';

class PlayerScreen extends StatefulWidget {
  const PlayerScreen({super.key});

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  late YoutubePlayerController _controller;
  final _lyricsService = LyricsService();
  LyricsResult? _lyrics;
  String? _loadedForVideoId;

  @override
  void initState() {
    super.initState();
    final track = context.read<PlayerState>().currentTrack;
    _controller = YoutubePlayerController(
      params: const YoutubePlayerParams(
        showControls: false, // audio-first UI; controls are custom below
        showFullscreenButton: false,
        mute: false,
      ),
    );
    if (track != null) {
      _controller.loadVideoById(videoId: track.videoId);
      _loadLyrics(track.name, track.artistNames);
    }
    _lyricsTrackCache = track;
  }

  Future<void> _loadLyrics(String title, String artist) async {
    try {
      final result = await _lyricsService.fetch(trackName: title, artistName: artist);
      if (mounted) setState(() => _lyrics = result);
    } catch (_) {
      // lyrics are optional — fail silently
    }
  }

  @override
  void dispose() {
    _controller.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final player = context.watch<PlayerState>();
    final track = player.currentTrack;

    if (track != _lyricsTrackCache && track != null) {
      _lyricsTrackCache = track;
      _controller.loadVideoById(videoId: track.videoId);
      _lyrics = null;
      _loadLyrics(track.name, track.artistNames);
    }

    if (track == null) {
      return const Scaffold(body: Center(child: Text('Gak ada lagu diputar')));
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Now Playing')),
      body: SafeArea(
        child: Column(
          children: [
            // Hidden/minimal video surface — kept alive to drive audio playback
            // through the official YouTube iframe embed (same approach as the
            // web version's react-youtube usage).
            SizedBox(
              height: 0,
              width: 0,
              child: YoutubePlayer(controller: _controller),
            ),
            const SizedBox(height: 24),
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: track.thumbnailUrl.isNotEmpty
                  ? CachedNetworkImage(
                      imageUrl: track.thumbnailUrl,
                      width: 260,
                      height: 260,
                      fit: BoxFit.cover,
                    )
                  : Container(width: 260, height: 260, color: Colors.white10),
            ),
            const SizedBox(height: 20),
            Text(track.name,
                style: Theme.of(context).textTheme.titleLarge,
                textAlign: TextAlign.center),
            const SizedBox(height: 4),
            Text(track.artistNames,
                style: TextStyle(color: Colors.white54)),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  icon: Icon(Icons.shuffle,
                      color: player.isShuffle ? Theme.of(context).colorScheme.primary : Colors.white54),
                  onPressed: player.toggleShuffle,
                ),
                IconButton(
                  icon: const Icon(Icons.skip_previous, size: 36),
                  onPressed: player.playPrev,
                ),
                IconButton(
                  icon: Icon(player.isPlaying ? Icons.pause_circle_filled : Icons.play_circle_filled,
                      size: 56),
                  onPressed: () {
                    player.togglePlay();
                    player.isPlaying ? _controller.playVideo() : _controller.pauseVideo();
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.skip_next, size: 36),
                  onPressed: player.playNext,
                ),
                IconButton(
                  icon: Icon(
                    player.repeatMode == RepeatMode.one ? Icons.repeat_one : Icons.repeat,
                    color: player.repeatMode == RepeatMode.off ? Colors.white54 : Theme.of(context).colorScheme.primary,
                  ),
                  onPressed: player.toggleRepeat,
                ),
              ],
            ),
            const Divider(height: 32),
            Expanded(
              child: _LyricsView(lyrics: _lyrics),
            ),
          ],
        ),
      ),
    );
  }

  // simple field to detect track changes inside build()
  dynamic _lyricsTrackCache;
}

class _LyricsView extends StatelessWidget {
  final LyricsResult? lyrics;
  const _LyricsView({required this.lyrics});

  @override
  Widget build(BuildContext context) {
    if (lyrics == null) {
      return const Center(
        child: Text('Memuat lirik...', style: TextStyle(color: Colors.white38)),
      );
    }
    if (lyrics!.hasSynced) {
      return ListView.builder(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        itemCount: lyrics!.syncedLines.length,
        itemBuilder: (context, i) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Text(
            lyrics!.syncedLines[i].text,
            style: const TextStyle(fontSize: 16),
            textAlign: TextAlign.center,
          ),
        ),
      );
    }
    if (lyrics!.plainLyrics != null) {
      return SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Text(lyrics!.plainLyrics!, textAlign: TextAlign.center),
      );
    }
    return const Center(
      child: Text('Lirik gak ketemu', style: TextStyle(color: Colors.white38)),
    );
  }
}
