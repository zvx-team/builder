// ignore_for_file: use_build_context_synchronously
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ─────────────────────────────────────────────────────────────
//  PinLockManager  –  Utility untuk simpan/cek PIN
// ─────────────────────────────────────────────────────────────

class PinLockManager {
  static const _keyPin = 'app_pin';
  static const _keyEnabled = 'pin_enabled';
  static const _keyBiometric = 'biometric_enabled';

  static Future<bool> isPinEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_keyEnabled) ?? false;
  }

  static Future<bool> isBiometricEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_keyBiometric) ?? false;
  }

  static Future<void> setPin(String pin) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyPin, pin);
    await prefs.setBool(_keyEnabled, true);
  }

  static Future<void> disablePin() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_keyPin);
    await prefs.setBool(_keyEnabled, false);
    await prefs.setBool(_keyBiometric, false);
  }

  static Future<bool> checkPin(String input) async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(_keyPin) ?? '';
    return saved == input;
  }

  static Future<void> setBiometric(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyBiometric, enabled);
  }

  static Future<bool> canUseBiometric() async {
    return false; // local_auth dihapus untuk kompatibilitas build
  }

  static Future<bool> authenticateBiometric() async {
    return false; // local_auth dihapus untuk kompatibilitas build
  }
}

// ─────────────────────────────────────────────────────────────
//  PinLockScreen  –  Layar input PIN saat buka app
// ─────────────────────────────────────────────────────────────

class PinLockScreen extends StatefulWidget {
  final Widget child;
  const PinLockScreen({super.key, required this.child});

  @override
  State<PinLockScreen> createState() => _PinLockScreenState();
}

class _PinLockScreenState extends State<PinLockScreen> {
  bool _unlocked = false;
  bool _checking = true;
  String _pinInput = '';
  bool _showError = false;
  int _attempts = 0;

  @override
  void initState() {
    super.initState();
    _checkLock();
  }

  Future<void> _checkLock() async {
    final pinEnabled = await PinLockManager.isPinEnabled();
    if (!pinEnabled) {
      if (mounted) setState(() { _unlocked = true; _checking = false; });
      return;
    }

    // Coba biometric dulu jika enabled
    final bioEnabled = await PinLockManager.isBiometricEnabled();
    if (bioEnabled) {
      final ok = await PinLockManager.authenticateBiometric();
      if (ok && mounted) {
        setState(() { _unlocked = true; _checking = false; });
        return;
      }
    }

    if (mounted) setState(() { _checking = false; });
  }

  void _onKeyTap(String key) {
    if (_pinInput.length >= 4) return;
    setState(() {
      _pinInput += key;
      _showError = false;
    });
    if (_pinInput.length == 4) {
      _verifyPin();
    }
  }

  void _onDelete() {
    if (_pinInput.isEmpty) return;
    setState(() {
      _pinInput = _pinInput.substring(0, _pinInput.length - 1);
      _showError = false;
    });
  }

  Future<void> _verifyPin() async {
    final ok = await PinLockManager.checkPin(_pinInput);
    if (ok) {
      setState(() { _unlocked = true; });
    } else {
      _attempts++;
      setState(() {
        _pinInput = '';
        _showError = true;
      });
    }
  }

  Future<void> _tryBiometric() async {
    final ok = await PinLockManager.authenticateBiometric();
    if (ok && mounted) setState(() { _unlocked = true; });
  }

  @override
  Widget build(BuildContext context) {
    if (_checking) {
      return const Scaffold(
        backgroundColor: Colors.black,
        body: Center(child: CircularProgressIndicator(color: Color(0xFF00C6FF))),
      );
    }

    if (_unlocked) return widget.child;

    return Scaffold(
      backgroundColor: const Color(0xFF020D15),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 60),

            // Logo / Icon
            Container(
              width: 80, height: 80,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: const Color(0xFF00C6FF), width: 2),
                boxShadow: [
                  BoxShadow(color: const Color(0xFF00C6FF).withOpacity(0.3), blurRadius: 20, spreadRadius: 2),
                ],
              ),
              child: const Icon(Icons.lock_outline, color: Color(0xFF00C6FF), size: 40),
            ),
            const SizedBox(height: 20),

            const Text('OBSTACLE', style: TextStyle(
              color: Color(0xFF00C6FF), fontFamily: 'Orbitron',
              fontSize: 20, fontWeight: FontWeight.bold, letterSpacing: 3,
            )),
            const SizedBox(height: 6),
            const Text('Masukkan PIN untuk lanjut', style: TextStyle(
              color: Colors.white54, fontFamily: 'ShareTechMono', fontSize: 13,
            )),
            const SizedBox(height: 40),

            // PIN dots
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(4, (i) {
                final filled = i < _pinInput.length;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 150),
                  margin: const EdgeInsets.symmetric(horizontal: 10),
                  width: 18, height: 18,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _showError
                        ? Colors.red.withOpacity(filled ? 1 : 0.2)
                        : (filled ? const Color(0xFF00C6FF) : Colors.white12),
                    border: Border.all(
                      color: _showError ? Colors.red : const Color(0xFF00C6FF),
                      width: 1.5,
                    ),
                    boxShadow: filled ? [
                      BoxShadow(
                        color: (_showError ? Colors.red : const Color(0xFF00C6FF)).withOpacity(0.5),
                        blurRadius: 8, spreadRadius: 1,
                      )
                    ] : null,
                  ),
                );
              }),
            ),

            if (_showError) ...[
              const SizedBox(height: 12),
              Text(
                _attempts >= 5 ? 'Terlalu banyak percobaan salah!' : 'PIN salah! Coba lagi.',
                style: const TextStyle(color: Colors.red, fontFamily: 'ShareTechMono', fontSize: 12),
              ),
            ],

            const SizedBox(height: 40),

            // Numpad
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 60),
              child: Column(
                children: [
                  _buildNumRow(['1', '2', '3']),
                  const SizedBox(height: 16),
                  _buildNumRow(['4', '5', '6']),
                  const SizedBox(height: 16),
                  _buildNumRow(['7', '8', '9']),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _buildBioButton(),
                      _buildNumButton('0'),
                      _buildDeleteButton(),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNumRow(List<String> keys) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: keys.map((k) => _buildNumButton(k)).toList(),
    );
  }

  Widget _buildNumButton(String digit) {
    return GestureDetector(
      onTap: () => _onKeyTap(digit),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 100),
        width: 70, height: 70,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: const Color(0xFF071828),
          border: Border.all(color: const Color(0xFF00C6FF).withOpacity(0.3), width: 1),
        ),
        child: Center(
          child: Text(digit, style: const TextStyle(
            color: Colors.white, fontSize: 24,
            fontFamily: 'Orbitron', fontWeight: FontWeight.bold,
          )),
        ),
      ),
    );
  }

  Widget _buildDeleteButton() {
    return GestureDetector(
      onTap: _onDelete,
      child: Container(
        width: 70, height: 70,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: const Color(0xFF071828),
          border: Border.all(color: Colors.white24, width: 1),
        ),
        child: const Icon(Icons.backspace_outlined, color: Colors.white54, size: 24),
      ),
    );
  }

  Widget _buildBioButton() {
    return FutureBuilder<bool>(
      future: PinLockManager.isBiometricEnabled(),
      builder: (context, snap) {
        if (snap.data == true) {
          return GestureDetector(
            onTap: _tryBiometric,
            child: Container(
              width: 70, height: 70,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF071828),
                border: Border.all(color: const Color(0xFF00C6FF).withOpacity(0.3), width: 1),
              ),
              child: const Icon(Icons.fingerprint, color: Color(0xFF00C6FF), size: 30),
            ),
          );
        }
        return const SizedBox(width: 70, height: 70);
      },
    );
  }
}

// ─────────────────────────────────────────────────────────────
//  PinSettingsPage  –  Halaman settings PIN di Settings page
// ─────────────────────────────────────────────────────────────

class PinSettingsWidget extends StatefulWidget {
  const PinSettingsWidget({super.key});

  @override
  State<PinSettingsWidget> createState() => _PinSettingsWidgetState();
}

class _PinSettingsWidgetState extends State<PinSettingsWidget> {
  bool _pinEnabled = false;
  bool _bioEnabled = false;
  bool _canUseBio = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final pin = await PinLockManager.isPinEnabled();
    final bio = await PinLockManager.isBiometricEnabled();
    final canBio = await PinLockManager.canUseBiometric();
    if (mounted) {
      setState(() {
        _pinEnabled = pin;
        _bioEnabled = bio;
        _canUseBio = canBio;
      });
    }
  }

  Future<void> _showSetPinDialog() async {
    String pin1 = '';
    String pin2 = '';
    int step = 1; // 1 = set, 2 = confirm

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setS) {
            final accent = const Color(0xFF00C6FF);
            return AlertDialog(
              backgroundColor: const Color(0xFF071828),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
                side: BorderSide(color: accent.withOpacity(0.3)),
              ),
              title: Text(
                step == 1 ? 'Buat PIN Baru' : 'Konfirmasi PIN',
                style: TextStyle(color: accent, fontFamily: 'Orbitron', fontSize: 14),
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    step == 1 ? 'Masukkan 4 digit PIN baru' : 'Masukkan PIN sekali lagi',
                    style: const TextStyle(color: Colors.white70, fontFamily: 'ShareTechMono', fontSize: 12),
                  ),
                  const SizedBox(height: 20),
                  TextField(
                    obscureText: true,
                    keyboardType: TextInputType.number,
                    maxLength: 4,
                    autofocus: true,
                    style: TextStyle(color: accent, fontSize: 24, letterSpacing: 16, fontFamily: 'Orbitron'),
                    textAlign: TextAlign.center,
                    decoration: InputDecoration(
                      counterText: '',
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: accent.withOpacity(0.4)),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: accent),
                      ),
                    ),
                    onChanged: (v) {
                      if (step == 1) pin1 = v;
                      else pin2 = v;
                    },
                    onSubmitted: (v) async {
                      if (step == 1 && v.length == 4) {
                        setS(() { step = 2; });
                      } else if (step == 2 && v.length == 4) {
                        if (pin1 == pin2) {
                          await PinLockManager.setPin(pin1);
                          Navigator.pop(ctx, true);
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('PIN tidak cocok!'), backgroundColor: Colors.red),
                          );
                          setS(() { step = 1; pin1 = ''; pin2 = ''; });
                        }
                      }
                    },
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: const Text('Batal', style: TextStyle(color: Colors.white54)),
                ),
              ],
            );
          },
        );
      },
    );
    _load();
  }

  Future<void> _showDisablePinDialog() async {
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF071828),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: Colors.red),
        ),
        title: const Text('Hapus PIN?', style: TextStyle(color: Colors.red, fontFamily: 'Orbitron', fontSize: 14)),
        content: const Text('PIN lock akan dinonaktifkan.', style: TextStyle(color: Colors.white70, fontFamily: 'ShareTechMono', fontSize: 12)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Batal', style: TextStyle(color: Colors.white54)),
          ),
          TextButton(
            onPressed: () async {
              await PinLockManager.disablePin();
              Navigator.pop(ctx);
              _load();
            },
            child: const Text('Hapus', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFF00C6FF);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('KEAMANAN', style: TextStyle(
          color: accent, fontFamily: 'Orbitron', fontSize: 12,
          fontWeight: FontWeight.bold, letterSpacing: 2,
        )),
        const SizedBox(height: 12),

        // PIN Toggle
        _settingsTile(
          icon: Icons.lock_outline,
          title: 'PIN Lock',
          subtitle: _pinEnabled ? 'Aktif — App dikunci dengan PIN' : 'Nonaktif',
          trailing: Switch(
            value: _pinEnabled,
            activeColor: accent,
            onChanged: (v) async {
              if (v) {
                await _showSetPinDialog();
              } else {
                await _showDisablePinDialog();
              }
            },
          ),
        ),

        // Change PIN (hanya jika PIN aktif)
        if (_pinEnabled) ...[
          const SizedBox(height: 8),
          _settingsTile(
            icon: Icons.edit,
            title: 'Ganti PIN',
            subtitle: 'Ubah 4 digit PIN',
            trailing: TextButton(
              onPressed: _showSetPinDialog,
              child: const Text('Ganti', style: TextStyle(color: accent, fontFamily: 'ShareTechMono')),
            ),
          ),
        ],

        // Biometric toggle (jika device support dan PIN aktif)
        if (_pinEnabled && _canUseBio) ...[
          const SizedBox(height: 8),
          _settingsTile(
            icon: Icons.fingerprint,
            title: 'Fingerprint / Biometrik',
            subtitle: 'Login cepat pakai fingerprint',
            trailing: Switch(
              value: _bioEnabled,
              activeColor: accent,
              onChanged: (v) async {
                await PinLockManager.setBiometric(v);
                setState(() { _bioEnabled = v; });
              },
            ),
          ),
        ],
      ],
    );
  }

  Widget _settingsTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required Widget trailing,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF071828),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF00C6FF).withOpacity(0.15)),
      ),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFF00C6FF), size: 20),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(
                  color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 13,
                )),
                Text(subtitle, style: const TextStyle(
                  color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 11,
                )),
              ],
            ),
          ),
          trailing,
        ],
      ),
    );
  }
}
