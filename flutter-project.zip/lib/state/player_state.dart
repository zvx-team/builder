import 'dart:convert';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/track.dart';

enum RepeatMode { off, all, one }

/// Port of the zustand `usePlayerStore` from lib/store.ts.
/// Handles queue, shuffle/repeat, history and play counts, persisted
/// locally with SharedPreferences (equivalent to zustand's `persist`).
class PlayerState extends ChangeNotifier {
  Track? currentTrack;
  List<Track> queue = [];
  int queueIndex = -1;
  bool isPlaying = false;
  Duration progress = Duration.zero;
  Duration duration = Duration.zero;

  List<Track> _originalQueue = [];
  bool isShuffle = false;
  RepeatMode repeatMode = RepeatMode.off;

  final List<Track> history = [];
  final Map<String, int> playCounts = {};

  static const _prefsKey = 'player_state_v1';

  Future<void> restore() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_prefsKey);
    if (raw == null) return;
    try {
      final data = jsonDecode(raw);
      playCounts.addAll(Map<String, int>.from(data['playCounts'] ?? {}));
      final rawHistory = (data['history'] as List?) ?? [];
      history.addAll(rawHistory.map((h) => Track.fromJson(h['track'])));
      notifyListeners();
    } catch (_) {
      // ignore corrupt/legacy state
    }
  }

  Future<void> _persist() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _prefsKey,
      jsonEncode({
        'playCounts': playCounts,
        'history': history
            .take(100)
            .map((t) => {
                  'track': t.toJson(),
                  'playedAt': DateTime.now().millisecondsSinceEpoch,
                })
            .toList(),
      }),
    );
  }

  void playTrack(Track track, {List<Track>? newQueue}) {
    currentTrack = track;
    if (newQueue != null) {
      _originalQueue = List.of(newQueue);
      queue = isShuffle ? _shuffled(newQueue, keep: track) : List.of(newQueue);
      queueIndex = queue.indexWhere((t) => t.videoId == track.videoId);
    } else if (!queue.any((t) => t.videoId == track.videoId)) {
      queue = [track];
      _originalQueue = [track];
      queueIndex = 0;
    }
    isPlaying = true;
    progress = Duration.zero;

    history.insert(0, track);
    playCounts[track.videoId] = (playCounts[track.videoId] ?? 0) + 1;
    _persist();

    notifyListeners();
  }

  void togglePlay() {
    isPlaying = !isPlaying;
    notifyListeners();
  }

  void setPlaying(bool playing) {
    isPlaying = playing;
    notifyListeners();
  }

  void setProgress(Duration p) {
    progress = p;
    notifyListeners();
  }

  void setDuration(Duration d) {
    duration = d;
    notifyListeners();
  }

  void addToQueue(Track track) {
    queue.add(track);
    _originalQueue.add(track);
    notifyListeners();
  }

  void toggleShuffle() {
    isShuffle = !isShuffle;
    if (isShuffle) {
      queue = _shuffled(_originalQueue, keep: currentTrack);
    } else {
      queue = List.of(_originalQueue);
    }
    if (currentTrack != null) {
      queueIndex = queue.indexWhere((t) => t.videoId == currentTrack!.videoId);
    }
    notifyListeners();
  }

  void toggleRepeat() {
    repeatMode = switch (repeatMode) {
      RepeatMode.off => RepeatMode.all,
      RepeatMode.all => RepeatMode.one,
      RepeatMode.one => RepeatMode.off,
    };
    notifyListeners();
  }

  Future<void> playNext() async {
    if (queue.isEmpty) return;
    if (repeatMode == RepeatMode.one) {
      progress = Duration.zero;
      isPlaying = true;
      notifyListeners();
      return;
    }
    final next = queueIndex + 1;
    if (next < queue.length) {
      queueIndex = next;
      playTrack(queue[next]);
    } else if (repeatMode == RepeatMode.all && queue.isNotEmpty) {
      queueIndex = 0;
      playTrack(queue[0]);
    } else {
      isPlaying = false;
      notifyListeners();
    }
  }

  void playPrev() {
    if (queue.isEmpty) return;
    final prev = queueIndex - 1;
    if (prev >= 0) {
      queueIndex = prev;
      playTrack(queue[prev]);
    }
  }

  List<Track> _shuffled(List<Track> source, {Track? keep}) {
    final list = List<Track>.of(source)..shuffle(Random());
    if (keep != null) {
      list.removeWhere((t) => t.videoId == keep.videoId);
      list.insert(0, keep);
    }
    return list;
  }
}
