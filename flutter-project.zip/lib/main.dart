import 'package:flutter/material.dart';

// Import Halaman Utama
import 'landing_page.dart'; 
import 'login_page.dart';
import 'loader_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'buy_account.dart';
import 'splash.dart'; 
import 'device_dashboard.dart';
import 'control_panel.dart';
import 'theme_provider.dart'; // ← sistem tema
import 'pin_lock.dart';       // ← fitur 20: PIN Lock
import 'sound_manager.dart';  // ← fitur 18: Sound Effects
import 'settings_page.dart';  // ← Settings page

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SoundManager.init(); // inisialisasi sound manager
  runApp(const MyApp(startRoute: '/'));
}

class MyApp extends StatefulWidget {
  final String startRoute;
  const MyApp({super.key, required this.startRoute});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final ThemeProvider _themeProvider = ThemeProvider();

  @override
  Widget build(BuildContext context) {
    // AppThemeScope membuat ThemeProvider bisa diakses dari seluruh widget tree
    return AppThemeScope(
      provider: _themeProvider,
      child: AnimatedBuilder(
        animation: _themeProvider,
        builder: (_, __) {
          return MaterialApp(
            debugShowCheckedModeBanner: false,
            title: 'RDP V1',
            // Theme otomatis ganti sesuai pilihan user
            theme: _themeProvider.toMaterialTheme(),
            initialRoute: widget.startRoute,

            onGenerateRoute: (settings) {
              final args = settings.arguments as Map<String, dynamic>?;

              switch (settings.name) {
                case '/settings':
                  return MaterialPageRoute(builder: (_) => const SettingsPage());

                case '/':
                  return MaterialPageRoute(
                    builder: (_) => PinLockScreen(child: const LandingPage()),
                  );
                case '/__skip_pin':
                  return MaterialPageRoute(builder: (_) => const LandingPage());
                  return MaterialPageRoute(builder: (_) => const LandingPage());

                case '/login':
                  return MaterialPageRoute(builder: (_) => const LoginPage());

                case '/splash':
                  return MaterialPageRoute(
                    builder: (_) => SplashPage(data: args ?? {}),
                  );

                case '/buy_account':
                  return MaterialPageRoute(builder: (_) => const BuyAccountPage());

                case '/loader':
                  return MaterialPageRoute(
                    builder: (_) => DashboardPage(
                      username: args?['username'] ?? '',
                      password: args?['password'] ?? '',
                      role: args?['role'] ?? 'member',
                      sessionKey: args?['key'] ?? '',
                      expiredDate: args?['expiredDate'] ?? '',
                      listBug: List<Map<String, dynamic>>.from(args?['listBug'] ?? []),
                      listGroupBug: List<Map<String, dynamic>>.from(args?['listGroupBug'] ?? []),
                      listPayload: List<Map<String, dynamic>>.from(args?['listPayload'] ?? []),
                      listDDoS: List<Map<String, dynamic>>.from(args?['listDDoS'] ?? []),
                      news: List<Map<String, dynamic>>.from(args?['news'] ?? []),
                      creatableRoles: List<String>.from(args?['creatableRoles'] ?? []),
                    ),
                  );

                case '/attack':
                  return MaterialPageRoute(
                    builder: (_) => AttackPage(
                      username: args?['username'] ?? '',
                      password: args?['password'] ?? '',
                      listBug: List<Map<String, dynamic>>.from(args?['listBug'] ?? []),
                      role: args?['role'] ?? '',
                      expiredDate: args?['expiredDate'] ?? '',
                      sessionKey: args?['sessionKey'] ?? '',
                    ),
                  );

                case '/seller':
                  return MaterialPageRoute(
                    builder: (_) => SellerPage(keyToken: args?['keyToken'] ?? ''),
                  );

                case '/admin':
                  return MaterialPageRoute(
                    builder: (_) => AdminPage(
                      sessionKey: args?['sessionKey'] ?? '',
                      role: args?['role'] ?? 'member',
                      creatableRoles: List<String>.from(args?['creatableRoles'] ?? []),
                    ),
                  );

                case '/login_rat':
                  return MaterialPageRoute(builder: (_) => const DeviceDashboardPage());

                case '/dashboard_rat':
                  return MaterialPageRoute(builder: (_) => const DeviceDashboardPage());

                case '/control_panel':
                  return MaterialPageRoute(
                    settings: settings,
                    builder: (_) => const ControlCenterPage(),
                  );

                default:
                  return MaterialPageRoute(
                    builder: (_) => const Scaffold(
                      body: Center(
                        child: Text('404 - PANEL NOT FOUND',
                            style: TextStyle(color: Colors.red)),
                      ),
                    ),
                  );
              }
            },
          );
        },
      ),
    );
  }
}
