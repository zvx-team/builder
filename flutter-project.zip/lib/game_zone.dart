import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'dart:math' as math;
import 'catur.dart';
import 'asahotak.dart';
import 'caklontong_page.dart';

const String wsUrl = "wss://ryannback.rxpedia.my.id:25581";

class GameZonePage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const GameZonePage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<GameZonePage> createState() => _GameZonePageState();
}

class _GameZonePageState extends State<GameZonePage> with TickerProviderStateMixin {
  WebSocketChannel? _channel;
  bool _isConnected = false;
  Timer? _reconnectTimer;

  int _chessPlayers = 0;
  int _asahOtakPlayers = 0;
  int _cakLontongPlayers = 0;
  int _totalOnline = 0;

  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  final Color darkBg = const Color(0xFF0A0F1E);
  final Color darkCard = const Color(0xFF151F2E);
  final Color textPrimary = Colors.white;
  final Color textSecondary = const Color(0xFF8F9BB3);

  late List<GameItem> _games;

  @override
  void initState() {
    super.initState();
    _initAnimations();
    _initializeGames();
    _connectWebSocket();
  }

  void _initAnimations() {
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    )..forward();
    _fadeAnimation = CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeOut,
    );
  }

  void _initializeGames() {
    _games = [
      GameItem(
        id: 'chess',
        title: 'Catur Arena',
        subtitle: 'Multiplayer Catur',
        description: 'Main catur online real-time',
        icon: FontAwesomeIcons.chessBoard,
        gradientColors: const [
          Color(0xFF9C27B0),
          Color(0xFF6A1B9A),
        ],
        accentColor: const Color(0xFF9C27B0),
        playerCountStream: _chessPlayers,
        difficulty: 'Semua Level',
        timeEstimate: '10-30 min',
        pageBuilder: (context) => ChessGamePage(
          sessionKey: widget.sessionKey,
          username: widget.username,
          role: widget.role,
        ),
      ),
      GameItem(
        id: 'asahotak',
        title: 'Asah Otak',
        subtitle: 'Teka-teki & Quiz',
        description: 'Uji kecerdasan dengan soal menarik',
        icon: Icons.psychology,
        gradientColors: const [
          Color(0xFF2196F3),
          Color(0xFF0D47A1),
        ],
        accentColor: const Color(0xFF2196F3),
        playerCountStream: _asahOtakPlayers,
        difficulty: 'Mudah - Sulit',
        timeEstimate: '5-15 min',
        pageBuilder: (context) => AsahOtakPage(
          sessionKey: widget.sessionKey,
          username: widget.username,
        ),
      ),
      GameItem(
        id: 'caklontong',
        title: 'Tebak Tebakan',
        subtitle: 'Games tebak tebak an',
        description: 'Jawaban aneh khas Gasima!',
        icon: Icons.lightbulb,
        gradientColors: const [
          Color(0xFFFF9F1C),
          Color(0xFFE65100),
        ],
        accentColor: const Color(0xFFFF9F1C),
        playerCountStream: _cakLontongPlayers,
        difficulty: 'Semua Level',
        timeEstimate: '30 detik/soal',
        pageBuilder: (context) => CakLontongPage(
          sessionKey: widget.sessionKey,
        ),
      ),
    ];
  }

  void _connectWebSocket() {
    try {
      _channel = WebSocketChannel.connect(Uri.parse(wsUrl));

      _channel!.stream.listen(
        _handleWebSocketMessage,
        onError: _handleWebSocketError,
        onDone: _handleWebSocketDone,
      );

      _channel!.sink.add(jsonEncode({
        'type': 'subscribe',
        'channel': 'game_stats',
        'sessionKey': widget.sessionKey,
      }));

      setState(() => _isConnected = true);

    } catch (e) {
      print('WebSocket connection error: $e');
      _scheduleReconnect();
    }
  }

  void _handleWebSocketMessage(dynamic message) {
    try {
      final data = jsonDecode(message);

      if (data['type'] == 'game_stats') {
        setState(() {
          _chessPlayers = data['chess'] ?? _chessPlayers;
          _asahOtakPlayers = data['asahotak'] ?? _asahOtakPlayers;
          _cakLontongPlayers = data['caklontong'] ?? _cakLontongPlayers;
          _totalOnline = data['total'] ?? 0;
        });
      }
    } catch (e) {
      print('Error parsing WebSocket message: $e');
    }
  }

  void _handleWebSocketError(error) {
    print('WebSocket error: $error');
    setState(() => _isConnected = false);
    _scheduleReconnect();
  }

  void _handleWebSocketDone() {
    print('WebSocket connection closed');
    setState(() => _isConnected = false);
    _scheduleReconnect();
  }

  void _scheduleReconnect() {
    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(const Duration(seconds: 5), () {
      if (mounted) {
        _connectWebSocket();
      }
    });
  }

  @override
  void dispose() {
    _reconnectTimer?.cancel();
    _channel?.sink.close(status.goingAway);
    _fadeController.dispose();
    super.dispose();
  }

  void _navigateToGame(GameItem game) {
    if (game.isComingSoon) {
      _showComingSoonDialog(game.title);
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: game.pageBuilder,
      ),
    ).then((_) {
      _channel?.sink.add(jsonEncode({
        'type': 'refresh_stats',
        'sessionKey': widget.sessionKey,
      }));
    });
  }

  void _showComingSoonDialog(String gameName) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: darkCard,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: Colors.orange.withOpacity(0.3), width: 1.5),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.orange.withOpacity(0.1),
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.orange.withOpacity(0.5)),
                ),
                child: const Icon(Icons.hourglass_empty, color: Colors.orange, size: 50),
              ),
              const SizedBox(height: 20),
              const Text(
                'COMING SOON',
                style: TextStyle(
                  color: Colors.orange,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                ),
              ),
              const SizedBox(height: 8),
              Text(
                gameName,
                style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),
              const Text(
                'Fitur ini akan segera hadir!\nNantikan update selanjutnya.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white70, fontSize: 14),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange.withOpacity(0.2),
                  foregroundColor: Colors.orange,
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: BorderSide(color: Colors.orange.withOpacity(0.5)),
                  ),
                ),
                child: const Text('OK'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _formatPlayerCount(int count) {
    if (count >= 1000000) {
      return '${(count / 1000000).toStringAsFixed(1)}M';
    } else if (count >= 1000) {
      return '${(count / 1000).toStringAsFixed(1)}K';
    }
    return count.toString();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: darkBg,
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [darkBg, const Color(0xFF151F2E)],
              ),
            ),
          ),

          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: CustomScrollView(
                physics: const BouncingScrollPhysics(),
                slivers: [
                  SliverToBoxAdapter(child: _buildHeader()),
                  const SliverToBoxAdapter(child: SizedBox(height: 20)),

                  SliverPadding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    sliver: SliverGrid(
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 14,
                        mainAxisSpacing: 14,
                        childAspectRatio: 0.85,
                      ),
                      delegate: SliverChildBuilderDelegate(
                            (context, index) => _buildGameCard(_games[index]),
                        childCount: _games.length,
                      ),
                    ),
                  ),

                  SliverToBoxAdapter(
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 30),
                      child: Center(
                        child: Text(
                          '© GASIMA • GAME ZONE',
                          style: TextStyle(
                            color: textSecondary.withOpacity(0.3),
                            fontSize: 10,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            Color(0xFF9C27B0),
            Color(0xFF2196F3),
            Color(0xFFFF9F1C),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.white.withOpacity(0.08),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.15),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Icon(Icons.games, color: Colors.white, size: 28),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'GASIMA GAME',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '👋 Hayy, ${widget.username}',
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.15),
              borderRadius: BorderRadius.circular(30),
            ),
            child: Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: _isConnected ? Colors.green : Colors.red,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  '${_formatPlayerCount(_totalOnline)} Peserta',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGameCard(GameItem game) {
    final int playerCount;
    switch (game.id) {
      case 'chess':
        playerCount = _chessPlayers;
        break;
      case 'asahotak':
        playerCount = _asahOtakPlayers;
        break;
      case 'caklontong':
        playerCount = _cakLontongPlayers;
        break;
      default:
        playerCount = 0;
    }

    return GestureDetector(
      onTap: () => _navigateToGame(game),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: game.gradientColors,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: game.accentColor.withOpacity(0.25),
              blurRadius: 12,
              spreadRadius: 0,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              bottom: -10,
              right: -10,
              child: Icon(
                game.icon,
                color: Colors.white.withOpacity(0.06),
                size: 80,
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(
                          game.icon,
                          color: Colors.white,
                          size: 22,
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          children: [
                            Icon(Icons.people, color: Colors.white70, size: 10),
                            const SizedBox(width: 2),
                            Text(
                              _formatPlayerCount(playerCount),
                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 9,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 12),

                  Text(
                    game.title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      letterSpacing: 0.5,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),

                  const SizedBox(height: 4),

                  Text(
                    game.subtitle,
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 11,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),

                  const SizedBox(height: 8),

                  Text(
                    game.description,
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.6),
                      fontSize: 10,
                      height: 1.3,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),

                  const Spacer(),

                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          game.difficulty,
                          style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 8,
                          ),
                        ),
                      ),
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          children: [
                            Icon(Icons.timer, color: Colors.white70, size: 8),
                            const SizedBox(width: 2),
                            Text(
                              game.timeEstimate,
                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 8,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class GameItem {
  final String id;
  final String title;
  final String subtitle;
  final String description;
  final IconData icon;
  final List<Color> gradientColors;
  final Color accentColor;
  final int playerCountStream;
  final String difficulty;
  final String timeEstimate;
  final bool isComingSoon;
  final WidgetBuilder pageBuilder;

  GameItem({
    this.id = '',
    required this.title,
    this.subtitle = '',
    this.description = '',
    required this.icon,
    this.gradientColors = const [Colors.blue, Colors.blueAccent],
    this.accentColor = Colors.blue,
    this.playerCountStream = 0,
    this.difficulty = 'Normal',
    this.timeEstimate = '5 min',
    this.isComingSoon = false,
    required this.pageBuilder,
  });
}