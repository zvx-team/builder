// ignore_for_file: use_build_context_synchronously
import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'sound_manager.dart';

// ─────────────────────────────────────────────────────────────
//  ShakeDetector  –  Manual implementation tanpa package shake
// ─────────────────────────────────────────────────────────────
class ShakeDetector {
  final VoidCallback onPhoneShake;
  final int minimumShakeCount;
  final int shakeSlopTimeMS;
  final int shakeCountResetTime;
  final double shakeThresholdGravity;

  static const _channel = EventChannel('flutter/accelerometer');
  StreamSubscription? _subscription;

  double _lastX = 0, _lastY = 0, _lastZ = 0;
  int _shakeCount = 0;
  int _lastShakeTime = 0;
  int _firstShakeTime = 0;

  ShakeDetector.autoStart({
    required this.onPhoneShake,
    this.minimumShakeCount = 2,
    this.shakeSlopTimeMS = 500,
    this.shakeCountResetTime = 3000,
    this.shakeThresholdGravity = 2.7,
  }) {
    _startListening();
  }

  void _startListening() {
    try {
      _subscription = _channel.receiveBroadcastStream().listen((event) {
        if (event is List && event.length >= 3) {
          _onAccelerometer(
            (event[0] as num).toDouble(),
            (event[1] as num).toDouble(),
            (event[2] as num).toDouble(),
          );
        }
      });
    } catch (_) {
      // Accelerometer tidak tersedia, gunakan timer sebagai fallback
    }
  }

  void _onAccelerometer(double x, double y, double z) {
    final now = DateTime.now().millisecondsSinceEpoch;
    final gX = x / 9.80665;
    final gY = y / 9.80665;
    final gZ = z / 9.80665;
    final gForce = sqrt(gX * gX + gY * gY + gZ * gZ);

    if (gForce < shakeThresholdGravity) return;
    if (now - _lastShakeTime < shakeSlopTimeMS) return;

    _lastShakeTime = now;

    if (_shakeCount == 0) _firstShakeTime = now;

    if (now - _firstShakeTime > shakeCountResetTime) {
      _shakeCount = 0;
      _firstShakeTime = now;
    }

    _shakeCount++;
    if (_shakeCount >= minimumShakeCount) {
      _shakeCount = 0;
      onPhoneShake();
    }
  }

  void stopListening() {
    _subscription?.cancel();
    _subscription = null;
  }
}

// ─────────────────────────────────────────────────────────────
//  ShakeAttackManager  –  Singleton controller shake detection
// ─────────────────────────────────────────────────────────────

class ShakeAttackManager {
  static const _keyEnabled = 'shake_attack_enabled';
  static const _keyTarget = 'shake_last_target';
  static const _keyCooldown = 'shake_cooldown_seconds';

  static ShakeDetector? _detector;
  static bool _enabled = false;
  static VoidCallback? _onShake;

  static Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _enabled = prefs.getBool(_keyEnabled) ?? false;
  }

  static bool get isEnabled => _enabled;

  static Future<void> setEnabled(bool v) async {
    _enabled = v;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyEnabled, v);
    if (!v) stop();
  }

  static Future<void> saveLastTarget(String target) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyTarget, target);
  }

  static Future<String> getLastTarget() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyTarget) ?? '';
  }

  static Future<int> getCooldown() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(_keyCooldown) ?? 5;
  }

  static Future<void> setCooldown(int seconds) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_keyCooldown, seconds);
  }

  /// Start listening for shakes. [callback] dipanggil setiap kali HP digoyangkan.
  static void start(VoidCallback callback) {
    stop(); // stop existing detector first
    _onShake = callback;
    _detector = ShakeDetector.autoStart(
      onPhoneShake: () {
        if (_enabled && _onShake != null) {
          _onShake!();
        }
      },
      minimumShakeCount: 2,
      shakeSlopTimeMS: 500,
      shakeCountResetTime: 3000,
      shakeThresholdGravity: 2.7,
    );
  }

  static void stop() {
    _detector?.stopListening();
    _detector = null;
    _onShake = null;
  }
}

// ─────────────────────────────────────────────────────────────
//  ShakeAttackOverlay  –  Overlay animasi saat shake detected
// ─────────────────────────────────────────────────────────────

class ShakeAttackOverlay extends StatefulWidget {
  final Widget child;
  final String target;
  final Future<void> Function(String target)? onShakeAttack;

  const ShakeAttackOverlay({
    super.key,
    required this.child,
    required this.target,
    this.onShakeAttack,
  });

  @override
  State<ShakeAttackOverlay> createState() => _ShakeAttackOverlayState();
}

class _ShakeAttackOverlayState extends State<ShakeAttackOverlay>
    with SingleTickerProviderStateMixin {
  bool _showFlash = false;
  late AnimationController _anim;
  late Animation<double> _scale;
  bool _isAttacking = false;
  int _cooldownLeft = 0;

  @override
  void initState() {
    super.initState();
    _anim = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );
    _scale = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _anim, curve: Curves.elasticOut),
    );

    _setupShake();
  }

  Future<void> _setupShake() async {
    await ShakeAttackManager.init();
    if (!ShakeAttackManager.isEnabled) return;

    ShakeAttackManager.start(() async {
      if (_isAttacking || _cooldownLeft > 0) return;
      await _triggerShakeAttack();
    });
  }

  Future<void> _triggerShakeAttack() async {
    if (!mounted) return;

    final target = widget.target;
    if (target.isEmpty) {
      _showNoTargetSnack();
      return;
    }

    setState(() {
      _showFlash = true;
      _isAttacking = true;
    });
    _anim.forward(from: 0);
    SoundManager.playAttack();

    // Execute attack
    if (widget.onShakeAttack != null) {
      await widget.onShakeAttack!(target);
    }

    // Cooldown
    final cooldown = await ShakeAttackManager.getCooldown();
    setState(() {
      _isAttacking = false;
      _showFlash = false;
      _cooldownLeft = cooldown;
    });

    // Countdown
    for (int i = cooldown; i > 0; i--) {
      await Future.delayed(const Duration(seconds: 1));
      if (mounted) setState(() { _cooldownLeft = i - 1; });
    }
    if (_cooldownLeft == 0 && mounted) SoundManager.playCooldown();
  }

  void _showNoTargetSnack() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text(
          '⚠️ Belum ada target! Set target dulu sebelum shake.',
          style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 12),
        ),
        backgroundColor: const Color(0xFF1A0000),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: Colors.red),
        ),
      ),
    );
  }

  @override
  void dispose() {
    ShakeAttackManager.stop();
    _anim.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        widget.child,

        // Flash overlay saat shake
        if (_showFlash)
          ScaleTransition(
            scale: _scale,
            child: Container(
              color: Colors.red.withOpacity(0.15),
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.bolt, color: Colors.red, size: 80),
                    const SizedBox(height: 10),
                    const Text('SHAKE ATTACK!', style: TextStyle(
                      color: Colors.red, fontFamily: 'Orbitron',
                      fontSize: 24, fontWeight: FontWeight.bold,
                      letterSpacing: 3,
                    )),
                    const SizedBox(height: 8),
                    Text(
                      'Target: ${widget.target}',
                      style: const TextStyle(
                        color: Colors.white70, fontFamily: 'ShareTechMono', fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

        // Cooldown badge
        if (_cooldownLeft > 0)
          Positioned(
            bottom: 100,
            right: 20,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: const Color(0xCC000000),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.orange.withOpacity(0.5)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.timer, color: Colors.orange, size: 14),
                  const SizedBox(width: 6),
                  Text(
                    'Shake CD: ${_cooldownLeft}s',
                    style: const TextStyle(
                      color: Colors.orange, fontFamily: 'ShareTechMono', fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────────
//  ShakeSettingsWidget  –  UI Settings shake di settings page
// ─────────────────────────────────────────────────────────────

class ShakeSettingsWidget extends StatefulWidget {
  const ShakeSettingsWidget({super.key});

  @override
  State<ShakeSettingsWidget> createState() => _ShakeSettingsWidgetState();
}

class _ShakeSettingsWidgetState extends State<ShakeSettingsWidget> {
  bool _enabled = false;
  String _lastTarget = '';
  int _cooldown = 5;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    await ShakeAttackManager.init();
    final target = await ShakeAttackManager.getLastTarget();
    final cd = await ShakeAttackManager.getCooldown();
    setState(() {
      _enabled = ShakeAttackManager.isEnabled;
      _lastTarget = target;
      _cooldown = cd;
    });
  }

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFF00C6FF);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('SHAKE TO ATTACK', style: TextStyle(
          color: accent, fontFamily: 'Orbitron', fontSize: 12,
          fontWeight: FontWeight.bold, letterSpacing: 2,
        )),
        const SizedBox(height: 12),

        // Toggle
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: const Color(0xFF071828),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: accent.withOpacity(0.15)),
          ),
          child: Row(
            children: [
              const Icon(Icons.vibration, color: accent, size: 20),
              const SizedBox(width: 14),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Shake to Attack', style: TextStyle(
                      color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 13,
                    )),
                    Text('Goyangkan HP → kirim bug ke target terakhir', style: TextStyle(
                      color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 10,
                    )),
                  ],
                ),
              ),
              Switch(
                value: _enabled,
                activeColor: accent,
                onChanged: (v) async {
                  await ShakeAttackManager.setEnabled(v);
                  setState(() { _enabled = v; });
                },
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),

        // Last target display
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: const Color(0xFF071828),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: accent.withOpacity(0.15)),
          ),
          child: Row(
            children: [
              const Icon(Icons.person_pin_outlined, color: accent, size: 20),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Target Terakhir', style: TextStyle(
                      color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 13,
                    )),
                    Text(
                      _lastTarget.isEmpty ? 'Belum ada target' : _lastTarget,
                      style: TextStyle(
                        color: _lastTarget.isEmpty ? Colors.white24 : accent,
                        fontFamily: 'ShareTechMono', fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),

        // Cooldown slider
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: const Color(0xFF071828),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: accent.withOpacity(0.15)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.timer_outlined, color: accent, size: 20),
                  const SizedBox(width: 14),
                  const Text('Cooldown Shake', style: TextStyle(
                    color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 13,
                  )),
                  const Spacer(),
                  Text('${_cooldown}s', style: const TextStyle(
                    color: accent, fontFamily: 'Orbitron', fontSize: 13,
                    fontWeight: FontWeight.bold,
                  )),
                ],
              ),
              Slider(
                value: _cooldown.toDouble(),
                min: 1, max: 60, divisions: 59,
                activeColor: accent,
                inactiveColor: accent.withOpacity(0.2),
                onChanged: (v) async {
                  setState(() { _cooldown = v.round(); });
                  await ShakeAttackManager.setCooldown(v.round());
                },
              ),
            ],
          ),
        ),
      ],
    );
  }
}
