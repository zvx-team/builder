import 'package:flutter/material.dart';
import 'package:flutter_js/flutter_js.dart';

class CekErrorPage extends StatefulWidget {
  const CekErrorPage({super.key});

  @override
  State<CekErrorPage> createState() => _CekErrorPageState();
}

class _CekErrorPageState extends State<CekErrorPage> {
  final TextEditingController _controller = TextEditingController();
  String _result = "";
  
  static const Color primaryWhite = Color(0xFFFFFFFF);

  final JavascriptRuntime jsRuntime = getJavascriptRuntime();

  void _checkError() {
    final code = _controller.text;
    final result = jsRuntime.evaluate(code);

    if (result.isError) {
      setState(() {
        _result = "🛠 Eror Terdeteksi:\n\n${result.stringResult}";
      });
    } else {
      setState(() {
        _result = "✅ Tidak ada error syntax.\n\nHasil: ${result.stringResult}";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("CEK ERROR CODE",
         style: TextStyle(
          color: primaryWhite,
          fontSize: 13,
          fontWeight: FontWeight.bold,
          letterSpacing: 1,
          fontFamily: "Orbitron",
         ),
       ),
      backgroundColor: const Color(0xFF660000),
     ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              maxLines: 10,
              style: const TextStyle(color: Color(0xFFFF4444)),
              decoration: const InputDecoration(
                hintText: "Paste function JS di sini...",
                hintStyle: TextStyle(color: Color(0xAA4444)),
                filled: true,
                fillColor: Color(0xFF330000),
              ),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: _checkError,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF990000),
                foregroundColor: Colors.white,
              ),
              child: const Text("🔍 Cek Error"),
            ),
            const SizedBox(height: 16),
            Text(
              _result,
              style: const TextStyle(color: Color(0xFFFF4444)),
            ),
          ],
        ),
      ),
    );
  }
}