import 'package:flutter/material.dart';

/// BrutalButton — Rounded Brutalist style
/// Otomatis pakai accent color dari theme.
/// Gunakan ini sebagai pengganti ElevatedButton, OutlinedButton, TextButton
/// di seluruh app (kecuali BottomNavigationBar).

class BrutalButton extends StatefulWidget {
  final VoidCallback? onPressed;
  final Widget child;
  final Color? accentColor;
  final Color? backgroundColor;
  final double borderRadius;
  final double borderWidth;
  final double shadowOffset;
  final EdgeInsetsGeometry? padding;
  final double? minimumWidth;
  final bool outlined; // true = transparan bg, border + text berwarna

  const BrutalButton({
    super.key,
    required this.onPressed,
    required this.child,
    this.accentColor,
    this.backgroundColor,
    this.borderRadius = 12,
    this.borderWidth = 2.5,
    this.shadowOffset = 4,
    this.padding,
    this.minimumWidth,
    this.outlined = false,
  });

  @override
  State<BrutalButton> createState() => _BrutalButtonState();
}

class _BrutalButtonState extends State<BrutalButton>
    with SingleTickerProviderStateMixin {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final accent = widget.accentColor ?? theme.colorScheme.primary;
    final bg = widget.outlined
        ? Colors.transparent
        : (widget.backgroundColor ?? Colors.black);
    final fgColor = widget.outlined ? accent : accent;

    return GestureDetector(
      onTapDown: widget.onPressed != null
          ? (_) => setState(() => _pressed = true)
          : null,
      onTapUp: widget.onPressed != null
          ? (_) {
              setState(() => _pressed = false);
              widget.onPressed?.call();
            }
          : null,
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 100),
        transform: _pressed
            ? (Matrix4.translationValues(widget.shadowOffset, widget.shadowOffset, 0))
            : Matrix4.identity(),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(widget.borderRadius),
          border: Border.all(
            color: widget.onPressed == null
                ? accent.withOpacity(0.3)
                : accent,
            width: widget.borderWidth,
          ),
          boxShadow: widget.onPressed == null
              ? null
              : _pressed
                  ? null
                  : [
                      BoxShadow(
                        color: accent,
                        offset: Offset(widget.shadowOffset, widget.shadowOffset),
                        blurRadius: 0,
                      ),
                    ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(widget.borderRadius),
            onTap: widget.onPressed,
            splashColor: accent.withOpacity(0.2),
            highlightColor: accent.withOpacity(0.08),
            child: Padding(
              padding: widget.padding ??
                  const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
              child: DefaultTextStyle(
                style: TextStyle(
                  color: widget.onPressed == null
                      ? fgColor.withOpacity(0.35)
                      : fgColor,
                  fontFamily: 'Orbitron',
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 2,
                ),
                child: IconTheme(
                  data: IconThemeData(
                    color: widget.onPressed == null
                        ? fgColor.withOpacity(0.35)
                        : fgColor,
                    size: 18,
                  ),
                  child: widget.child,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Versi dengan icon + label (mirip ElevatedButton.icon)
class BrutalButtonIcon extends StatelessWidget {
  final VoidCallback? onPressed;
  final Widget icon;
  final Widget label;
  final Color? accentColor;
  final Color? backgroundColor;
  final bool outlined;
  final EdgeInsetsGeometry? padding;

  const BrutalButtonIcon({
    super.key,
    required this.onPressed,
    required this.icon,
    required this.label,
    this.accentColor,
    this.backgroundColor,
    this.outlined = false,
    this.padding,
  });

  @override
  Widget build(BuildContext context) {
    return BrutalButton(
      onPressed: onPressed,
      accentColor: accentColor,
      backgroundColor: backgroundColor,
      outlined: outlined,
      padding: padding ?? const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          icon,
          const SizedBox(width: 8),
          label,
        ],
      ),
    );
  }
}

/// Versi minimal / text-only (pengganti TextButton di dialog, cancel, dll)
class BrutalTextButton extends StatelessWidget {
  final VoidCallback? onPressed;
  final Widget child;
  final Color? color;

  const BrutalTextButton({
    super.key,
    required this.onPressed,
    required this.child,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final accent = color ?? Theme.of(context).colorScheme.primary;
    return TextButton(
      onPressed: onPressed,
      style: TextButton.styleFrom(
        foregroundColor: accent,
        textStyle: const TextStyle(
          fontFamily: 'ShareTechMono',
          letterSpacing: 1.5,
          fontSize: 12,
        ),
      ),
      child: child,
    );
  }
}
