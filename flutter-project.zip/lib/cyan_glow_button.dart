import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Button style "Shadow God Mode" — Cyan pulse glow + sweep shimmer + explode on tap
class CyanGlowButton extends StatefulWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;
  final double? width;
  final double height;
  final Color glowColor;
  final double fontSize;

  const CyanGlowButton({
    super.key,
    required this.label,
    this.icon,
    this.onPressed,
    this.width,
    this.height = 54,
    this.glowColor = const Color(0xFF00FFFF),
    this.fontSize = 13,
  });

  @override
  State<CyanGlowButton> createState() => _CyanGlowButtonState();
}

class _CyanGlowButtonState extends State<CyanGlowButton>
    with TickerProviderStateMixin {

  // Pulse glow animation
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  // Shimmer sweep animation
  late AnimationController _shimmerCtrl;
  late Animation<double> _shimmerAnim;

  // Explode on tap animation
  late AnimationController _explodeCtrl;
  late Animation<double> _explodeAnim;
  late Animation<double> _explodeFadeAnim;

  bool _pressed = false;

  @override
  void initState() {
    super.initState();

    // Pulse: 0 0 10px → 0 0 30px → 0 0 10px loop
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 8, end: 28).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );

    // Shimmer sweep
    _shimmerCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _shimmerAnim = Tween<double>(begin: -1.5, end: 1.5).animate(
      CurvedAnimation(parent: _shimmerCtrl, curve: Curves.easeInOut),
    );

    // Explode
    _explodeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 400));
    _explodeAnim = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _explodeCtrl, curve: Curves.easeOut),
    );
    _explodeFadeAnim = Tween<double>(begin: 1, end: 0).animate(
      CurvedAnimation(parent: _explodeCtrl, curve: const Interval(0.4, 1.0, curve: Curves.easeOut)),
    );
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _shimmerCtrl.dispose();
    _explodeCtrl.dispose();
    super.dispose();
  }

  void _onTapDown(_) {
    HapticFeedback.lightImpact();
    setState(() => _pressed = true);
    _explodeCtrl.forward(from: 0);
  }

  void _onTapUp(_) => setState(() => _pressed = false);
  void _onTapCancel() => setState(() => _pressed = false);

  void _onHover(bool hovering) {
    if (hovering) {
      _shimmerCtrl.forward(from: 0);
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = widget.glowColor;
    final disabled = widget.onPressed == null;

    return MouseRegion(
      onEnter: (_) => _onHover(true),
      child: GestureDetector(
        onTapDown: disabled ? null : _onTapDown,
        onTapUp: disabled ? null : _onTapUp,
        onTapCancel: disabled ? null : _onTapCancel,
        onTap: disabled ? null : () {
          _shimmerCtrl.forward(from: 0);
          widget.onPressed?.call();
        },
        child: AnimatedBuilder(
          animation: Listenable.merge([_pulseAnim, _shimmerAnim, _explodeAnim]),
          builder: (context, child) {
            return AnimatedScale(
              scale: _pressed ? 0.92 : 1.0,
              duration: const Duration(milliseconds: 100),
              child: SizedBox(
                width: widget.width ?? double.infinity,
                height: widget.height,
                child: Stack(
                  children: [
                    // Base button with pulse glow
                    Container(
                      width: double.infinity,
                      height: double.infinity,
                      decoration: BoxDecoration(
                        color: Colors.black,
                        boxShadow: [
                          BoxShadow(
                            color: disabled
                                ? color.withOpacity(0.1)
                                : _pressed
                                    ? color.withOpacity(0.0)
                                    : color.withOpacity(0.5),
                            blurRadius: disabled ? 6 : _pressed ? 0 : _pulseAnim.value,
                            spreadRadius: disabled ? 0 : _pressed ? 0 : 1,
                          ),
                          if (_pressed)
                            BoxShadow(
                              color: color.withOpacity(0.4),
                              blurRadius: 20,
                              spreadRadius: 2,
                            ),
                        ],
                        border: Border.all(
                          color: disabled ? color.withOpacity(0.2) : color.withOpacity(0.6),
                          width: 1,
                        ),
                      ),
                      child: ClipRect(
                        child: Stack(
                          children: [
                            // Shimmer sweep layer
                            Positioned.fill(
                              child: Transform.translate(
                                offset: Offset(_shimmerAnim.value * 200, 0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [
                                        Colors.transparent,
                                        Colors.white.withOpacity(0.35),
                                        Colors.transparent,
                                      ],
                                      stops: const [0.3, 0.5, 0.7],
                                      transform: const GradientRotation(pi / 6),
                                    ),
                                  ),
                                ),
                              ),
                            ),

                            // Content
                            Center(
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  if (widget.icon != null) ...[
                                    Icon(widget.icon,
                                      color: disabled ? color.withOpacity(0.3) : Colors.white,
                                      size: 16,
                                    ),
                                    const SizedBox(width: 8),
                                  ],
                                  Text(
                                    widget.label,
                                    style: TextStyle(
                                      color: disabled ? Colors.white30 : Colors.white,
                                      fontSize: widget.fontSize,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 2,
                                      fontFamily: 'Orbitron',
                                      shadows: disabled ? [] : [
                                        Shadow(color: color.withOpacity(0.6), blurRadius: 8),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    // Explode layer
                    if (_explodeCtrl.isAnimating || _explodeCtrl.value > 0)
                      Positioned.fill(
                        child: FadeTransition(
                          opacity: _explodeFadeAnim,
                          child: ScaleTransition(
                            scale: _explodeAnim,
                            child: Container(
                              decoration: BoxDecoration(
                                gradient: RadialGradient(
                                  colors: [
                                    color.withOpacity(0.5),
                                    Colors.transparent,
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

/// Versi cooldown — otomatis ganti warna + teks pas cooldown aktif
class CyanGlowButtonCooldown extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;
  final bool isCooldown;
  final int cooldownSeconds;
  final bool isLoading;
  final Color glowColor;

  const CyanGlowButtonCooldown({
    super.key,
    required this.label,
    this.icon,
    this.onPressed,
    this.isCooldown = false,
    this.cooldownSeconds = 0,
    this.isLoading = false,
    this.glowColor = const Color(0xFF00FFFF),
  });

  @override
  Widget build(BuildContext context) {
    String displayLabel = isLoading
        ? 'MENGIRIM...'
        : isCooldown
            ? 'COOLDOWN ${cooldownSeconds}s'
            : label;

    Color effectiveGlow = isCooldown
        ? Colors.orange
        : isLoading
            ? Colors.white38
            : glowColor;

    return CyanGlowButton(
      label: displayLabel,
      icon: isLoading
          ? null
          : isCooldown
              ? Icons.timer
              : icon,
      onPressed: (isCooldown || isLoading) ? null : onPressed,
      glowColor: effectiveGlow,
    );
  }
}
