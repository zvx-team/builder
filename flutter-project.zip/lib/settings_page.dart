// ignore_for_file: use_build_context_synchronously
import 'package:flutter/material.dart';
import 'theme_provider.dart';
import 'pin_lock.dart';
import 'sound_manager.dart';
import 'shake_attack.dart';
import 'sound_manager.dart';

// ─────────────────────────────────────────────────────────────
//  SettingsPage  –  Halaman pengaturan lengkap RDP
//  Menggabungkan: Theme Builder, Splash Custom, Sound Effects,
//                 Shake to Attack, PIN Lock / Biometric
// ─────────────────────────────────────────────────────────────

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = AppThemeScope.of(context);
    final accent = themeProvider.accent;
    final bg = themeProvider.bg;

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: bg,
        title: Text(
          'SETTINGS',
          style: TextStyle(
            color: accent,
            fontFamily: 'Orbitron',
            fontSize: 16,
            fontWeight: FontWeight.bold,
            letterSpacing: 3,
          ),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: accent, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // ── 16. CUSTOM THEME BUILDER ──
          _Section(
            title: '16 — CUSTOM THEME',
            icon: Icons.palette_outlined,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Pilih warna tema aplikasi',
                  style: TextStyle(
                    color: Colors.white54,
                    fontFamily: 'ShareTechMono',
                    fontSize: 12,
                  ),
                ),
                const SizedBox(height: 12),
                // Inline theme grid (reuse kAppThemes dari theme_provider)
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 4,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                    childAspectRatio: 0.82,
                  ),
                  itemCount: kAppThemes.length,
                  itemBuilder: (ctx, i) {
                    final theme = kAppThemes[i];
                    final isActive = themeProvider.current.id == theme.id;
                    return GestureDetector(
                      onTap: () => themeProvider.setTheme(theme),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        decoration: BoxDecoration(
                          color: theme.bg,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: isActive ? theme.accent : theme.accent.withOpacity(0.2),
                            width: isActive ? 2 : 1,
                          ),
                          boxShadow: isActive
                              ? [BoxShadow(color: theme.accent.withOpacity(0.35), blurRadius: 14, spreadRadius: 1)]
                              : null,
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              width: 32, height: 32,
                              decoration: BoxDecoration(
                                color: theme.accent.withOpacity(0.15),
                                shape: BoxShape.circle,
                                border: Border.all(color: theme.accent.withOpacity(0.6)),
                              ),
                              child: Icon(theme.icon, color: theme.accent, size: 15),
                            ),
                            const SizedBox(height: 6),
                            Text(theme.name, style: TextStyle(
                              color: isActive ? theme.accent : Colors.white54,
                              fontFamily: 'Orbitron', fontSize: 8,
                              fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                              letterSpacing: 1,
                            ), textAlign: TextAlign.center),
                            if (isActive) ...[
                              const SizedBox(height: 2),
                              Icon(Icons.check_circle, color: theme.accent, size: 10),
                            ],
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // ── 18. SOUND EFFECTS ──
          _Section(
            title: '18 — SOUND EFFECTS',
            icon: Icons.volume_up_rounded,
            child: const SoundSettingsWidget(),
          ),

          const SizedBox(height: 16),

          // ── 19. SHAKE TO ATTACK ──
          _Section(
            title: '19 — SHAKE TO ATTACK',
            icon: Icons.vibration,
            child: const ShakeSettingsWidget(),
          ),

          const SizedBox(height: 16),

          // ── 20. PIN LOCK / BIOMETRIC ──
          _Section(
            title: '20 — PIN LOCK / BIOMETRIC',
            icon: Icons.lock_outline,
            child: const PinSettingsWidget(),
          ),

          const SizedBox(height: 40),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
//  _Section  –  Container card per fitur
// ─────────────────────────────────────────────────────────────

class _Section extends StatefulWidget {
  final String title;
  final IconData icon;
  final Widget child;

  const _Section({
    required this.title,
    required this.icon,
    required this.child,
  });

  @override
  State<_Section> createState() => _SectionState();
}

class _SectionState extends State<_Section> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    final themeProvider = AppThemeScope.of(context);
    final accent = themeProvider.accent;
    final card = themeProvider.card;

    return Container(
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: accent.withOpacity(0.15)),
      ),
      child: Column(
        children: [
          // Header
          GestureDetector(
            onTap: () => setState(() { _expanded = !_expanded; }),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                borderRadius: _expanded
                    ? const BorderRadius.vertical(top: Radius.circular(16))
                    : BorderRadius.circular(16),
              ),
              child: Row(
                children: [
                  Icon(widget.icon, color: accent, size: 20),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      widget.title,
                      style: TextStyle(
                        color: accent,
                        fontFamily: 'Orbitron',
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                  Icon(
                    _expanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
                    color: accent.withOpacity(0.6),
                    size: 20,
                  ),
                ],
              ),
            ),
          ),

          // Content (accordion)
          AnimatedSize(
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeInOut,
            child: _expanded
                ? Container(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                    child: widget.child,
                  )
                : const SizedBox.shrink(),
          ),
        ],
      ),
    );
  }
}
