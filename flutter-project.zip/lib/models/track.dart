class Artist {
  final String name;
  final String? artistId;

  Artist({required this.name, this.artistId});

  factory Artist.fromJson(Map<String, dynamic> json) {
    return Artist(
      name: json['name'] ?? 'Unknown Artist',
      artistId: json['artistId'],
    );
  }
}

class Thumbnail {
  final String url;
  final int width;
  final int height;

  Thumbnail({required this.url, required this.width, required this.height});

  factory Thumbnail.fromJson(Map<String, dynamic> json) {
    return Thumbnail(
      url: json['url'] ?? '',
      width: json['width'] ?? 0,
      height: json['height'] ?? 0,
    );
  }
}

/// Mirrors the `Track` interface from lib/store.ts in the web version.
class Track {
  final String videoId;
  final String name;
  final List<Artist> artists;
  final List<Thumbnail> thumbnails;
  final int? durationSeconds;
  final bool isExplicit;

  Track({
    required this.videoId,
    required this.name,
    required this.artists,
    required this.thumbnails,
    this.durationSeconds,
    this.isExplicit = false,
  });

  String get artistNames => artists.map((a) => a.name).join(', ');

  /// Best available thumbnail, falling back to a placeholder.
  String get thumbnailUrl {
    if (thumbnails.isEmpty) return '';
    return thumbnails.last.url;
  }

  factory Track.fromJson(Map<String, dynamic> json) {
    final rawArtist = json['artist'];
    List<Artist> artists = [];
    if (rawArtist is List) {
      artists = rawArtist.map((a) => Artist.fromJson(a)).toList();
    } else if (rawArtist is Map<String, dynamic>) {
      artists = [Artist.fromJson(rawArtist)];
    }

    final rawThumbs = (json['thumbnails'] as List?) ?? [];

    return Track(
      videoId: json['videoId'] ?? '',
      name: json['name'] ?? 'Unknown Title',
      artists: artists,
      thumbnails: rawThumbs.map((t) => Thumbnail.fromJson(t)).toList(),
      durationSeconds: json['duration'],
      isExplicit: json['isExplicit'] ?? false,
    );
  }

  Map<String, dynamic> toJson() => {
        'videoId': videoId,
        'name': name,
        'artist': artists.map((a) => {'name': a.name, 'artistId': a.artistId}).toList(),
        'thumbnails': thumbnails
            .map((t) => {'url': t.url, 'width': t.width, 'height': t.height})
            .toList(),
        'duration': durationSeconds,
        'isExplicit': isExplicit,
      };
}
