import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'theme_provider.dart';

class SholatPage extends StatefulWidget {
  const SholatPage({super.key});

  @override
  State<SholatPage> createState() => _SholatPageState();
}

class _SholatPageState extends State<SholatPage> with TickerProviderStateMixin {
  Map<String, String> _jadwal = {};
  String _kota = 'Jakarta';
  String _tanggal = '';
  bool _isLoading = false;
  String _error = '';
  Timer? _clockTimer;
  DateTime _now = DateTime.now();
  String? _nextSholat;
  Duration _countdown = Duration.zero;

  final _kotaCtrl = TextEditingController(text: 'Jakarta');

  // Nama sholat dan ikonnya
  final List<Map<String, dynamic>> _sholatList = [
    {'key': 'Imsak', 'icon': Icons.nightlight_round, 'color': const Color(0xFF6C63FF)},
    {'key': 'Subuh', 'icon': Icons.wb_twilight, 'color': const Color(0xFFFF6B6B)},
    {'key': 'Dhuha', 'icon': Icons.wb_sunny_outlined, 'color': const Color(0xFFFFD93D)},
    {'key': 'Dzuhur', 'icon': Icons.wb_sunny, 'color': const Color(0xFFFF9A3C)},
    {'key': 'Ashar', 'icon': Icons.sunny_snowing, 'color': const Color(0xFF4ECDC4)},
    {'key': 'Maghrib', 'icon': Icons.nights_stay_outlined, 'color': const Color(0xFFFF6B9D)},
    {'key': 'Isya', 'icon': Icons.nightlight, 'color': const Color(0xFF6C63FF)},
  ];

  @override
  void initState() {
    super.initState();
    _fetchJadwal();
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {
        _now = DateTime.now();
        _updateCountdown();
      });
    });
  }

  @override
  void dispose() {
    _clockTimer?.cancel();
    _kotaCtrl.dispose();
    super.dispose();
  }

  Future<void> _fetchJadwal() async {
    setState(() { _isLoading = true; _error = ''; });
    try {
      final now = DateTime.now();
      final res = await http.get(
        Uri.parse('https://api.aladhan.com/v1/timingsByCity/${now.day}-${now.month}-${now.year}?city=${Uri.encodeComponent(_kota)}&country=Indonesia&method=11'),
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);

      if (data['code'] == 200) {
        final t = data['data']['timings'] as Map<String, dynamic>;
        // Aladhan returns time like "04:30 (WIB)" — trim timezone suffix
        String cleanTime(String? raw) {
          if (raw == null) return '-';
          return raw.split(' ').first; // ambil "04:30" aja
        }
        setState(() {
          _jadwal = {
            'Imsak':   cleanTime(t['Imsak']),
            'Subuh':   cleanTime(t['Fajr']),
            'Dhuha':   cleanTime(t['Sunrise']),
            'Dzuhur':  cleanTime(t['Dhuhr']),
            'Ashar':   cleanTime(t['Asr']),
            'Maghrib': cleanTime(t['Maghrib']),
            'Isya':    cleanTime(t['Isha']),
          };
          _tanggal = '${now.day}/${now.month}/${now.year}';
          _isLoading = false;
        });
        _updateCountdown();
      } else {
        setState(() { _error = 'Data tidak tersedia (code: ${data['code']})'; _isLoading = false; });
      }
    } catch (e) {
      setState(() { _error = 'Gagal mengambil data:\n${e.toString().substring(0, e.toString().length.clamp(0, 100))}'; _isLoading = false; });
    }
  }

  void _updateCountdown() {
    if (_jadwal.isEmpty) return;
    final now = _now;
    String? next;
    Duration? minDiff;

    for (final s in _sholatList) {
      final key = s['key'] as String;
      final timeStr = _jadwal[key];
      if (timeStr == null || timeStr == '-') continue;
      final parts = timeStr.split(':');
      if (parts.length < 2) continue;
      var target = DateTime(now.year, now.month, now.day, int.parse(parts[0]), int.parse(parts[1]));
      if (target.isBefore(now)) target = target.add(const Duration(days: 1));
      final diff = target.difference(now);
      if (minDiff == null || diff < minDiff) {
        minDiff = diff;
        next = key;
      }
    }

    _nextSholat = next;
    _countdown = minDiff ?? Duration.zero;
  }

  String _fmtCountdown(Duration d) {
    final h = d.inHours.toString().padLeft(2, '0');
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$h:$m:$s';
  }

  bool _isWaktuIni(String key) {
    if (_jadwal.isEmpty || !_jadwal.containsKey(key)) return false;
    final timeStr = _jadwal[key]!;
    final parts = timeStr.split(':');
    if (parts.length < 2) return false;
    final waktu = DateTime(_now.year, _now.month, _now.day, int.parse(parts[0]), int.parse(parts[1]));
    
    // cari sholat berikutnya
    final keys = _sholatList.map((s) => s['key'] as String).toList();
    final idx = keys.indexOf(key);
    if (idx < 0) return false;
    
    DateTime? nextWaktu;
    for (int i = idx + 1; i < keys.length; i++) {
      final nextStr = _jadwal[keys[i]];
      if (nextStr == null || nextStr == '-') continue;
      final np = nextStr.split(':');
      if (np.length < 2) continue;
      nextWaktu = DateTime(_now.year, _now.month, _now.day, int.parse(np[0]), int.parse(np[1]));
      break;
    }
    nextWaktu ??= waktu.add(const Duration(hours: 2));
    return _now.isAfter(waktu) && _now.isBefore(nextWaktu);
  }

  @override
  Widget build(BuildContext context) {
    final theme = AppThemeScope.of(context);
    return Scaffold(
      backgroundColor: theme.bg,
      body: Column(
        children: [
          _buildHeader(theme),
          Expanded(
            child: _isLoading
                ? Center(child: CircularProgressIndicator(color: theme.accent))
                : _error.isNotEmpty
                    ? _buildError(theme)
                    : _buildContent(theme),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(ThemeProvider theme) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 50, 16, 16),
      decoration: BoxDecoration(
        color: theme.card,
        border: Border(bottom: BorderSide(color: theme.accent.withOpacity(0.2))),
      ),
      child: Row(
        children: [
          IconButton(
            icon: Icon(Icons.arrow_back_ios_new, color: theme.accent, size: 20),
            onPressed: () => Navigator.pop(context),
          ),
          const SizedBox(width: 8),
          Icon(Icons.mosque_rounded, color: theme.accent, size: 26),
          const SizedBox(width: 10),
          Text('JADWAL SHOLAT', style: TextStyle(
            color: theme.accent, fontSize: 18, fontWeight: FontWeight.w900,
            fontFamily: 'Orbitron', letterSpacing: 2,
          )),
        ],
      ),
    );
  }

  Widget _buildError(ThemeProvider theme) {
    return Center(child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(Icons.error_outline, color: theme.accent, size: 60),
        const SizedBox(height: 16),
        Text(_error, style: const TextStyle(color: Colors.white54), textAlign: TextAlign.center),
        const SizedBox(height: 20),
        ElevatedButton(
          onPressed: _fetchJadwal,
          style: ElevatedButton.styleFrom(backgroundColor: theme.accent, foregroundColor: theme.bg),
          child: const Text('Coba Lagi'),
        ),
      ],
    ));
  }

  Widget _buildContent(ThemeProvider theme) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
      children: [
        // Jam sekarang
        _buildClockCard(theme),
        const SizedBox(height: 14),
        // City search
        _buildCitySearch(theme),
        const SizedBox(height: 14),
        // Countdown ke sholat berikutnya
        if (_nextSholat != null) _buildCountdownCard(theme),
        const SizedBox(height: 14),
        // Tanggal
        if (_tanggal.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Text(_tanggal, style: TextStyle(color: theme.accent.withOpacity(0.7), fontSize: 13, fontFamily: 'ShareTechMono'), textAlign: TextAlign.center),
          ),
        // List jadwal
        ..._sholatList.map((s) => _buildSholatCard(theme, s)).toList(),
        const SizedBox(height: 10),
        // Refresh button
        OutlinedButton.icon(
          onPressed: _fetchJadwal,
          icon: Icon(Icons.refresh, color: theme.accent),
          label: Text('Perbarui Jadwal', style: TextStyle(color: theme.accent)),
          style: OutlinedButton.styleFrom(
            side: BorderSide(color: theme.accent.withOpacity(0.4)),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            padding: const EdgeInsets.symmetric(vertical: 12),
          ),
        ),
      ],
    );
  }

  Widget _buildCitySearch(ThemeProvider theme) {
    return Row(
      children: [
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              color: theme.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: theme.accent.withOpacity(0.3)),
            ),
            child: TextField(
              controller: _kotaCtrl,
              style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono'),
              decoration: InputDecoration(
                hintText: 'Masukkan kota...',
                hintStyle: const TextStyle(color: Colors.white38),
                prefixIcon: Icon(Icons.location_city, color: theme.accent, size: 20),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(vertical: 13),
              ),
              onSubmitted: (val) {
                if (val.trim().isNotEmpty) {
                  setState(() => _kota = val.trim());
                  _fetchJadwal();
                }
              },
            ),
          ),
        ),
        const SizedBox(width: 10),
        GestureDetector(
          onTap: () {
            final val = _kotaCtrl.text.trim();
            if (val.isNotEmpty) {
              setState(() => _kota = val);
              _fetchJadwal();
            }
          },
          child: Container(
            padding: const EdgeInsets.all(13),
            decoration: BoxDecoration(
              color: theme.accent,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(Icons.search, color: theme.bg, size: 22),
          ),
        ),
      ],
    );
  }

  Widget _buildClockCard(ThemeProvider theme) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [theme.accent.withOpacity(0.2), theme.card],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: theme.accent.withOpacity(0.3)),
        boxShadow: [BoxShadow(color: theme.accent.withOpacity(0.08), blurRadius: 20)],
      ),
      child: Column(
        children: [
          Text(
            DateFormat('HH:mm:ss').format(_now),
            style: TextStyle(
              color: theme.accent, fontSize: 48, fontWeight: FontWeight.w900,
              fontFamily: 'Orbitron', letterSpacing: 4,
              shadows: [Shadow(color: theme.accent.withOpacity(0.5), blurRadius: 20)],
            ),
          ),
          const SizedBox(height: 4),
          Text(
            DateFormat('EEEE, d MMMM yyyy', 'id').format(_now),
            style: const TextStyle(color: Colors.white60, fontSize: 14),
          ),
        ],
      ),
    );
  }

  Widget _buildCountdownCard(ThemeProvider theme) {
    final sholatData = _sholatList.firstWhere(
      (s) => s['key'] == _nextSholat,
      orElse: () => {'key': _nextSholat, 'icon': Icons.access_time, 'color': theme.accent},
    );
    final color = sholatData['color'] as Color;

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: color.withOpacity(0.2), shape: BoxShape.circle),
            child: Icon(sholatData['icon'] as IconData, color: color, size: 28),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Sholat Berikutnya', style: TextStyle(color: color.withOpacity(0.7), fontSize: 12)),
                Text(_nextSholat!, style: TextStyle(color: color, fontSize: 18, fontWeight: FontWeight.bold)),
                Text(_jadwal[_nextSholat!] ?? '', style: const TextStyle(color: Colors.white54, fontSize: 13)),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text('Menuju', style: TextStyle(color: color.withOpacity(0.7), fontSize: 11)),
              Text(
                _fmtCountdown(_countdown),
                style: TextStyle(
                  color: color, fontSize: 22, fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  shadows: [Shadow(color: color.withOpacity(0.5), blurRadius: 10)],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSholatCard(ThemeProvider theme, Map<String, dynamic> s) {
    final key = s['key'] as String;
    final time = _jadwal[key] ?? '-';
    final color = s['color'] as Color;
    final isNext = _nextSholat == key;
    final isNow = _isWaktuIni(key);

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isNow ? color.withOpacity(0.15) : isNext ? theme.accent.withOpacity(0.08) : theme.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isNow ? color.withOpacity(0.6) : isNext ? theme.accent.withOpacity(0.4) : Colors.white.withOpacity(0.05),
          width: isNow ? 1.5 : 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 44, height: 44,
            decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(12)),
            child: Icon(s['icon'] as IconData, color: color, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(key, style: TextStyle(
                  color: isNow ? color : Colors.white,
                  fontWeight: FontWeight.bold, fontSize: 16,
                )),
                if (isNow) Text('Waktu Sekarang', style: TextStyle(color: color.withOpacity(0.8), fontSize: 11)),
                if (isNext && !isNow) Text('Berikutnya', style: TextStyle(color: theme.accent.withOpacity(0.7), fontSize: 11)),
              ],
            ),
          ),
          Text(time, style: TextStyle(
            color: isNow ? color : isNext ? theme.accent : Colors.white70,
            fontSize: 20, fontWeight: FontWeight.w900,
            fontFamily: 'Orbitron',
          )),
        ],
      ),
    );
  }
}
