// wa_blast_page.dart
import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'theme_provider.dart';
import 'cyan_glow_button.dart';

class WaBlastPage extends StatefulWidget {
  final String sessionKey;
  const WaBlastPage({super.key, required this.sessionKey});

  @override
  State<WaBlastPage> createState() => _WaBlastPageState();
}

class _WaBlastPageState extends State<WaBlastPage>
    with TickerProviderStateMixin {
  static const String _baseUrl = 'http://arullll.private-rexy.web.id:11235';

  // Controllers
  final _numbersCtrl = TextEditingController();
  final _messageCtrl = TextEditingController();
  final _delayCtrl = TextEditingController(text: '2');
  final _scrollCtrl = ScrollController();

  // State
  bool _isBlasting = false;
  bool _isPaused = false;
  int _successCount = 0;
  int _failCount = 0;
  int _totalCount = 0;
  int _currentIndex = 0;
  String _senderType = 'global'; // global | private
  List<String> _logs = [];
  List<String> _numbers = [];

  // Blast control
  bool _stopFlag = false;

  // Animations
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _numbersCtrl.dispose();
    _messageCtrl.dispose();
    _delayCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  // ── Parse nomor ────────────────────────────────────────────────
  List<String> _parseNumbers(String raw) {
    final lines = raw.split(RegExp(r'[\n,;]+'));
    final result = <String>[];
    for (final line in lines) {
      final cleaned = line.trim().replaceAll(RegExp(r'[^\d]'), '');
      if (cleaned.length >= 8) result.add(cleaned);
    }
    return result.toSet().toList(); // deduplicate
  }

  // ── Add log ────────────────────────────────────────────────────
  void _addLog(String msg) {
    setState(() => _logs.add('[${_timestamp()}] $msg'));
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  String _timestamp() {
    final now = DateTime.now();
    return '${now.hour.toString().padLeft(2, '0')}:'
        '${now.minute.toString().padLeft(2, '0')}:'
        '${now.second.toString().padLeft(2, '0')}';
  }

  // ── Start blast ────────────────────────────────────────────────
  Future<void> _startBlast() async {
    final numbers = _parseNumbers(_numbersCtrl.text);
    final message = _messageCtrl.text.trim();
    final delaySeconds = int.tryParse(_delayCtrl.text.trim()) ?? 2;

    if (numbers.isEmpty) {
      _showSnack('❌ Masukkan minimal 1 nomor tujuan');
      return;
    }
    if (message.isEmpty) {
      _showSnack('❌ Pesan tidak boleh kosong');
      return;
    }

    setState(() {
      _isBlasting = true;
      _isPaused = false;
      _stopFlag = false;
      _numbers = numbers;
      _totalCount = numbers.length;
      _successCount = 0;
      _failCount = 0;
      _currentIndex = 0;
      _logs = [];
    });

    _addLog('🚀 Blast dimulai — ${numbers.length} nomor | delay ${delaySeconds}s');

    for (int i = 0; i < numbers.length; i++) {
      if (_stopFlag) {
        _addLog('🛑 Blast dihentikan oleh user');
        break;
      }

      // Handle pause
      while (_isPaused && !_stopFlag) {
        await Future.delayed(const Duration(milliseconds: 500));
      }
      if (_stopFlag) break;

      final number = numbers[i];
      setState(() => _currentIndex = i + 1);

      try {
        final url = Uri.parse(
          '$_baseUrl/api/whatsapp/blastMessage'
          '?key=${widget.sessionKey}'
          '&target=$number'
          '&message=${Uri.encodeComponent(message)}'
          '&senderType=$_senderType',
        );

        final res = await http.get(url).timeout(const Duration(seconds: 15));
        final data = jsonDecode(res.body);

        if (data['valid'] == true && data['sended'] == true) {
          setState(() => _successCount++);
          _addLog('✅ $number — Terkirim');
        } else {
          setState(() => _failCount++);
          _addLog('❌ $number — ${data['message'] ?? 'Gagal'}');
        }
      } on TimeoutException {
        setState(() => _failCount++);
        _addLog('⏱ $number — Timeout');
      } catch (e) {
        setState(() => _failCount++);
        _addLog('❌ $number — Error: $e');
      }

      // Delay antar kirim (kecuali nomor terakhir)
      if (i < numbers.length - 1 && !_stopFlag) {
        await Future.delayed(Duration(seconds: delaySeconds));
      }
    }

    if (mounted) {
      setState(() {
        _isBlasting = false;
        _isPaused = false;
      });
      _addLog(
        '🏁 Selesai — ✅ $_successCount berhasil | ❌ $_failCount gagal',
      );
    }
  }

  void _pauseResume() {
    setState(() => _isPaused = !_isPaused);
    _addLog(_isPaused ? '⏸ Dijeda...' : '▶️ Dilanjutkan');
  }

  void _stopBlast() {
    setState(() => _stopFlag = true);
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(fontFamily: 'ShareTechMono')),
        backgroundColor: Colors.black87,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // ── Build ──────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final theme = AppThemeScope.of(context);
    final accent = theme.accent;
    final bg = theme.bg;
    final card = theme.card;

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: accent, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            Icon(Icons.send_rounded, color: accent, size: 18),
            const SizedBox(width: 8),
            Text(
              'WA BLAST',
              style: TextStyle(
                color: accent,
                fontFamily: 'Orbitron',
                fontSize: 16,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
              ),
            ),
          ],
        ),
        actions: [
          if (_isBlasting)
            Padding(
              padding: const EdgeInsets.only(right: 16),
              child: AnimatedBuilder(
                animation: _pulseAnim,
                builder: (_, __) => Opacity(
                  opacity: _pulseAnim.value,
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: accent.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: accent.withOpacity(0.4)),
                    ),
                    child: Text(
                      '$_currentIndex/$_totalCount',
                      style: TextStyle(
                        color: accent,
                        fontFamily: 'ShareTechMono',
                        fontSize: 12,
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
      body: Column(
        children: [
          // Progress bar
          if (_isBlasting || _totalCount > 0) _buildProgressBar(accent),

          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Stats row
                  if (_totalCount > 0) _buildStatsRow(accent, card),

                  const SizedBox(height: 14),

                  // Sender type toggle
                  _buildSectionLabel('SENDER TYPE', accent),
                  const SizedBox(height: 8),
                  _buildSenderToggle(accent, card),
                  const SizedBox(height: 16),

                  // Numbers input
                  _buildSectionLabel('NOMOR TUJUAN', accent),
                  const SizedBox(height: 8),
                  _buildNumbersField(accent, card),
                  const SizedBox(height: 4),
                  Text(
                    'Pisahkan dengan enter, koma, atau titik koma. Duplikat otomatis dihapus.',
                    style: TextStyle(
                      color: Colors.white38,
                      fontSize: 11,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Message input
                  _buildSectionLabel('PESAN', accent),
                  const SizedBox(height: 8),
                  _buildMessageField(accent, card),
                  const SizedBox(height: 16),

                  // Delay
                  _buildSectionLabel('DELAY (DETIK)', accent),
                  const SizedBox(height: 8),
                  _buildDelayField(accent, card),
                  const SizedBox(height: 24),

                  // Action buttons
                  _buildActionButtons(accent),
                  const SizedBox(height: 20),

                  // Log
                  if (_logs.isNotEmpty) ...[
                    _buildSectionLabel('LOG', accent),
                    const SizedBox(height: 8),
                    _buildLogView(accent, card),
                    const SizedBox(height: 20),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Sub-widgets ───────────────────────────────────────────────

  Widget _buildProgressBar(Color accent) {
    final progress = _totalCount == 0 ? 0.0 : _currentIndex / _totalCount;
    return Container(
      height: 3,
      child: LinearProgressIndicator(
        value: progress,
        backgroundColor: Colors.white10,
        valueColor: AlwaysStoppedAnimation<Color>(accent),
      ),
    );
  }

  Widget _buildStatsRow(Color accent, Color card) {
    return Row(
      children: [
        _statChip('TOTAL', '$_totalCount', Colors.white54, card),
        const SizedBox(width: 8),
        _statChip('✅', '$_successCount', const Color(0xFF00E676), card),
        const SizedBox(width: 8),
        _statChip('❌', '$_failCount', const Color(0xFFFF5252), card),
      ],
    );
  }

  Widget _statChip(String label, String value, Color color, Color card) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: card,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          children: [
            Text(label,
                style: TextStyle(
                    color: Colors.white38,
                    fontSize: 10,
                    fontFamily: 'ShareTechMono')),
            const SizedBox(height: 4),
            Text(value,
                style: TextStyle(
                    color: color,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron')),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionLabel(String label, Color accent) {
    return Row(
      children: [
        Container(width: 3, height: 14, color: accent),
        const SizedBox(width: 8),
        Text(label,
            style: TextStyle(
                color: accent,
                fontSize: 11,
                fontFamily: 'Orbitron',
                letterSpacing: 1.5,
                fontWeight: FontWeight.bold)),
      ],
    );
  }

  Widget _buildSenderToggle(Color accent, Color card) {
    return Row(
      children: [
        _senderBtn('global', Icons.public, 'Global', accent, card),
        const SizedBox(width: 10),
        _senderBtn('private', Icons.person_outline, 'Private', accent, card),
      ],
    );
  }

  Widget _senderBtn(
      String type, IconData icon, String label, Color accent, Color card) {
    final isSelected = _senderType == type;
    return Expanded(
      child: GestureDetector(
        onTap: _isBlasting ? null : () => setState(() => _senderType = type),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isSelected ? accent.withOpacity(0.12) : card,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isSelected ? accent : Colors.white12,
              width: isSelected ? 1.5 : 1,
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon,
                  color: isSelected ? accent : Colors.white38, size: 16),
              const SizedBox(width: 8),
              Text(label,
                  style: TextStyle(
                      color: isSelected ? accent : Colors.white38,
                      fontFamily: 'ShareTechMono',
                      fontSize: 13,
                      fontWeight: isSelected
                          ? FontWeight.bold
                          : FontWeight.normal)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNumbersField(Color accent, Color card) {
    return Container(
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: accent.withOpacity(0.2)),
      ),
      child: TextField(
        controller: _numbersCtrl,
        enabled: !_isBlasting,
        maxLines: 6,
        keyboardType: TextInputType.multiline,
        style: const TextStyle(
            color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 13),
        decoration: InputDecoration(
          hintText:
              '6281234567890\n6289876543210\n6285555555555',
          hintStyle: TextStyle(color: Colors.white24, fontSize: 12),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.all(14),
          suffixIcon: Padding(
            padding: const EdgeInsets.only(bottom: 80, right: 8),
            child: IconButton(
              icon: Icon(Icons.paste_outlined, color: accent.withOpacity(0.6), size: 18),
              tooltip: 'Paste',
              onPressed: () async {
                final data = await Clipboard.getData('text/plain');
                if (data?.text != null) {
                  _numbersCtrl.text = data!.text!;
                }
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMessageField(Color accent, Color card) {
    return Container(
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: accent.withOpacity(0.2)),
      ),
      child: TextField(
        controller: _messageCtrl,
        enabled: !_isBlasting,
        maxLines: 4,
        style: const TextStyle(
            color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 13),
        decoration: InputDecoration(
          hintText: 'Tulis pesan di sini...',
          hintStyle: TextStyle(color: Colors.white24, fontSize: 12),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.all(14),
        ),
      ),
    );
  }

  Widget _buildDelayField(Color accent, Color card) {
    return Container(
      width: 120,
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: accent.withOpacity(0.2)),
      ),
      child: TextField(
        controller: _delayCtrl,
        enabled: !_isBlasting,
        keyboardType: TextInputType.number,
        textAlign: TextAlign.center,
        style: TextStyle(
            color: accent,
            fontFamily: 'Orbitron',
            fontSize: 18,
            fontWeight: FontWeight.bold),
        decoration: InputDecoration(
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        ),
      ),
    );
  }

  Widget _buildActionButtons(Color accent) {
    if (!_isBlasting) {
      return CyanGlowButton(
        label: 'MULAI BLAST',
        icon: Icons.send_rounded,
        glowColor: accent,
        onPressed: _startBlast,
      );
    }

    return Row(
      children: [
        Expanded(
          child: ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: _isPaused
                  ? const Color(0xFF00E676)
                  : const Color(0xFFFFB300),
              foregroundColor: Colors.black,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
            ),
            icon: Icon(_isPaused ? Icons.play_arrow : Icons.pause, size: 18),
            label: Text(_isPaused ? 'LANJUT' : 'JEDA',
                style: const TextStyle(
                    fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
            onPressed: _pauseResume,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFFF5252),
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
            ),
            icon: const Icon(Icons.stop_rounded, size: 18),
            label: const Text('STOP',
                style: TextStyle(
                    fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
            onPressed: _stopBlast,
          ),
        ),
      ],
    );
  }

  Widget _buildLogView(Color accent, Color card) {
    return Container(
      height: 200,
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: accent.withOpacity(0.15)),
      ),
      child: ListView.builder(
        controller: _scrollCtrl,
        padding: const EdgeInsets.all(10),
        itemCount: _logs.length,
        itemBuilder: (_, i) {
          final log = _logs[i];
          Color logColor = Colors.white54;
          if (log.contains('✅')) logColor = const Color(0xFF00E676);
          if (log.contains('❌') || log.contains('⏱')) {
            logColor = const Color(0xFFFF5252);
          }
          if (log.contains('🚀') || log.contains('🏁')) logColor = accent;
          if (log.contains('⏸') || log.contains('▶️') ||
              log.contains('🛑')) {
            logColor = const Color(0xFFFFB300);
          }
          return Text(
            log,
            style: TextStyle(
                color: logColor,
                fontFamily: 'ShareTechMono',
                fontSize: 11),
          );
        },
      ),
    );
  }
}
