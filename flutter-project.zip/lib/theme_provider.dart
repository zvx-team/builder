import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ─────────────────────────────────────────────────────────────
//  AppTheme  –  Definisi warna tema
// ─────────────────────────────────────────────────────────────

class AppTheme {
  final String id;
  final String name;
  final Color accent;
  final Color bg;
  final Color card;
  final IconData icon;

  const AppTheme({
    required this.id,
    required this.name,
    required this.accent,
    required this.bg,
    required this.card,
    required this.icon,
  });
}

// ─────────────────────────────────────────────────────────────
//  Daftar tema tersedia
// ─────────────────────────────────────────────────────────────

const List<AppTheme> kAppThemes = [
  AppTheme(
    id: 'gray',
    name: 'GHOST',
    accent: Color(0xFFD6D6D6),
    bg: Color(0xFF0A0A0A),
    card: Color(0xFF141414),
    icon: Icons.blur_on,
  ),
  AppTheme(
    id: 'red',
    name: 'BLOOD',
    accent: Color(0xFFFF3B3B),
    bg: Color(0xFF0D0000),
    card: Color(0xFF1A0000),
    icon: Icons.whatshot,
  ),
  AppTheme(
    id: 'cyan',
    name: 'CYBER',
    accent: Color(0xFF00C6FF),
    bg: Color(0xFF020D15),
    card: Color(0xFF071828),
    icon: Icons.developer_board,
  ),
  AppTheme(
    id: 'green',
    name: 'MATRIX',
    accent: Color(0xFF00FF88),
    bg: Color(0xFF020D05),
    card: Color(0xFF071510),
    icon: Icons.terminal,
  ),
  AppTheme(
    id: 'purple',
    name: 'PHANTOM',
    accent: Color(0xFFBB86FC),
    bg: Color(0xFF080510),
    card: Color(0xFF130D20),
    icon: Icons.auto_awesome,
  ),
  AppTheme(
    id: 'orange',
    name: 'INFERNO',
    accent: Color(0xFFFF8C00),
    bg: Color(0xFF0D0700),
    card: Color(0xFF1A0F00),
    icon: Icons.local_fire_department,
  ),
  AppTheme(
    id: 'pink',
    name: 'VENOM',
    accent: Color(0xFFFF4DDA),
    bg: Color(0xFF0D0009),
    card: Color(0xFF1A0015),
    icon: Icons.spa,
  ),
  AppTheme(
    id: 'gold',
    name: 'ELITE',
    accent: Color(0xFFFFD700),
    bg: Color(0xFF0D0B00),
    card: Color(0xFF1A1500),
    icon: Icons.workspace_premium,
  ),
];

// ─────────────────────────────────────────────────────────────
//  ThemeProvider  –  ChangeNotifier
// ─────────────────────────────────────────────────────────────

class ThemeProvider extends ChangeNotifier {
  static const String _key = 'app_theme_id';

  AppTheme _current = kAppThemes[0]; // default: GHOST

  AppTheme get current => _current;
  Color get accent => _current.accent;
  Color get bg => _current.bg;
  Color get card => _current.card;

  ThemeProvider() {
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final savedId = prefs.getString(_key) ?? 'gray';
    final found = kAppThemes.firstWhere(
      (t) => t.id == savedId,
      orElse: () => kAppThemes[0],
    );
    _current = found;
    notifyListeners();
  }

  Future<void> setTheme(AppTheme theme) async {
    _current = theme;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, theme.id);
  }

  ThemeData toMaterialTheme() {
    final accent = _current.accent;
    const _br = BorderRadius.all(Radius.circular(12));

    return ThemeData(
      brightness: Brightness.dark,
      fontFamily: 'ShareTechMono',
      scaffoldBackgroundColor: _current.bg,
      colorScheme: ColorScheme.dark().copyWith(
        primary: accent,
        secondary: accent.withOpacity(0.6),
        surface: _current.card,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: _current.bg,
        elevation: 0,
        centerTitle: true,
      ),
      // ── Global ElevatedButton: Brutalist Rounded ──
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ButtonStyle(
          backgroundColor: WidgetStateProperty.resolveWith((states) {
            if (states.contains(WidgetState.disabled)) return Colors.black;
            return Colors.black;
          }),
          foregroundColor: WidgetStateProperty.resolveWith((states) {
            if (states.contains(WidgetState.disabled)) return accent.withOpacity(0.3);
            return accent;
          }),
          overlayColor: WidgetStateProperty.all(accent.withOpacity(0.12)),
          side: WidgetStateProperty.resolveWith((states) {
            if (states.contains(WidgetState.disabled)) {
              return BorderSide(color: accent.withOpacity(0.3), width: 2.5);
            }
            return BorderSide(color: accent, width: 2.5);
          }),
          elevation: WidgetStateProperty.all(0),
          shadowColor: WidgetStateProperty.all(Colors.transparent),
          shape: WidgetStateProperty.all(RoundedRectangleBorder(borderRadius: _br)),
          textStyle: WidgetStateProperty.all(const TextStyle(
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.w700,
            fontSize: 13,
            letterSpacing: 2,
          )),
          padding: WidgetStateProperty.all(
            const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          ),
        ),
      ),
      // ── Global OutlinedButton: Brutalist Rounded ──
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: ButtonStyle(
          backgroundColor: WidgetStateProperty.all(Colors.transparent),
          foregroundColor: WidgetStateProperty.resolveWith((states) {
            if (states.contains(WidgetState.disabled)) return accent.withOpacity(0.3);
            return accent;
          }),
          overlayColor: WidgetStateProperty.all(accent.withOpacity(0.10)),
          side: WidgetStateProperty.resolveWith((states) {
            if (states.contains(WidgetState.disabled)) {
              return BorderSide(color: accent.withOpacity(0.3), width: 2.5);
            }
            return BorderSide(color: accent, width: 2.5);
          }),
          shape: WidgetStateProperty.all(RoundedRectangleBorder(borderRadius: _br)),
          textStyle: WidgetStateProperty.all(const TextStyle(
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.w700,
            fontSize: 13,
            letterSpacing: 2,
          )),
          padding: WidgetStateProperty.all(
            const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          ),
        ),
      ),
      // ── Global TextButton ──
      textButtonTheme: TextButtonThemeData(
        style: ButtonStyle(
          foregroundColor: WidgetStateProperty.resolveWith((states) {
            if (states.contains(WidgetState.disabled)) return accent.withOpacity(0.3);
            return accent;
          }),
          overlayColor: WidgetStateProperty.all(accent.withOpacity(0.08)),
          textStyle: WidgetStateProperty.all(const TextStyle(
            fontFamily: 'ShareTechMono',
            fontSize: 12,
            letterSpacing: 1.5,
          )),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
//  InheritedTheme  –  Akses tema dari mana saja
// ─────────────────────────────────────────────────────────────

class AppThemeScope extends InheritedNotifier<ThemeProvider> {
  const AppThemeScope({
    super.key,
    required ThemeProvider provider,
    required super.child,
  }) : super(notifier: provider);

  static ThemeProvider of(BuildContext context) {
    final scope =
        context.dependOnInheritedWidgetOfExactType<AppThemeScope>();
    assert(scope != null, 'AppThemeScope not found in widget tree');
    return scope!.notifier!;
  }
}

// ─────────────────────────────────────────────────────────────
//  ThemePickerSheet  –  Bottom sheet pemilih tema
// ─────────────────────────────────────────────────────────────

class ThemePickerSheet extends StatelessWidget {
  final ThemeProvider provider;

  const ThemePickerSheet({super.key, required this.provider});

  static Future<void> show(BuildContext context, ThemeProvider provider) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => ThemePickerSheet(provider: provider),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bg = provider.bg;
    final accent = provider.accent;
    final card = provider.card;

    return Container(
      decoration: BoxDecoration(
        color: bg,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        border: Border.all(color: accent.withOpacity(0.2)),
      ),
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 36),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Handle bar
          Container(
            width: 36,
            height: 4,
            decoration: BoxDecoration(
              color: Colors.white24,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 20),

          // Title
          Row(
            children: [
              Icon(Icons.palette, color: accent, size: 18),
              const SizedBox(width: 8),
              Text(
                'PILIH TEMA',
                style: TextStyle(
                  color: accent,
                  fontFamily: 'Orbitron',
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            'Tema aktif: ${provider.current.name}',
            style: TextStyle(
              color: accent.withOpacity(0.45),
              fontFamily: 'ShareTechMono',
              fontSize: 11,
            ),
          ),
          const SizedBox(height: 20),

          // Grid tema
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              childAspectRatio: 0.82,
            ),
            itemCount: kAppThemes.length,
            itemBuilder: (context, i) {
              final theme = kAppThemes[i];
              final isActive = provider.current.id == theme.id;
              return _ThemeCard(
                theme: theme,
                isActive: isActive,
                onTap: () async {
                  await provider.setTheme(theme);
                  if (context.mounted) Navigator.pop(context);
                },
              );
            },
          ),
        ],
      ),
    );
  }
}

class _ThemeCard extends StatelessWidget {
  final AppTheme theme;
  final bool isActive;
  final VoidCallback onTap;

  const _ThemeCard({
    required this.theme,
    required this.isActive,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        decoration: BoxDecoration(
          color: theme.bg,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isActive ? theme.accent : theme.accent.withOpacity(0.2),
            width: isActive ? 2 : 1,
          ),
          boxShadow: isActive
              ? [
                  BoxShadow(
                    color: theme.accent.withOpacity(0.35),
                    blurRadius: 14,
                    spreadRadius: 1,
                  )
                ]
              : null,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Color circle
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: theme.accent.withOpacity(0.15),
                shape: BoxShape.circle,
                border: Border.all(color: theme.accent.withOpacity(0.6)),
              ),
              child: Icon(theme.icon, color: theme.accent, size: 15),
            ),
            const SizedBox(height: 6),
            Text(
              theme.name,
              style: TextStyle(
                color: isActive ? theme.accent : Colors.white54,
                fontFamily: 'Orbitron',
                fontSize: 8,
                fontWeight:
                    isActive ? FontWeight.bold : FontWeight.normal,
                letterSpacing: 1,
              ),
              textAlign: TextAlign.center,
            ),
            if (isActive) ...[
              const SizedBox(height: 2),
              Icon(Icons.check_circle, color: theme.accent, size: 10),
            ],
          ],
        ),
      ),
    );
  }
}
