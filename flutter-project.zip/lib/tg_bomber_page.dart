// tg_bomber_page.dart
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'theme_provider.dart';

// ─────────────────────────────────────────────────────────────
//  Telegram Bomber Page
//  Kirim pesan massal ke user/grup Telegram via Bot API
// ─────────────────────────────────────────────────────────────
class TgBomberPage extends StatefulWidget {
  const TgBomberPage({super.key});

  @override
  State<TgBomberPage> createState() => _TgBomberPageState();
}

class _TgBomberPageState extends State<TgBomberPage>
    with TickerProviderStateMixin {
  // Controllers
  final _botTokenCtrl = TextEditingController();
  final _chatIdCtrl = TextEditingController();
  final _messageCtrl = TextEditingController();
  final _qtyCtrl = TextEditingController(text: '50');
  final _delayCtrl = TextEditingController(text: '1');
  final _scrollCtrl = ScrollController();

  // State
  bool _isRunning = false;
  bool _stopFlag = false;
  bool _isPaused = false;
  int _successCount = 0;
  int _failCount = 0;
  int _currentIndex = 0;
  int _totalQty = 0;
  List<String> _logs = [];
  String _botName = '';
  bool _isVerifyingToken = false;

  // Animations
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _botTokenCtrl.dispose();
    _chatIdCtrl.dispose();
    _messageCtrl.dispose();
    _qtyCtrl.dispose();
    _delayCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  // ── Verify bot token ──────────────────────────────────────────
  Future<void> _verifyToken() async {
    final token = _botTokenCtrl.text.trim();
    if (token.isEmpty) {
      _snack('❌ Masukkan Bot Token dulu');
      return;
    }
    setState(() {
      _isVerifyingToken = true;
      _botName = '';
    });
    try {
      final res = await http.get(
        Uri.parse('https://api.telegram.org/bot$token/getMe'),
      ).timeout(const Duration(seconds: 8));
      final data = jsonDecode(res.body);
      if (data['ok'] == true) {
        setState(() {
          _botName = '@${data['result']['username']} (${data['result']['first_name']})';
        });
        _snack('✅ Bot valid: $_botName');
      } else {
        _snack('❌ Token tidak valid: ${data['description']}');
      }
    } on TimeoutException {
      _snack('⏱ Timeout — cek koneksi');
    } catch (e) {
      _snack('❌ Error: $e');
    } finally {
      setState(() => _isVerifyingToken = false);
    }
  }

  // ── Start bombing ─────────────────────────────────────────────
  Future<void> _startBombing() async {
    final token = _botTokenCtrl.text.trim();
    final chatId = _chatIdCtrl.text.trim();
    final message = _messageCtrl.text.trim();
    final qty = int.tryParse(_qtyCtrl.text.trim()) ?? 50;
    final delaySec = int.tryParse(_delayCtrl.text.trim()) ?? 1;

    if (token.isEmpty) { _snack('❌ Masukkan Bot Token'); return; }
    if (chatId.isEmpty) { _snack('❌ Masukkan Chat ID / Username target'); return; }
    if (message.isEmpty) { _snack('❌ Pesan tidak boleh kosong'); return; }
    if (qty < 1 || qty > 1000) { _snack('❌ Qty harus antara 1–1000'); return; }

    setState(() {
      _isRunning = true;
      _stopFlag = false;
      _isPaused = false;
      _successCount = 0;
      _failCount = 0;
      _currentIndex = 0;
      _totalQty = qty;
      _logs = [];
    });

    _addLog('🚀 Bombing dimulai → $chatId | $qty pesan | delay ${delaySec}s');

    final url = Uri.parse('https://api.telegram.org/bot$token/sendMessage');

    for (int i = 0; i < qty; i++) {
      if (_stopFlag) {
        _addLog('🛑 Dihentikan oleh user');
        break;
      }

      while (_isPaused && !_stopFlag) {
        await Future.delayed(const Duration(milliseconds: 400));
      }
      if (_stopFlag) break;

      setState(() => _currentIndex = i + 1);

      try {
        final res = await http.post(
          url,
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'chat_id': chatId,
            'text': message,
            'parse_mode': 'HTML',
          }),
        ).timeout(const Duration(seconds: 10));

        final data = jsonDecode(res.body);
        if (data['ok'] == true) {
          setState(() => _successCount++);
          _addLog('✅ #${i + 1} — Terkirim (msg_id: ${data['result']['message_id']})');
        } else {
          setState(() => _failCount++);
          _addLog('❌ #${i + 1} — ${data['description']}');
          // Jika bot di-block atau kicked, stop otomatis
          if ((data['description'] as String?)?.contains('blocked') == true ||
              (data['description'] as String?)?.contains('kicked') == true) {
            _addLog('⛔ Bot diblock/kicked — auto stop');
            break;
          }
        }
      } on TimeoutException {
        setState(() => _failCount++);
        _addLog('⏱ #${i + 1} — Timeout');
      } catch (e) {
        setState(() => _failCount++);
        _addLog('❌ #${i + 1} — ${e.toString().split(':').first}');
      }

      if (i < qty - 1 && !_stopFlag) {
        await Future.delayed(Duration(seconds: delaySec));
      }
    }

    if (mounted) {
      setState(() {
        _isRunning = false;
        _isPaused = false;
      });
      _addLog('🏁 Selesai — ✅ $_successCount berhasil | ❌ $_failCount gagal');
    }
  }

  void _addLog(String msg) {
    setState(() => _logs.add('[${_ts()}] $msg'));
    Future.delayed(const Duration(milliseconds: 80), () {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  String _ts() {
    final n = DateTime.now();
    return '${n.hour.toString().padLeft(2, '0')}:${n.minute.toString().padLeft(2, '0')}:${n.second.toString().padLeft(2, '0')}';
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: 'ShareTechMono')),
      backgroundColor: Colors.black87,
      behavior: SnackBarBehavior.floating,
    ));
  }

  @override
  Widget build(BuildContext context) {
    final theme = AppThemeScope.of(context);
    final accent = theme.accent;
    final bg = theme.bg;
    final card = theme.card;

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: accent, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            Icon(Icons.telegram, color: accent, size: 20),
            const SizedBox(width: 8),
            Text('TG BOMBER',
                style: TextStyle(
                    color: accent,
                    fontFamily: 'Orbitron',
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2)),
          ],
        ),
        actions: [
          if (_isRunning)
            Padding(
              padding: const EdgeInsets.only(right: 14),
              child: AnimatedBuilder(
                animation: _pulseAnim,
                builder: (_, __) => Opacity(
                  opacity: _pulseAnim.value,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: accent.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: accent.withOpacity(0.4)),
                    ),
                    child: Text('$_currentIndex/$_totalQty',
                        style: TextStyle(
                            color: accent,
                            fontFamily: 'ShareTechMono',
                            fontSize: 12)),
                  ),
                ),
              ),
            ),
        ],
      ),
      body: Column(
        children: [
          if (_isRunning || _totalQty > 0)
            LinearProgressIndicator(
              value: _totalQty == 0 ? 0 : _currentIndex / _totalQty,
              backgroundColor: Colors.white10,
              valueColor: AlwaysStoppedAnimation(accent),
              minHeight: 3,
            ),

          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Stats
                  if (_totalQty > 0) ...[
                    Row(children: [
                      _stat('TOTAL', '$_totalQty', Colors.white54, card),
                      const SizedBox(width: 8),
                      _stat('✅', '$_successCount', const Color(0xFF00E676), card),
                      const SizedBox(width: 8),
                      _stat('❌', '$_failCount', const Color(0xFFFF5252), card),
                    ]),
                    const SizedBox(height: 14),
                  ],

                  // Info box
                  Container(
                    padding: const EdgeInsets.all(12),
                    margin: const EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(
                      color: const Color(0x140088CC),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: const Color(0x400088CC)),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.info_outline, color: Color(0xFF0088CC), size: 16),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Butuh Bot Token dari @BotFather. Target bisa username (@target) atau Chat ID angka.',
                            style: TextStyle(
                                color: const Color(0xCC0088CC),
                                fontSize: 11,
                                fontFamily: 'ShareTechMono'),
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Bot token
                  _label('BOT TOKEN', accent),
                  const SizedBox(height: 8),
                  _buildTokenField(accent, card),
                  if (_botName.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Icon(Icons.check_circle, color: const Color(0xFF00E676), size: 14),
                        const SizedBox(width: 6),
                        Text(_botName,
                            style: const TextStyle(
                                color: Color(0xFF00E676),
                                fontSize: 12,
                                fontFamily: 'ShareTechMono')),
                      ],
                    ),
                  ],
                  const SizedBox(height: 16),

                  // Target
                  _label('TARGET (Username / Chat ID)', accent),
                  const SizedBox(height: 8),
                  _buildInput(
                    ctrl: _chatIdCtrl,
                    hint: '@username atau -1001234567890',
                    icon: Icons.person_outline,
                    accent: accent,
                    card: card,
                  ),
                  const SizedBox(height: 16),

                  // Message
                  _label('PESAN', accent),
                  const SizedBox(height: 8),
                  Container(
                    decoration: BoxDecoration(
                      color: card,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: accent.withOpacity(0.2)),
                    ),
                    child: TextField(
                      controller: _messageCtrl,
                      enabled: !_isRunning,
                      maxLines: 4,
                      style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 13),
                      decoration: InputDecoration(
                        hintText: 'Tulis pesan di sini...\nSupport HTML: <b>bold</b>, <i>italic</i>',
                        hintStyle: TextStyle(color: Colors.white24, fontSize: 11),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.all(14),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Qty & Delay
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _label('JUMLAH PESAN', accent),
                            const SizedBox(height: 8),
                            _buildSmallInput(_qtyCtrl, 'Max 1000', accent, card),
                          ],
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _label('DELAY (DETIK)', accent),
                            const SizedBox(height: 8),
                            _buildSmallInput(_delayCtrl, 'Min 0', accent, card),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),

                  // Action buttons
                  _buildActionButtons(accent),
                  const SizedBox(height: 20),

                  // Log
                  if (_logs.isNotEmpty) ...[
                    _label('LOG', accent),
                    const SizedBox(height: 8),
                    _buildLog(accent),
                    const SizedBox(height: 20),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Sub widgets ───────────────────────────────────────────────

  Widget _label(String text, Color accent) => Row(children: [
        Container(width: 3, height: 13, color: accent),
        const SizedBox(width: 8),
        Text(text,
            style: TextStyle(
                color: accent,
                fontSize: 10,
                fontFamily: 'Orbitron',
                letterSpacing: 1.5,
                fontWeight: FontWeight.bold)),
      ]);

  Widget _stat(String label, String val, Color color, Color card) => Expanded(
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
              color: card,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: color.withOpacity(0.3))),
          child: Column(children: [
            Text(label,
                style: const TextStyle(color: Colors.white38, fontSize: 10, fontFamily: 'ShareTechMono')),
            const SizedBox(height: 4),
            Text(val,
                style: TextStyle(
                    color: color, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
          ]),
        ),
      );

  Widget _buildTokenField(Color accent, Color card) {
    return Container(
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: accent.withOpacity(0.25)),
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _botTokenCtrl,
              enabled: !_isRunning,
              obscureText: true,
              style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 13),
              decoration: InputDecoration(
                hintText: '123456789:AABBcc...',
                hintStyle: TextStyle(color: Colors.white24, fontSize: 12),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                prefixIcon: Icon(Icons.vpn_key_outlined, color: accent.withOpacity(0.5), size: 18),
              ),
            ),
          ),
          Container(
            margin: const EdgeInsets.only(right: 6),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: accent.withOpacity(0.15),
                foregroundColor: accent,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                elevation: 0,
              ),
              onPressed: _isRunning || _isVerifyingToken ? null : _verifyToken,
              child: _isVerifyingToken
                  ? SizedBox(
                      width: 14,
                      height: 14,
                      child: CircularProgressIndicator(strokeWidth: 2, color: accent))
                  : Text('CEK', style: TextStyle(fontFamily: 'Orbitron', fontSize: 11, color: accent)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInput({
    required TextEditingController ctrl,
    required String hint,
    required IconData icon,
    required Color accent,
    required Color card,
  }) =>
      Container(
        decoration: BoxDecoration(
          color: card,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: accent.withOpacity(0.2)),
        ),
        child: TextField(
          controller: ctrl,
          enabled: !_isRunning,
          style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 13),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: TextStyle(color: Colors.white24, fontSize: 12),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
            prefixIcon: Icon(icon, color: accent.withOpacity(0.5), size: 18),
            suffixIcon: IconButton(
              icon: Icon(Icons.paste_outlined, color: accent.withOpacity(0.4), size: 16),
              onPressed: () async {
                final d = await Clipboard.getData('text/plain');
                if (d?.text != null) ctrl.text = d!.text!;
              },
            ),
          ),
        ),
      );

  Widget _buildSmallInput(TextEditingController ctrl, String hint, Color accent, Color card) =>
      Container(
        decoration: BoxDecoration(
          color: card,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: accent.withOpacity(0.2)),
        ),
        child: TextField(
          controller: ctrl,
          enabled: !_isRunning,
          keyboardType: TextInputType.number,
          textAlign: TextAlign.center,
          style: TextStyle(
              color: accent, fontFamily: 'Orbitron', fontSize: 18, fontWeight: FontWeight.bold),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: TextStyle(color: Colors.white24, fontSize: 12),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          ),
        ),
      );

  Widget _buildActionButtons(Color accent) {
    if (!_isRunning) {
      return SizedBox(
        width: double.infinity,
        child: ElevatedButton.icon(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF0088CC),
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 14),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            elevation: 6,
            shadowColor: const Color(0x800088CC),
          ),
          icon: const Icon(Icons.send_rounded, size: 18),
          label: const Text('MULAI BOMBING',
              style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, letterSpacing: 1.5)),
          onPressed: _startBombing,
        ),
      );
    }

    return Row(
      children: [
        Expanded(
          child: ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: _isPaused ? const Color(0xFF00E676) : const Color(0xFFFFB300),
              foregroundColor: Colors.black,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            icon: Icon(_isPaused ? Icons.play_arrow : Icons.pause, size: 18),
            label: Text(_isPaused ? 'LANJUT' : 'JEDA',
                style: const TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
            onPressed: () => setState(() => _isPaused = !_isPaused),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFFF5252),
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            icon: const Icon(Icons.stop_rounded, size: 18),
            label: const Text('STOP',
                style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
            onPressed: () => setState(() => _stopFlag = true),
          ),
        ),
      ],
    );
  }

  Widget _buildLog(Color accent) => Container(
        height: 200,
        decoration: BoxDecoration(
          color: Colors.black,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: accent.withOpacity(0.15)),
        ),
        child: ListView.builder(
          controller: _scrollCtrl,
          padding: const EdgeInsets.all(10),
          itemCount: _logs.length,
          itemBuilder: (_, i) {
            final log = _logs[i];
            Color c = Colors.white54;
            if (log.contains('✅')) c = const Color(0xFF00E676);
            if (log.contains('❌') || log.contains('⏱') || log.contains('⛔')) {
              c = const Color(0xFFFF5252);
            }
            if (log.contains('🚀') || log.contains('🏁')) c = accent;
            if (log.contains('🛑') || log.contains('⏸') || log.contains('▶️')) {
              c = const Color(0xFFFFB300);
            }
            return Text(log,
                style: TextStyle(color: c, fontFamily: 'ShareTechMono', fontSize: 11));
          },
        ),
      );
}
