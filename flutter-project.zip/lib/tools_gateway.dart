import 'package:flutter/material.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'public_chat.dart';
import 'spam_ngl.dart';

class ToolsPage extends StatelessWidget {
  final String sessionKey;
  final String username;
  final String userRole; // Field ini digunakan di class ini
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.userRole,
    required this.listDoos,
  });

  final Color bgDark = const Color(0xFF050A10);
  final Color surfaceDark = const Color(0xFF0F172A);
  final Color cardDark = const Color(0xFF1E293B);
  final Color accentSky = const Color(0xFF38BDF8);
  final Color textGrey = const Color(0xFF94A3B8);
  final Color borderDark = const Color(0xFF334155);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: SafeArea(
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: surfaceDark,
                border: Border(bottom: BorderSide(color: borderDark)),
              ),
              child: const Column(
                children: [
                  Icon(Icons.hub_outlined, color: Color(0xFF38BDF8), size: 28),
                  SizedBox(height: 12),
                  Text("NETWORK TOOLS", 
                    style: TextStyle(fontFamily: 'Orbitron', fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white)),
                ],
              ),
            ),
            
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  // Meneruskan parameter yang dibutuhkan oleh masing-masing halaman
                  _buildToolCard(context, "Spam NGL", "Send anonymous messages", Icons.email_outlined, false, const NglPage()),
                  
                  // PublicChatPage membutuhkan sessionKey, username, dan role
                  _buildToolCard(context, "Public Chat", "Join global discussions", Icons.chat_bubble_outline, false, 
                    PublicChatPage(sessionKey: sessionKey, username: username, role: userRole)),
                  
                  _buildToolCard(context, "WiFi Killer (Internal)", "Disable WiFi networks locally", Icons.wifi_off, false, const WifiInternalPage()),
                  _buildToolCard(context, "WiFi Killer (External)", "Advanced WiFi attack tools", Icons.satellite_alt, true, const WifiKillerPage()),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildToolCard(BuildContext context, String title, String subtitle, IconData icon, bool isVip, Widget destinationPage) {
    if (isVip && userRole == "guest") return const SizedBox.shrink();

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: cardDark,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderDark),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => destinationPage),
            );
          },
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Icon(icon, color: accentSky, size: 24),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
                      Text(subtitle, style: TextStyle(color: textGrey, fontSize: 12)),
                    ],
                  ),
                ),
                Icon(Icons.arrow_forward_ios, color: accentSky, size: 14),
              ],
            ),
          ),
        ),
      ),
    );
  }
}