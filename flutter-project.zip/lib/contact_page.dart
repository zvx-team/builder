import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

class ContactPage extends StatelessWidget {
  const ContactPage({super.key});

  // --- TEMA WARNA HITAM + ABU-ABU (Konsisten dengan halaman lain) ---
  static const Color bgBlack = Colors.black;
  static const Color greyDark = Color(0xFF1E1E1E);  // grey[800] setara
  static const Color greyLight = Color(0xFF3A3A3A); // grey[500]
  static const Color redDark = Color(0xFF8B0000);   // tidak dipakai di halaman ini

  // Glassmorphism dengan opacity dari putih (tetap)
  static const Color cardGlass = Color.fromARGB(13, 255, 255, 255);
  static const Color borderGlass = Color.fromARGB(26, 255, 255, 255);

  Future<void> _launchUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: greyLight),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          "Customer Service",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              bgBlack,
              greyDark.withOpacity(0.2),
              bgBlack,
            ],
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Header Icon (lingkaran abu-abu)
                Container(
                  padding: EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: greyDark.withOpacity(0.2),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: greyLight.withOpacity(0.3),
                        blurRadius: 20,
                      ),
                    ],
                  ),
                  child: Icon(
                    Icons.support_agent_rounded,
                    size: 60,
                    color: greyLight,
                  ),
                ),
                SizedBox(height: 24),
                Text(
                  "Need Help?",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  "Contact us through our social media platforms below.",
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white60, fontSize: 14),
                ),
                SizedBox(height: 40),

                // Daftar tombol kontak (ikon abu-abu terang, latar gelap)
                Column(
                  children: [
                    _buildContactButton(
                      label: "Telegram Owner",
                      icon: FontAwesomeIcons.telegram,
                      color: greyLight,
                      url: "https://t.me/RixzzNotDev",
                    ),
                    SizedBox(height: 16),
                    _buildContactButton(
                      label: "Telegram Group",
                      icon: FontAwesomeIcons.telegram,
                      color: greyLight,
                      url: "https://t.me/RoomRixzz",
                    ),
                    SizedBox(height: 16),
                    _buildContactButton(
                      label: "Telegram Channel",
                      icon: FontAwesomeIcons.telegram,
                      color: greyLight,
                      url: "https://t.me/AboutRixzz",
                    ),
                    SizedBox(height: 16),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildContactButton({
    required String label,
    required IconData icon,
    required Color color,
    required String url,
  }) {
    return InkWell(
      onTap: () => _launchUrl(url),
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(vertical: 18, horizontal: 20),
        decoration: BoxDecoration(
          color: cardGlass,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: borderGlass),
          boxShadow: [
            BoxShadow(
              color: greyDark.withOpacity(0.2),
              blurRadius: 10,
              offset: Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.2),
                    shape: BoxShape.circle,
                  ),
                  child: FaIcon(icon, color: color, size: 24),
                ),
                SizedBox(width: 20),
                Text(
                  label,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            Icon(Icons.arrow_forward_ios, color: Colors.white54, size: 16),
          ],
        ),
      ),
    );
  }
}