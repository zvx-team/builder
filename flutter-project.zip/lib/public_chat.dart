import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// Model pesan untuk data yang rapi
class ChatMessage {
  final String username;
  final String message;
  final String formattedTime;

  ChatMessage({required this.username, required this.message, required this.formattedTime});

  factory ChatMessage.fromJson(Map<String, dynamic> json) {
    return ChatMessage(
      username: json['username'] ?? 'Unknown',
      message: json['message'] ?? '',
      formattedTime: json['formattedTime'] ?? '',
    );
  }
}

class PublicChatPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const PublicChatPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<PublicChatPage> createState() => _PublicChatPageState();
}

class _PublicChatPageState extends State<PublicChatPage> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  List<ChatMessage> _messages = [];
  int _onlineCount = 0;
  final String _baseUrl = "http://arkzzxrizz.private.omdhancivok.my.id:2152";

  @override
  void initState() {
    super.initState();
    _refreshData();
    Timer.periodic(const Duration(seconds: 5), (_) => _fetchMessages());
    Timer.periodic(const Duration(seconds: 15), (_) => _fetchOnlineUsers());
  }

  void _refreshData() {
    _fetchMessages();
    _fetchOnlineUsers();
  }

  Future<void> _fetchMessages() async {
    try {
      final response = await http.get(Uri.parse("$_baseUrl/getPublicChat?key=${widget.sessionKey}"));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['valid'] == true) {
          final List<dynamic> msgList = data['messages'];
          setState(() {
            _messages = msgList.map((e) => ChatMessage.fromJson(e)).toList();
          });
        }
      }
    } catch (e) {
      debugPrint("Gagal memuat pesan: $e");
    }
  }

  Future<void> _fetchOnlineUsers() async {
    try {
      final response = await http.get(Uri.parse("$_baseUrl/getOnlineUsers?key=${widget.sessionKey}"));
      if (response.statusCode == 200) {
        setState(() => _onlineCount = json.decode(response.body)['count'] ?? 0);
      }
    } catch (e) {}
  }

  Future<void> _sendMessage() async {
    if (_messageController.text.trim().isEmpty) return;
    String text = _messageController.text;
    _messageController.clear();
    
    try {
      await http.post(
        Uri.parse("$_baseUrl/sendPublicChat"),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({'key': widget.sessionKey, 'message': text}),
      );
      _fetchMessages();
    } catch (e) {
      debugPrint("Gagal kirim: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF05050a),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
          decoration: BoxDecoration(
            color: Colors.transparent,
            borderRadius: BorderRadius.circular(25),
            border: Border.all(color: Colors.cyan.withOpacity(0.6)),
            boxShadow: [BoxShadow(color: Colors.cyan.withOpacity(0.15), blurRadius: 15)],
          ),
          child: const Text("PUBLIK CHAT", style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.cyan, letterSpacing: 1.5)),
        ),
        actions: [
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(color: Colors.green.withOpacity(0.05), border: Border.all(color: Colors.green.withOpacity(0.3)), borderRadius: BorderRadius.circular(20)),
            child: Row(children: [const Icon(Icons.circle, size: 8, color: Colors.green), const SizedBox(width: 6), Text("$_onlineCount ONLINE", style: const TextStyle(fontSize: 10, color: Colors.green, fontWeight: FontWeight.bold))]),
          )
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              reverse: true,
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final msg = _messages.reversed.toList()[index];
                final isMe = msg.username == widget.username;
                return Align(
                  alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 15, vertical: 6),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: const Color(0xFF11152c), borderRadius: BorderRadius.circular(20)),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(msg.username, style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: isMe ? Colors.cyan : Colors.redAccent)),
                      const SizedBox(height: 4),
                      Text(msg.message, style: const TextStyle(color: Colors.white, fontSize: 14)),
                      const SizedBox(height: 4),
                      Text(msg.formattedTime, style: const TextStyle(color: Colors.white30, fontSize: 8)),
                    ]),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Row(children: [
              Expanded(
                child: TextField(
                  controller: _messageController,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    hintText: "Tulis pesan...", 
                    hintStyle: const TextStyle(color: Colors.white24),
                    filled: true, 
                    fillColor: const Color(0xFF11152c), 
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(30), borderSide: BorderSide.none),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15)
                  )
                ),
              ),
              const SizedBox(width: 12),
              Container(
                decoration: BoxDecoration(color: Colors.cyan.withOpacity(0.1), border: Border.all(color: Colors.cyan.withOpacity(0.3)), shape: BoxShape.circle),
                child: IconButton(onPressed: _sendMessage, icon: const Icon(Icons.send_rounded, color: Colors.cyan)),
              )
            ]),
          )
        ],
      ),
    );
  }
}