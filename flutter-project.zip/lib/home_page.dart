import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;
  final String sessionKey;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.listBug,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  // Logic & Features preserved from original
  String _selectedMode = "number";
  String _selectedBug = "01";
  final TextEditingController _targetController = TextEditingController();
  bool _isSending = false;

  // Design Tokens (Matching Screenshot_20260625-190000_1.png)
  final Color bgDark = const Color(0xFF02040a);
  final Color borderRed = const Color(0xFF7f1d1d);
  final Color accentCyan = const Color(0xFF22D3EE);
  final Color borderDark = const Color(0xFF1E293B);

  @override
  void initState() {
    super.initState();
    if (widget.listBug.isNotEmpty) {
      _selectedBug = widget.listBug[0]['bug_id'].toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            children: [
              _buildHeader(),
              const SizedBox(height: 24),
              _buildModeSelectors(),
              const SizedBox(height: 24),
              _buildTargetInput(),
              const SizedBox(height: 24),
              _buildPayloadSelector(),
              const Spacer(),
              _buildLaunchButton(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
      decoration: BoxDecoration(
        color: const Color(0xFF0a0710).withOpacity(0.9),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: borderRed.withOpacity(0.6)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFF200d14),
              borderRadius: BorderRadius.circular(50),
            ),
            child: const Icon(FontAwesomeIcons.bug, color: Colors.redAccent, size: 22),
          ),
          const SizedBox(width: 16),
          const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("WHATSAPP CRASH", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16, fontFamily: 'Orbitron', letterSpacing: 1.5)),
              Text("Advanced Payload Injection Tool", style: TextStyle(color: Colors.grey, fontSize: 10, fontFamily: 'ShareTechMono', letterSpacing: 0.5)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildModeSelectors() {
    return Row(
      children: [
        _buildModeButton("BUG NOMOR", "number", FontAwesomeIcons.mobileScreen),
        const SizedBox(width: 12),
        _buildModeButton("BUG GROUP", "group", FontAwesomeIcons.users),
      ],
    );
  }

  Widget _buildTargetInput() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(_selectedMode == "number" ? "TARGET NUMBER" : "TARGET GROUP LINK", 
             style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.8, fontFamily: 'Orbitron')),
        const SizedBox(height: 10),
        TextField(
          controller: _targetController,
          style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono'),
          decoration: InputDecoration(
            filled: true,
            fillColor: const Color(0xFF040914),
            prefixIcon: Icon(_selectedMode == "number" ? Icons.phone_android : Icons.link, color: Colors.grey),
            hintText: _selectedMode == "number" ? "e.g. +628xxxxxxxxx" : "https://chat.whatsapp.com/...",
            hintStyle: TextStyle(color: Colors.grey.withOpacity(0.4), fontSize: 13),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: borderDark)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: borderDark)),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: accentCyan)),
          ),
        ),
      ],
    );
  }

  Widget _buildPayloadSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("SELECT PAYLOAD BUG", style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.8, fontFamily: 'Orbitron')),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(color: const Color(0xFF040914), borderRadius: BorderRadius.circular(16), border: Border.all(color: borderDark)),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: _selectedBug,
              isExpanded: true,
              dropdownColor: const Color(0xFF081121),
              style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 14),
              onChanged: (val) => setState(() => _selectedBug = val!),
              items: widget.listBug.map((bug) => DropdownMenuItem(
                value: bug['bug_id'].toString(),
                child: Text(bug['bug_name'] ?? ""),
              )).toList(),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildLaunchButton() {
    return SizedBox(
      width: double.infinity,
      height: 58,
      child: ElevatedButton(
        onPressed: _isSending ? null : () => _performAttack(),
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF111827),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: borderDark)),
        ),
        child: _isSending 
          ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
          : const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(FontAwesomeIcons.rocket, size: 16),
              SizedBox(width: 12),
              Text("LAUNCH ATTACK", style: TextStyle(letterSpacing: 2, fontWeight: FontWeight.bold, fontSize: 14, fontFamily: 'Orbitron')),
            ]),
      ),
    );
  }

  Widget _buildModeButton(String label, String mode, IconData icon) {
    bool isSelected = _selectedMode == mode;
    return Expanded(
      child: InkWell(
        onTap: () => setState(() => _selectedMode = mode),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 18),
          decoration: BoxDecoration(
            color: isSelected ? const Color(0xFF06111f) : const Color(0xFF040811),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: isSelected ? accentCyan : borderDark),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 14, color: isSelected ? accentCyan : Colors.grey),
              const SizedBox(width: 8),
              Text(label, style: TextStyle(color: isSelected ? accentCyan : Colors.grey, fontSize: 11, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _performAttack() async {
    setState(() => _isSending = true);
    // Original attack logic preserved
    await Future.delayed(const Duration(seconds: 2));
    if (!mounted) return;
    setState(() => _isSending = false);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text("Attack successfully injected!"), 
      backgroundColor: Colors.green,
      behavior: SnackBarBehavior.floating,
    ));
  }
}