// ignore_for_file: use_build_context_synchronously
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'sound_manager.dart';
import 'shake_attack.dart';
// ═══════════════════════════════════════════════════════════════
//  AttackPage  –  Basic Bug dengan Sender Type (Global / Private)
// ═══════════════════════════════════════════════════════════════

class AttackPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const AttackPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<AttackPage> createState() => _AttackPageState();
}

class _AttackPageState extends State<AttackPage> with SingleTickerProviderStateMixin {
  static const String _baseUrl = "http://arullll.private-rexy.web.id:11235";

  // Controllers
  final _targetCtrl = TextEditingController();
  late AnimationController _glowCtrl;
  late Animation<double> _glowAnim;

  // Bug & sender
  String _selectedBugId = "";
  String _senderType = "global"; // "global" | "private"

  // Sender data
  List<String> _globalSenders = [];
  int _globalCount = 0;
  int _privateCount = 0;
  bool _loadingSenders = false;

  // Send state
  bool _isSending = false;
  int _activeStep = 0; // 0=input, 1=process, 2=complete

  // Theme — biru gelap ala Image 2
  static const Color _bg      = Color(0xFF0D1B2A);
  static const Color _card    = Color(0xFF112233);
  static const Color _border  = Color(0xFF1E3A5F);
  static const Color _accent  = Color(0xFF00C6FF); // biru cyan
  static const Color _green   = Color(0xFF00E676);
  static const Color _textDim = Color(0xFF607D8B);

  @override
  void initState() {
    super.initState();
    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);
    _glowAnim = Tween<double>(begin: 0.4, end: 1.0).animate(
      CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut),
    );

    if (widget.listBug.isNotEmpty) {
      _selectedBugId = widget.listBug[0]['bug_id'];
    }
    _fetchSenders();
  }

  @override
  void dispose() {
    _glowCtrl.dispose();
    _targetCtrl.dispose();
    super.dispose();
  }

  // ── Fetch sender aktif ────────────────────────────────────────

  Future<void> _fetchSenders() async {
    if (_loadingSenders) return;
    setState(() => _loadingSenders = true);
    try {
      final res = await http.get(Uri.parse(
          "$_baseUrl/api/whatsapp/mySender?key=${widget.sessionKey}"));
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        // API return { connections: { global: [...], private: [...] } }
        final conns = data['connections'] as Map<String, dynamic>? ?? {};
        final globalList = conns['global'] as List? ?? [];
        final privateList = conns['private'] as List? ?? [];
        setState(() {
          _globalCount = globalList.length;
          _privateCount = privateList.length;
          // Ambil nomor dari global senders (preview 3 teratas)
          _globalSenders = globalList
              .take(3)
              .map((s) => s['sessionName']?.toString() ?? s.toString())
              .toList();
        });
      }
    } catch (_) {}
    setState(() => _loadingSenders = false);
  }

  // ── Send bug ──────────────────────────────────────────────────

  String? _formatPhone(String raw) {
    final cleaned = raw.replaceAll(RegExp(r'[^\d]'), '');
    if (cleaned.startsWith('0') || cleaned.length < 8) return null;
    return cleaned;
  }

  Future<void> _sendBug() async {
    if (_isSending) return;

    final target = _formatPhone(_targetCtrl.text.trim());
    if (target == null) {
      SoundManager.playError();
      _alert("❌ Nomor Tidak Valid",
          "Gunakan format internasional (e.g. 628123...), bukan 08xxx.");
      return;
    }
    if (_selectedBugId.isEmpty) {
      SoundManager.playError();
      _alert("❌ Pilih Bug", "Pilih jenis bug terlebih dahulu.");
      return;
    }

    // Simpan target untuk Shake to Attack
    await ShakeAttackManager.saveLastTarget(target);

    SoundManager.playAttack();
    setState(() { _isSending = true; _activeStep = 1; });

    try {
      final url = "$_baseUrl/api/whatsapp/sendBug"
          "?key=\${widget.sessionKey}"
          "&target=$target"
          "&bug=$_selectedBugId"
          "&senderType=$_senderType";
      final res = await http.get(Uri.parse(url));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        SoundManager.playCooldown();
        _alert("⏳ Cooldown", "Tunggu beberapa saat sebelum mengirim lagi.");
      } else if (data["senderOn"] == false) {
        SoundManager.playError();
        _alert("⚠️ Sender Kosong", "Tidak ada sender aktif. Hubungi seller.");
      } else if (data["valid"] == false) {
        SoundManager.playError();
        _alert("❌ Key Invalid", "Session key tidak valid. Silakan login ulang.");
      } else if (data["sended"] == false) {
        SoundManager.playError();
        _alert("⚠️ Gagal Kirim", "Gagal mengirim bug. Server mungkin maintenance.");
      } else {
        SoundManager.playSuccess();
        setState(() => _activeStep = 2);
        _showSuccessSheet(target);
      }
    } catch (_) {
      SoundManager.playError();
      _alert("❌ Error", "Terjadi kesalahan koneksi. Coba lagi.");
    } finally {
      setState(() => _isSending = false);
    }
  }

  // ── Dialogs ───────────────────────────────────────────────────

  void _alert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: _accent.withOpacity(0.3)),
        ),
        title: Text(title,
            style: const TextStyle(
                color: Colors.white, fontFamily: 'Orbitron', fontSize: 14)),
        content: Text(msg,
            style: TextStyle(
                color: Colors.white60, fontFamily: 'ShareTechMono', fontSize: 13)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK", style: TextStyle(color: _accent)),
          )
        ],
      ),
    );
  }

  void _showSuccessSheet(String target) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _SuccessSheet(
        target: target,
        accent: _accent,
        onDismiss: () {
          Navigator.pop(context);
          setState(() => _activeStep = 0);
        },
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────
  //  BUILD
  // ─────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeader(),
              const SizedBox(height: 16),
              _buildProgressBar(),
              const SizedBox(height: 16),
              _buildTargetCard(),
              const SizedBox(height: 12),
              _buildBugTypeCard(),
              const SizedBox(height: 12),
              _buildSenderTypeCard(),
              const SizedBox(height: 20),
              _buildSendButton(),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  // ── Header ────────────────────────────────────────────────────

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _border),
      ),
      child: Row(
        children: [
          // Avatar
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: _accent.withOpacity(0.1),
              shape: BoxShape.circle,
              border: Border.all(color: _accent.withOpacity(0.3)),
            ),
            child: Icon(FontAwesomeIcons.userShield, color: _accent, size: 20),
          ),
          const SizedBox(width: 12),
          // User info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.username.toUpperCase(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontFamily: 'Orbitron',
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: _getRoleColor().withOpacity(0.15),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: _getRoleColor().withOpacity(0.4)),
                  ),
                  child: Text(
                    widget.role.toUpperCase(),
                    style: TextStyle(
                      color: _getRoleColor(),
                      fontSize: 10,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
          // Exp date
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: const Color(0x0FFFFFFF),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _border),
            ),
            child: Column(
              children: [
                const Icon(FontAwesomeIcons.calendarAlt,
                    color: Colors.white54, size: 13),
                const SizedBox(height: 3),
                Text("EXP",
                    style: TextStyle(
                        color: Colors.white38,
                        fontSize: 9,
                        fontFamily: 'ShareTechMono')),
                Text(
                  widget.expiredDate,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontFamily: 'ShareTechMono',
                      fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Color _getRoleColor() {
    switch (widget.role.toLowerCase()) {
      case 'developer': case 'dev': return const Color(0xFFFF5252);
      case 'high owner': return const Color(0xFFFF6D00);
      case 'owner': return const Color(0xFFE040FB);
      case 'high admin': return const Color(0xFFFFAB40);
      case 'admin': return const Color(0xFFFFD740);
      case 'vip': return const Color(0xFF69F0AE);
      case 'reseller': case 'reseller1': return const Color(0xFF448AFF);
      default: return _accent;
    }
  }

  // ── Progress bar ──────────────────────────────────────────────

  Widget _buildProgressBar() {
    final steps = [
      {"icon": FontAwesomeIcons.keyboard, "label": "Input"},
      {"icon": FontAwesomeIcons.gears, "label": "Process"},
      {"icon": FontAwesomeIcons.circleCheck, "label": "Complete"},
    ];
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _border),
      ),
      child: Row(
        children: List.generate(steps.length * 2 - 1, (i) {
          if (i.isOdd) {
            // line
            final lineActive = _activeStep > i ~/ 2;
            return Expanded(
              child: Container(
                height: 2,
                margin: const EdgeInsets.symmetric(horizontal: 4),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: lineActive
                        ? [_accent, _accent.withOpacity(0.4)]
                        : [Colors.white12, Colors.white12],
                  ),
                  borderRadius: BorderRadius.circular(1),
                ),
              ),
            );
          }
          final idx = i ~/ 2;
          final isActive = _activeStep >= idx;
          final icon = steps[idx]["icon"] as IconData;
          final label = steps[idx]["label"] as String;
          return Expanded(
            child: Column(
              children: [
                AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    color: isActive
                        ? _accent.withOpacity(0.15)
                        : const Color(0x0AFFFFFF),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: isActive ? _accent.withOpacity(0.6) : Colors.white12,
                      width: 1.5,
                    ),
                  ),
                  child: Icon(icon,
                      color: isActive ? _accent : Colors.white24, size: 15),
                ),
                const SizedBox(height: 5),
                Text(label,
                    style: TextStyle(
                        color: isActive ? _accent : Colors.white24,
                        fontSize: 9,
                        fontFamily: 'Orbitron')),
              ],
            ),
          );
        }),
      ),
    );
  }

  // ── Target card ───────────────────────────────────────────────

  Widget _buildTargetCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _iconBox(FontAwesomeIcons.phone, _accent),
              const SizedBox(width: 10),
              const Text("Target Number",
                  style: TextStyle(
                      color: Colors.white,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.bold,
                      fontSize: 15)),
            ],
          ),
          const SizedBox(height: 14),
          TextField(
            controller: _targetCtrl,
            keyboardType: TextInputType.phone,
            style: const TextStyle(
                color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 15),
            cursorColor: _accent,
            decoration: InputDecoration(
              hintText: "Contoh: +62812xxxxxxxx",
              hintStyle: TextStyle(color: Colors.white24, fontFamily: 'ShareTechMono'),
              filled: true,
              fillColor: _bg,
              prefixIcon: Icon(FontAwesomeIcons.mobileScreen,
                  color: Colors.white30, size: 16),
              enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(color: _border),
                borderRadius: BorderRadius.circular(12),
              ),
              focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(color: _accent.withOpacity(0.6), width: 1.5),
                borderRadius: BorderRadius.circular(12),
              ),
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            ),
          ),
        ],
      ),
    );
  }

  // ── Bug type card ─────────────────────────────────────────────

  Widget _buildBugTypeCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _iconBox(FontAwesomeIcons.bug, _accent),
              const SizedBox(width: 10),
              const Text("Pilih Bug",
                  style: TextStyle(
                      color: Colors.white,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.bold,
                      fontSize: 15)),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
            decoration: BoxDecoration(
              color: _bg,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _border),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: _selectedBugId.isEmpty ? null : _selectedBugId,
                isExpanded: true,
                dropdownColor: _card,
                iconEnabledColor: Colors.white38,
                style: const TextStyle(
                    color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 14),
                hint: Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      margin: const EdgeInsets.only(right: 10),
                      decoration: BoxDecoration(
                          color: _accent, shape: BoxShape.circle),
                    ),
                    Text("Pilih bug type...",
                        style: TextStyle(
                            color: Colors.white38,
                            fontFamily: 'ShareTechMono')),
                  ],
                ),
                items: widget.listBug.map((bug) {
                  return DropdownMenuItem<String>(
                    value: bug['bug_id'],
                    child: Row(
                      children: [
                        Container(
                          width: 8,
                          height: 8,
                          margin: const EdgeInsets.only(right: 10),
                          decoration: BoxDecoration(
                              color: _accent, shape: BoxShape.circle),
                        ),
                        Expanded(
                          child: Text(
                            bug['bug_name'] ?? bug['bug_id'],
                            style: const TextStyle(
                                color: Colors.white,
                                fontFamily: 'ShareTechMono',
                                fontSize: 13),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  );
                }).toList(),
                onChanged: (v) => setState(() => _selectedBugId = v ?? ""),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Sender Type card ──────────────────────────────────────────

  Widget _buildSenderTypeCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  _iconBox(FontAwesomeIcons.layerGroup, _accent),
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text("Sender Type",
                          style: TextStyle(
                              color: Colors.white,
                              fontFamily: 'Orbitron',
                              fontWeight: FontWeight.bold,
                              fontSize: 15)),
                      Text("Pilih sumber nomor pengirim",
                          style: TextStyle(
                              color: _textDim,
                              fontFamily: 'ShareTechMono',
                              fontSize: 11)),
                    ],
                  ),
                ],
              ),
              // Refresh
              GestureDetector(
                onTap: _fetchSenders,
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _bg,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: _border),
                  ),
                  child: _loadingSenders
                      ? SizedBox(
                          width: 14,
                          height: 14,
                          child: CircularProgressIndicator(
                              color: _accent, strokeWidth: 2))
                      : Icon(Icons.refresh_rounded, color: _accent, size: 16),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Toggle Global / Private
          Row(
            children: [
              Expanded(child: _senderToggle(
                type: "global",
                icon: FontAwesomeIcons.globe,
                label: "Global",
                subtitle: "$_globalCount sender",
                color: _green,
              )),
              const SizedBox(width: 10),
              Expanded(child: _senderToggle(
                type: "private",
                icon: FontAwesomeIcons.userShield,
                label: "Private",
                subtitle: "$_privateCount sender",
                color: _accent,
              )),
            ],
          ),

          // Sender list — hanya tampil kalau global dipilih
          if (_senderType == "global") ...[
            const SizedBox(height: 14),
            AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: _bg,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _border),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(FontAwesomeIcons.listUl, color: _green, size: 13),
                      const SizedBox(width: 8),
                      Text(
                        "$_globalCount sender aktif",
                        style: TextStyle(
                            color: _green,
                            fontFamily: 'ShareTechMono',
                            fontSize: 12,
                            fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  if (_globalSenders.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    ..._globalSenders.map((num) => Padding(
                          padding: const EdgeInsets.only(bottom: 5),
                          child: Row(
                            children: [
                              Container(
                                width: 7,
                                height: 7,
                                decoration: BoxDecoration(
                                    color: _green, shape: BoxShape.circle),
                              ),
                              const SizedBox(width: 8),
                              Text(num,
                                  style: const TextStyle(
                                      color: Colors.white70,
                                      fontFamily: 'ShareTechMono',
                                      fontSize: 12)),
                            ],
                          ),
                        )),
                    if (_globalCount > 3)
                      Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child: Text(
                          "+ ${_globalCount - 3} lainnya...",
                          style: TextStyle(
                              color: _textDim,
                              fontFamily: 'ShareTechMono',
                              fontSize: 11),
                        ),
                      ),
                  ],
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _senderToggle({
    required String type,
    required IconData icon,
    required String label,
    required String subtitle,
    required Color color,
  }) {
    final isSelected = _senderType == type;
    return GestureDetector(
      onTap: () => setState(() => _senderType = type),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
        decoration: BoxDecoration(
          color: isSelected ? color.withOpacity(0.1) : _bg,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isSelected ? color.withOpacity(0.6) : _border,
            width: isSelected ? 1.5 : 1,
          ),
        ),
        child: Column(
          children: [
            Icon(icon, color: isSelected ? color : Colors.white30, size: 24),
            const SizedBox(height: 8),
            Text(label,
                style: TextStyle(
                    color: isSelected ? color : Colors.white38,
                    fontFamily: 'Orbitron',
                    fontSize: 12,
                    fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text(subtitle,
                style: TextStyle(
                    color: isSelected ? color.withOpacity(0.7) : _textDim,
                    fontFamily: 'ShareTechMono',
                    fontSize: 10)),
            if (isSelected) ...[
              const SizedBox(height: 6),
              Container(
                width: 24,
                height: 2,
                decoration: BoxDecoration(
                    color: color, borderRadius: BorderRadius.circular(1)),
              ),
            ],
          ],
        ),
      ),
    );
  }

  // ── Send Button ───────────────────────────────────────────────

  Widget _buildSendButton() {
    return SizedBox(
      width: double.infinity,
      height: 58,
      child: ElevatedButton.icon(
        onPressed: _isSending ? null : _sendBug,
        icon: _isSending
            ? SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(color: _bg, strokeWidth: 2.5))
            : const Icon(FontAwesomeIcons.paperPlane, size: 18),
        label: Text(
          _isSending ? "MENGIRIM..." : "KIRIM BUG ATTACK",
          style: const TextStyle(
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
            fontSize: 14,
            letterSpacing: 1.5,
          ),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: _accent,
          foregroundColor: Colors.white,
          disabledBackgroundColor: _accent.withOpacity(0.3),
          disabledForegroundColor: Colors.white38,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12)),
          elevation: 0,
        ),
      ),
    );
  }

  // ── Helper ────────────────────────────────────────────────────

  Widget _iconBox(IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(0.25)),
      ),
      child: Icon(icon, color: color, size: 16),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  Success Bottom Sheet
// ═══════════════════════════════════════════════════════════════

class _SuccessSheet extends StatelessWidget {
  final String target;
  final Color accent;
  final VoidCallback onDismiss;

  const _SuccessSheet({
    required this.target,
    required this.accent,
    required this.onDismiss,
  });

  @override
  Widget build(BuildContext context) {
    const bg = Color(0xFF112233);
    return Container(
      padding: const EdgeInsets.fromLTRB(24, 16, 24, 36),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        border: Border.all(color: accent.withOpacity(0.25)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 40, height: 4,
            decoration: BoxDecoration(
                color: Colors.white24,
                borderRadius: BorderRadius.circular(2)),
          ),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: accent.withOpacity(0.1),
              shape: BoxShape.circle,
              border: Border.all(color: accent.withOpacity(0.4)),
            ),
            child: Icon(FontAwesomeIcons.checkDouble, color: accent, size: 28),
          ),
          const SizedBox(height: 16),
          Text("Attack Successful!",
              style: TextStyle(
                  color: accent,
                  fontFamily: 'Orbitron',
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1)),
          const SizedBox(height: 8),
          Text("Bug berhasil dikirim ke $target",
              style: const TextStyle(
                  color: Colors.white54,
                  fontFamily: 'ShareTechMono',
                  fontSize: 12),
              textAlign: TextAlign.center),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: onDismiss,
              style: ElevatedButton.styleFrom(
                backgroundColor: accent.withOpacity(0.12),
                foregroundColor: accent,
                side: BorderSide(color: accent.withOpacity(0.35)),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                padding: const EdgeInsets.symmetric(vertical: 14),
                elevation: 0,
              ),
              child: const Text("DONE",
                  style: TextStyle(
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1)),
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  SuccessVideoDialog — dipertahankan agar tidak break referensi lain
// ═══════════════════════════════════════════════════════════════

class SuccessVideoDialog extends StatelessWidget {
  final String target;
  final VoidCallback onDismiss;

  const SuccessVideoDialog({
    super.key,
    required this.target,
    required this.onDismiss,
  });

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFF00C6FF);
    return AlertDialog(
      backgroundColor: const Color(0xFF112233),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: accent.withOpacity(0.3)),
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(FontAwesomeIcons.checkDouble, color: accent, size: 40),
          const SizedBox(height: 16),
          const Text("Attack Successful!",
              style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                  fontSize: 16)),
          const SizedBox(height: 8),
          Text("Bug sent to $target",
              style: const TextStyle(
                  color: Colors.white54, fontFamily: 'ShareTechMono')),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: onDismiss,
            style: ElevatedButton.styleFrom(
              backgroundColor: accent.withOpacity(0.1),
              foregroundColor: accent,
              side: BorderSide(color: accent.withOpacity(0.3)),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
            ),
            child: const Text("DONE",
                style: TextStyle(fontFamily: 'Orbitron')),
          ),
        ],
      ),
    );
  }
}
