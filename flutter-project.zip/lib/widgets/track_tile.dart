import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../models/track.dart';

class TrackTile extends StatelessWidget {
  final Track track;
  final VoidCallback onTap;
  final Widget? trailing;

  const TrackTile({
    super.key,
    required this.track,
    required this.onTap,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      leading: ClipRRect(
        borderRadius: BorderRadius.circular(6),
        child: track.thumbnailUrl.isNotEmpty
            ? CachedNetworkImage(
                imageUrl: track.thumbnailUrl,
                width: 48,
                height: 48,
                fit: BoxFit.cover,
                errorWidget: (_, __, ___) => _placeholder(),
              )
            : _placeholder(),
      ),
      title: Text(track.name, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Text(track.artistNames, maxLines: 1, overflow: TextOverflow.ellipsis),
      trailing: trailing,
    );
  }

  Widget _placeholder() => Container(
        width: 48,
        height: 48,
        color: Colors.white10,
        child: const Icon(Icons.music_note, color: Colors.white38),
      );
}
