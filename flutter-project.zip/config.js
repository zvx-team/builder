module.exports = {
  BOT_TOKEN: "8920879667:AAGvva3lRaiEWT9XXxrTe1wLugJSZHaDOsg",
  OWNER_ID: ["7976707432"],
};